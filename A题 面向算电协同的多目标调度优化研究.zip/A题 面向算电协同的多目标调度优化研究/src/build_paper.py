# -*- coding: utf-8 -*-
"""由 paper_content.py 生成 paper/论文.docx 与 paper/main.tex。"""
from __future__ import annotations

from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

from common import PROJECT_ROOT, TABLE_DIR, FIG_DIR
from paper_content import content
from paper_data import build

PAPER_DIR = PROJECT_ROOT / "paper"


def _set_cn_font(run, cn="宋体", latin="Times New Roman", size=12, bold=False, color=None):
    run.font.name = latin
    run.font.size = Pt(size)
    run.font.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = rpr.makeelement(qn("w:rFonts"), {})
        rpr.append(rfonts)
    rfonts.set(qn("w:eastAsia"), cn)


def _add_para(doc, text, size=12, bold=False, align=None, indent=True, cn="宋体"):
    p = doc.add_paragraph()
    if align:
        p.alignment = align
    if indent:
        p.paragraph_format.first_line_indent = Pt(size * 2)
    p.paragraph_format.line_spacing = 1.4
    r = p.add_run(text)
    _set_cn_font(r, cn=cn, size=size, bold=bold)
    return p


def _add_heading(doc, text, level):
    sizes = {1: 15, 2: 13}
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10 if level == 1 else 6)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.3
    r = p.add_run(text)
    _set_cn_font(r, cn="黑体", size=sizes.get(level, 12), bold=True)
    return p


def _add_table(doc, title, header, rows, note=None):
    _add_para(doc, title, size=10.5, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, indent=False, cn="黑体")
    rows = list(rows)[:60]
    tbl = doc.add_table(rows=1 + len(rows), cols=len(header))
    tbl.style = "Table Grid"
    tbl.alignment = 1
    for j, h in enumerate(header):
        cell = tbl.cell(0, j)
        cell.text = ""
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(str(h))
        _set_cn_font(r, cn="黑体", size=9, bold=True)
    for i, row in enumerate(rows, start=1):
        for j, v in enumerate(row):
            cell = tbl.cell(i, j)
            cell.text = ""
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = p.add_run(str(v))
            _set_cn_font(r, size=9)
    if note:
        _add_para(doc, note, size=9, indent=False)
    return tbl


def _add_csv_table(doc, spec, data):
    name = spec["file"]
    path = TABLE_DIR / f"{name}.csv"
    if not path.exists():
        _add_para(doc, f"[缺失表格 {name}]", size=10)
        return
    df = pd.read_csv(path)
    if "max_rows" in spec:
        df = df.head(spec["max_rows"])
    header = [str(c) for c in df.columns]
    rows = [[fmt(v) for v in r] for r in df.to_numpy().tolist()]
    _add_table(doc, spec.get("title", name), header, rows, spec.get("note"))


def fmt(v) -> str:
    if isinstance(v, float):
        return f"{v:.2f}"
    return str(v)


def _add_figure(doc, path, caption, width_cm):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    img = FIG_DIR / path
    if img.exists():
        run.add_picture(str(img), width=Cm(width_cm))
    else:
        _set_cn_font(run, size=10)
        run.add_text("（图件待生成）")
    _add_para(doc, caption, size=10.5, align=WD_ALIGN_PARAGRAPH.CENTER, indent=False)


def build_docx(D: dict) -> Path:
    PAPER_DIR.mkdir(exist_ok=True)
    doc = Document()
    eq_no = 0
    for section in doc.sections:
        section.page_width = Cm(21)
        section.page_height = Cm(29.7)
        section.left_margin = Cm(2.5)
        section.right_margin = Cm(2.5)
        section.top_margin = Cm(2.54)
        section.bottom_margin = Cm(2.54)

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = title.add_run("面向算电协同的多目标调度优化研究")
    _set_cn_font(r, cn="黑体", size=20, bold=True)
    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = sub.add_run("2026年暑期培训第二次模拟题 A题 建模论文")
    _set_cn_font(r, cn="黑体", size=14, bold=True)
    doc.add_paragraph()

    for block in content(D):
        kind = block[0]
        if kind == "h1":
            _add_heading(doc, block[1], 1)
        elif kind == "h2":
            _add_heading(doc, block[1], 2)
        elif kind == "para":
            _add_para(doc, block[1])
        elif kind == "bullet":
            for item in block[1]:
                p = doc.add_paragraph(style="List Bullet")
                p.paragraph_format.line_spacing = 1.35
                r = p.add_run(item)
                _set_cn_font(r, size=12)
        elif kind == "equation":
            eq_no += 1
            _add_para(doc, block[1]["plain"] + "    " + f"（{eq_no}）",
                      size=12, align=WD_ALIGN_PARAGRAPH.CENTER, indent=False)
        elif kind == "table":
            spec = block[1]
            _add_table(doc, spec["title"], spec["header"], spec["rows"], spec.get("note"))
        elif kind == "csv_table":
            _add_csv_table(doc, block[1], D)
        elif kind == "figure":
            spec = block[1]
            _add_figure(doc, spec["path"], spec["caption"], spec.get("width_cm", 14))
    out = PAPER_DIR / "论文_C023版.docx"
    doc.save(out)
    return out


def build_tex(D: dict) -> Path:
    PAPER_DIR.mkdir(exist_ok=True)
    eq_no = 0
    lines = [
        "\\documentclass[12pt]{ctexart}",
        "\\usepackage[a4paper,left=2.5cm,right=2.5cm,top=2.54cm,bottom=2.54cm]{geometry}",
        "\\usepackage{amsmath,amssymb}",
        "\\usepackage{graphicx}",
        "\\usepackage{booktabs}",
        "\\usepackage{caption}",
        "\\usepackage{float}",
        "\\usepackage[hidelinks]{hyperref}",
        "\\setlength{\\parindent}{2em}",
        "\\begin{document}",
        "\\begin{center}{\\Large\\bfseries 面向算电协同的多目标调度优化研究}\\\\[4pt]"
        "{\\large 2026年暑期培训第二次模拟题 A题 建模论文}\\end{center}",
    ]
    for block in content(D):
        kind = block[0]
        if kind == "h1":
            lines.append(f"\\section{{{block[1]}}}")
        elif kind == "h2":
            lines.append(f"\\subsection{{{block[1]}}}")
        elif kind == "para":
            lines.append(block[1].replace("%", "\\%").replace("&", "\\&").replace("#", "\\#") + "\n\n")
        elif kind == "bullet":
            lines.append("\\begin{itemize}")
            for item in block[1]:
                lines.append(f"\\item {item}")
            lines.append("\\end{itemize}")
        elif kind == "equation":
            eq_no += 1
            lines.append("\\begin{equation}" + block[1]["latex"] + "\\end{equation}")
        elif kind == "table":
            spec = block[1]
            lines.append("\\begin{table}[H]\\centering\\caption{" + spec["title"] + "}")
            lines.append("\\begin{tabular}{" + "c" * len(spec["header"]) + "}\\toprule")
            lines.append(" & ".join(spec["header"]) + " \\\\ \\midrule")
            for row in spec["rows"]:
                lines.append(" & ".join(str(v) for v in row) + " \\\\")
            lines.append("\\bottomrule\\end{tabular}\\end{table}")
        elif kind == "csv_table":
            name = block[1]["file"]
            path = TABLE_DIR / f"{name}.csv"
            if path.exists():
                df = pd.read_csv(path).head(block[1].get("max_rows", 20))
                header = [str(c) for c in df.columns]
                lines.append("\\begin{table}[H]\\centering\\caption{" + block[1].get("title", name) + "}")
                lines.append("\\begin{tabular}{" + "c" * len(header) + "}\\toprule")
                lines.append(" & ".join(header) + " \\\\ \\midrule")
                for _, r in df.iterrows():
                    lines.append(" & ".join(fmt(v) for v in r.tolist()) + " \\\\")
                lines.append("\\bottomrule\\end{tabular}\\end{table}")
        elif kind == "figure":
            spec = block[1]
            width = spec.get("width_cm", 14) / 2.54
            lines.append("\\begin{figure}[H]\\centering")
            lines.append(f"\\includegraphics[width={width:.2f}\\textwidth]{{../figures/{spec['path']}}}")
            lines.append(f"\\caption{{{spec['caption']}}}\\end{{figure}}")
    lines.append("\\end{document}")
    out = PAPER_DIR / "main.tex"
    out.write_text("\n".join(lines), encoding="utf-8")
    return out


if __name__ == "__main__":
    data = build()
    docx_path = build_docx(data)
    tex_path = build_tex(data)
    print("docx:", docx_path)
    print("tex:", tex_path)
