# -*- coding: utf-8 -*-
"""论文数据汇总：从 results/ 与 tables/ 读取关键结果，统一供论文生成器使用。"""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from common import PROJECT_ROOT, TABLE_DIR, OUT_DIR


def _load_json(name: str) -> dict:
    p = OUT_DIR / f"{name}.json"
    if not p.exists():
        return {}
    return json.loads(p.read_text(encoding="utf-8"))


def _load_csv(name: str) -> pd.DataFrame:
    p = TABLE_DIR / f"{name}.csv"
    if not p.exists():
        return pd.DataFrame()
    return pd.read_csv(p)


def build() -> dict:
    d = {
        "q1_prediction": _load_json("q1_prediction_summary"),
        "q1_schedule": _load_json("q1_schedule_summary"),
        "q2_metrics": _load_json("q2_metrics"),
        "q3_summary": _load_csv("q3_summary"),
        "q3_totals": _load_csv("q3_totals"),
        "q4_scenarios": _load_csv("q4_scenario_metrics"),
        "q4_tradeoff": _load_csv("q4_tradeoff_metrics"),
        "q1_metrics": _load_csv("q1_prediction_metrics"),
        "workload_stats": _load_csv("q1_workload_statistics"),
    }
    return d
