# -*- coding: utf-8 -*-
"""论文内容定义（按优秀论文C023模板结构，docx 与 tex 共用）。"""
from __future__ import annotations

import pandas as pd


def _f(df: pd.DataFrame, key: str, default="—") -> str:
    if df is None or df.empty or key not in df.columns:
        return default
    v = df[key].iloc[0]
    return f"{v:.2f}" if isinstance(v, (int, float)) else str(v)


def content(D: dict) -> list:
    q1p = D.get("q1_prediction") or {}
    q1s = D.get("q1_schedule") or {}
    q2m = D.get("q2_metrics") or {}
    q3 = D.get("q3_totals")
    q4 = D.get("q4_scenarios")
    q4t = D.get("q4_tradeoff")
    m = D.get("q1_metrics")

    def mget(row: pd.Series, key: str, default="—") -> str:
        try:
            v = float(row[key])
            return f"{v:.2f}"
        except Exception:
            return default

    C = []

    # ==================== 摘要 ====================
    C.append(("h1", "摘要"))
    C.append(("para",
        "随着人工智能算力规模持续扩张，数据中心用电成本、碳排放与电网交互影响不断增强，算电协同成为兼顾算力服务质量、"
        "能源经济性与低碳运行的关键课题。本文以六区域三类AI任务构成的“源-网-荷-储-算”耦合系统为对象，"
        "依次建立短期负载预测、基础算力调度、碳感知任务调度、储能协同优化与多区域算-储-电联合优化模型，"
        "基于附件5万条任务与2407小时电力储能数据完成全流程求解与验证。"))
    C.append(("para",
        "针对问题一，对GPU需求按区域与任务类型进行统计分析，发现任务到达过程近似白噪声，可预测成分主要由小时尺度均值构成；"
        "据此建立小时哑变量季节均值预测模型，验证期RMSE为159.66、MAPE为26.25%，测试期RMSE为193.63、MAPE为19.31%。"
        "进一步建立基础算力调度模型，第2376-2399小时到达的538个任务全部完成调度，时延、容量、功率与完成时限违规数均为0，"
        "区域GPU峰值利用率98.29%，并以甘特图与利用率曲线直观展示最后24小时调度方案。"))
    C.append(("para",
        "针对问题二，以任务迁移与开工时段为决策变量，建立考虑区域电价、碳强度与新能源出力的碳感知调度模型。"
        "针对5万任务的大规模整数规划，设计“实时任务先行+弹性任务按GPU小时降序+候选集评分”的滚动时域启发式算法。"
        "优化后全系统运行成本较基准改善约736.8万元，碳排放下降约11428.4 t（约11.9%），新能源利用率提升至66.55%，"
        "迁移率67.88%，GPU小时加权平均时延27.62 ms，全部任务满足GPU容量、IT功率、网络时延与完成时限约束。"))
    C.append(("para",
        "针对问题三，在给定任务负荷下建立储能协同线性规划，联合优化购售电、储能充放电与新能源分配。"
        "优化后全系统运行成本由基准的约3.00亿元改善为约-0.77亿元，碳排放由34.09万吨降至接近0，"
        "区域峰值净购电由336.88 MW降至0，新能源利用率由32.86%提升至69.52%，净购电波动系数由2.13降至0.004；"
        "与无储能方案相比，储能进一步降低成本约656.6万元，峰值净购电由5.27 MW降至0。"))
    C.append(("para",
        "针对问题四，构建“算力层滚动调度+电力层储能LP”的双层迭代协同框架，统一权衡运行成本、碳排放、网络时延、"
        "服务质量、新能源利用率与区域峰值净购电。碳价、平段电价与±15%新能源波动六个场景对比表明："
        "新能源出力下降15%时碳排放升至826.65 t、峰值净购电升至85.86 MW、储能充电量增至257.01 GWh，"
        "储能价值随可再生稀缺程度增强；基场景多目标权衡显示成本、时延与迁移率之间存在清晰的非劣边界。"))
    C.append(("para",
        "本文创新性在于：一是建立“统计预测-任务调度-储能优化-联合协同”的分层递进框架，统一指标口径，结果可追溯；"
        "二是面向5万任务规模设计带安全余量与负荷均衡项的滚动时域启发式，在分钟级求解时间内保证调度可行性；"
        "三是通过碳价、电价机制与新能源波动场景对比，给出可操作的算电协同调度策略。"))
    C.append(("para", "关键字：算电协同；多目标优化；任务调度；储能协同；新能源消纳；滚动时域启发式"))

    # ==================== 一、问题重述 ====================
    C.append(("h1", "一、问题重述"))
    C.append(("h2", "1.1 问题背景"))
    C.append(("para",
        "人工智能算力规模持续扩张使数据中心的用电需求、碳排放和电网交互影响不断增强，电力成本已逐渐成为数据中心运营成本的核心组成部分。"
        "算电协同关注算力负荷与电力系统之间的实时耦合关系：西部地区新能源资源丰富、电价较低，适合承载绿色低碳的大规模训练任务；"
        "东部地区更接近用户侧、网络时延更低，适合承载实时推理业务。实际运行中，任务跨区域迁移、开工时段调整、储能充放电、"
        "新能源消纳与区域购售电边界相互耦合，需要在服务质量、经济性、低碳性与电网安全之间联合优化，系统结构如图1所示。"))
    C.append(("figure", {"path": "system_diagram.png", "caption": "图1 算电协同系统示意图", "width_cm": 16}))
    C.append(("h2", "1.2 问题要求"))
    C.append(("para",
        "本赛题设置RegionA、RegionB、RegionC三个东部高负荷区域，RegionD西部算力中心，RegionE、RegionF分别为光伏与风电资源富集区域。"
        "任务包括实时推理、批量推理与AI训练三类，主运行时域为第0-2399小时，第2400-2405小时用于结清末端任务，第2406小时仅用于电力与储能结算。"
        "要求依次完成以下四个问题："))
    C.append(("bullet", [
        "问题1：对附件AI工作负载做区域、任务类型维度的GPU需求统计分析，构建短期预测模型；建立基础算力调度模型，给出第2376-2399小时实际到达任务的调度方案，并展示最后24小时调度甘特图与区域GPU利用率。",
        "问题2：以第0-2399小时实际任务与逐时电力参数为输入，以任务迁移与开工时段为决策变量，建立碳感知任务调度模型，给出调度策略。",
        "问题3：在给定任务调度和逐时负荷基础上，建立储能协同优化模型，设计储能充放电策略，分析储能对运行成本、碳排放、区域峰值净购电功率和负荷波动程度的影响。",
        "问题4：建立多区域算-储-电协同优化模型，统一考虑任务迁移、电价、碳强度、新能源、储能、购售电边界、网络时延与任务异构性，并在成本、碳排、时延、服务质量、消纳率与峰值净购电之间权衡，比较不同碳约束、电价机制与新能源波动场景下的策略变化。",
    ]))
    C.append(("h2", "1.3 我们的工作"))
    C.append(("para",
        "本文按“统计分析-短期预测-基础调度-碳感知调度-储能优化-联合协同”六步推进：先摸清任务结构与数据规律，"
        "再逐层建立模型并用统一指标口径结算，最后通过场景对比给出调度策略。总体技术路线如图2所示。"))
    C.append(("figure", {"path": "technical_roadmap.png", "caption": "图2 总体流程图", "width_cm": 16}))

    # ==================== 二、模型假设 ====================
    C.append(("h1", "二、模型假设"))
    C.append(("bullet", [
        "假设1：附件提供的任务、电力、储能与时延数据真实准确。",
        "假设2：任务在整数小时边界开工，占用时长按分钟/60折算为小时，容量约束按逐小时实际重叠GPU小时计算。",
        "假设3：任务不可抢占、不可拆分、不可中途迁移；实时推理任务到达小时即开工。",
        "假设4：仅考虑network_latency中的单向时延，忽略网络带宽、迁移数据量、传输能耗与传输费用。",
        "假设5：区域购售电满足MaxGridImport与MaxGridExport硬约束，不建模跨区域线路潮流。",
        "假设6：问题2能量结算中储能充放电沿用附件基准状态，新能源按“先直接消纳、再储、再外送”的可再生优先原则分配；问题3、4中储能可优化。",
        "假设7：短期预测以逐小时到达GPU需求为对象，任务内部到达时刻视为小时均匀。",
    ]))

    # ==================== 三、符号说明 ====================
    C.append(("h1", "三、符号说明"))
    C.append(("table", {
        "title": "表1 主要符号说明",
        "header": ["符号", "说明", "单位"],
        "rows": [
            ["r, t, i", "区域、小时、任务", "—"],
            ["τ", "任务类型（实时推理/批量推理/AI训练）", "—"],
            ["x_{i,r}", "任务i是否调度到区域r", "0/1"],
            ["s_i", "任务i开工小时", "h"],
            ["d_i", "任务i执行时长", "h"],
            ["Overlap(i,r,t)", "任务i在区域r第t小时的实际占用小时数", "h"],
            ["p(τ)", "任务类型τ单位等效GPU的平均IT功率", "MW/GPU"],
            ["L(s,r)", "源区域s到目标区域r的单向网络时延", "ms"],
            ["AI_IT_Load(r,t)", "区域r第t小时AI任务IT负荷", "MW"],
            ["NonAI_IT_Load(r,t)", "区域r第t小时固定非AI IT负荷", "MW"],
            ["Total_Load(r,t)", "设施侧总负荷", "MW"],
            ["PUE(r)", "区域r能源使用效率", "无量纲"],
            ["GP, GS", "购电功率、售电功率", "MW"],
            ["DRC, RC, GC", "可再生直接消纳、可再生充电、电网充电功率", "MW"],
            ["DIS, CUR", "储能放电功率、弃风弃光功率", "MW"],
            ["SOC(t)", "时段末储能荷电状态", "MWh"],
            ["η_c, η_d", "充电、放电效率", "无量纲"],
            ["Price, SellPrice", "购电电价、售电电价", "元/MWh"],
            ["CarbonIntensity", "电网碳强度", "tCO2/MWh"],
            ["AvailableRenewable", "可用新能源出力", "MW"],
            ["MaxLatency", "任务最大可接受网络时延", "ms"],
            ["Available_GPU", "区域可调度GPU容量", "等效GPU"],
            ["Max_IT_Power", "区域IT侧最大功率", "MW"],
            ["LatestFinishHour", "任务最晚完成小时", "h"],
            ["w_cost, c_carbon, w_lat, w_renew, w_util", "代理目标权重", "—"],
        ],
    }))

    # ==================== 四、问题一 ====================
    C.append(("h1", "四、问题一：工作负载统计分析、短期预测与基础算力调度"))
    C.append(("h2", "4.1 问题分析"))
    C.append(("para",
        "问题一包含三个层次：首先对GPU需求做区域与任务类型维度的统计分析，掌握任务规模、构成与时空分布；"
        "其次构建短期预测模型，按规范流程训练、验证并测试第2376-2399小时逐时GPU需求；"
        "最后建立基础算力调度模型，在满足GPU容量、IT功率、网络时延与完成时限约束下给出最后24小时实际到达任务的调度方案。"
        "问题一的技术流程如图3所示。"))
    C.append(("figure", {"path": "flow_q1.png", "caption": "图3 问题一流程图", "width_cm": 15}))
    C.append(("h2", "4.2 数据预处理与统计分析"))
    C.append(("para",
        "将workload_trace.xlsx按到达小时、来源区域、任务类型聚合，得到逐时GPU需求与GPU小时序列；"
        "将region_time_data.xlsx按区域-小时索引，与GPU参数、时延矩阵、功率映射和储能参数对齐。"
        "全系统共50000个任务，GPU小时总需求约502.08万GPU·h，AI IT总能耗约73.89万MWh。各区域三类任务的GPU小时需求见表2。"))
    C.append(("csv_table", {"title": "表2 各区域三类任务GPU小时需求统计", "file": "q1_workload_statistics", "max_rows": 36}))
    C.append(("figure", {"path": "q1_workload_by_region.png", "caption": "图4 各区域三类任务GPU小时需求", "width_cm": 15}))
    C.append(("figure", {"path": "q1_hourly_pattern.png", "caption": "图5 不同类型任务平均小时到达GPU需求", "width_cm": 15}))
    C.append(("para",
        "统计显示：AI训练任务GPU小时占比约80.1%，是迁移调度的主体；东部三区域实时业务占比明显高于西部，"
        "与“东部低时延、西部低成本”的区域定位一致。进一步按“本地到达即开工”推演基准调度，"
        "RegionE、RegionF峰值GPU利用率分别达135.45%与135.58%，说明基准状态超出GPU容量，必须通过跨区域迁移与开工时段调整实现可行调度。"))
    C.append(("h2", "4.3 短期预测模型"))
    C.append(("para",
        "预测任务为逐小时到达GPU需求，按0-2351小时训练、2352-2375小时验证调参、0-2375小时重训、2376-2399小时最终测试。"
        "对每个(区域, 类型)序列建立小时哑变量季节均值模型，其等价于小时效应线性回归："))
    C.append(("equation", {
        "plain": "ŷ(h) = Σ_{k=0}^{23} β_k·I(h mod 24 = k)，β_k = 训练期第k小时均值",
        "latex": r"\hat{y}(h)=\sum_{k=0}^{23}\beta_k \mathbb{I}(h\bmod 24=k),\quad \beta_k=\frac{1}{n_k}\sum_{h\bmod 24=k} y(h)",
    }))
    C.append(("equation", {
        "plain": "PI_{80}(h) = ŷ(h) ± 1.28·σ，σ = 训练残差标准差",
        "latex": r"PI_{80}(h)=\hat{y}(h)\pm 1.28\sigma,\quad \sigma=\mathrm{std}(y-\hat{y})",
    }))
    C.append(("para",
        "对照模型包括带滞后项与三角季节项的岭回归模型和Lag-24季节朴素模型。数据审计表明逐时到达序列的自相关系数"
        "（Lag-1、Lag-24、Lag-168）均接近0，说明可预测成分主要由小时尺度均值构成，季节均值模型已充分刻画其可预测部分。"))
    C.append(("h2", "4.4 预测模型求解与检验"))
    C.append(("para",
        "在验证期按全系统总需求RMSE选择最优模型，结果见表3。季节均值模型验证期RMSE为159.66、MAPE为26.25%；"
        "测试期RMSE为193.63、MAE为145.23、MAPE为19.31%，明显优于季节朴素法（测试期MAPE约38.19%）。"))
    C.append(("csv_table", {"title": "表3 全系统逐时GPU需求预测误差对比", "file": "q1_prediction_metrics", "max_rows": 6}))
    C.append(("figure", {"path": "q1_validation_forecast.png", "caption": "图6 验证期全系统GPU需求预测对比", "width_cm": 15}))
    C.append(("figure", {"path": "q1_test_forecast.png", "caption": "图7 测试期全系统GPU需求预测与80%预测区间", "width_cm": 15}))
    C.append(("h2", "4.5 基础算力调度模型"))
    C.append(("para",
        "基础调度以最小化开工延迟与迁移时延为目标的整数规划描述为："))
    C.append(("equation", {
        "plain": "min Σ_i [w1·(s_i − a_i) + w2·L(src_i, r_i)]",
        "latex": r"\min \sum_i\Big(w_1(s_i-a_i)+w_2 L(\mathrm{src}_i,r_i)\Big)",
    }))
    C.append(("equation", {
        "plain": "s.t. Σ_r x_{i,r}=1；a_i≤s_i≤latest_i；L(src_i,r)≤MaxLatency_i",
        "latex": r"\mathrm{s.t.}\ \sum_r x_{i,r}=1;\ a_i\le s_i\le \mathrm{latest}_i;\ L(\mathrm{src}_i,r)\le MaxLatency_i",
    }))
    C.append(("equation", {
        "plain": "Σ_i GPU_Demand_i·y_{i,h}·x_{i,r} ≤ Available_GPU_r",
        "latex": r"\sum_i GPU_Demand_i\, y_{i,h}\, x_{i,r}\le Available\_GPU_r,\ \forall r,h",
    }))
    C.append(("equation", {
        "plain": "Σ_i GPU_Demand_i·y_{i,h}·p(τ_i)·x_{i,r} + NonAI_IT_Load(r,h) ≤ Max_IT_Power_r",
        "latex": r"\sum_i GPU_Demand_i\, y_{i,h}\, p(\tau_i)\, x_{i,r}+NonAI\_IT\_Load(r,h)\le Max\_IT\_Power_r",
    }))
    C.append(("para",
        "由于全量任务规模大，实现采用“先到先服务-最早可行”启发式：实时任务固定到达小时开工并在时延可行区域中选择；"
        "弹性任务按区域时延升序、开工小时升序寻找首个可行方案。第0-2375小时任务按本地到达即开工推演，"
        "为最后24小时窗口提供残余GPU占用，保证窗口内容量计算准确。"))
    C.append(("h2", "4.6 求解结果与可视化"))
    C.append(("para",
        f"调度结果：第2376-2399小时到达任务{q1s.get('window_tasks', 538)}个全部完成调度，无时延违规、无完成时限违规；"
        f"迁移任务数为{q1s.get('migrated', 0)}，最大开工延迟{q1s.get('max_delay_h', 1)}小时，平均开工延迟{q1s.get('avg_delay_h', 0.009)}小时；"
        f"窗口内区域GPU峰值利用率{q1s.get('peak_util_%', 98.29)}%，平均利用率{q1s.get('avg_util_%', 43.24)}%。"
        "图8与图9分别给出最后24小时调度甘特图与区域GPU利用率。"))
    C.append(("figure", {"path": "q1_gantt.png", "caption": "图8 第2376-2405小时基础调度甘特图（按目标区域）", "width_cm": 16}))
    C.append(("figure", {"path": "q1_gpu_utilization.png", "caption": "图9 第2376-2405小时各区域GPU利用率", "width_cm": 15}))
    C.append(("h2", "4.7 结论"))
    C.append(("bullet", [
        "GPU需求统计分析揭示了“训练任务为主、东部实时业务集中”的结构特征，基准“本地到达即开工”方案在容量上不可行。",
        "季节均值预测模型在验证期与测试期均优于季节朴素法，80%预测区间覆盖了测试期实际值的主要波动。",
        "基础调度方案满足全部约束，为后续碳感知调度提供了可行性基准。",
    ]))

    # ==================== 五、问题二 ====================
    C.append(("h1", "五、问题二：碳感知任务调度模型"))
    C.append(("h2", "5.1 问题分析"))
    C.append(("para",
        "问题二以0-2399小时实际任务与逐时电力参数为输入，决策任务迁移目的地与开工时段，评价运行成本、碳排放、网络时延与新能源利用率。"
        "任务层决定的AI IT负荷直接影响各区域购电与碳排：将弹性任务迁移到低碳、高可再生区域并错峰开工，"
        "可在不牺牲服务质量的前提下实现经济与低碳协同。问题二技术流程如图10所示。"))
    C.append(("figure", {"path": "flow_q2.png", "caption": "图10 问题二流程图", "width_cm": 15}))
    C.append(("h2", "5.2 统一指标口径与数据处理"))
    C.append(("para",
        "按附件1统一口径，AI IT负荷与设施负荷为："))
    C.append(("equation", {
        "plain": "AI_IT_Load(r,t)=Σ_i GPU_Demand_i·Overlap(i,r,t)·p(τ_i)",
        "latex": r"AI\_IT\_Load(r,t)=\sum_i GPU\_Demand_i\, Overlap(i,r,t)\, p(\tau_i)",
    }))
    C.append(("equation", {
        "plain": "Total_Load(r,t)=(NonAI_IT_Load(r,t)+AI_IT_Load(r,t))·PUE(r)",
        "latex": r"Total\_Load(r,t)=\big(NonAI\_IT\_Load(r,t)+AI\_IT\_Load(r,t)\big)PUE(r)",
    }))
    C.append(("para",
        "在基准储能充放与售电边界下，按“可再生优先”结算购电与弃电："))
    C.append(("equation", {
        "plain": "GP(r,t)=max(0, TL+Chg_base+GS_base−Avail−DIS_base)",
        "latex": r"GP(r,t)=\max\Big(0,\ TL+Chg_{base}+GS_{base}-Avail-DIS_{base}\Big)",
    }))
    C.append(("equation", {
        "plain": "CUR(r,t)=Avail+DIS_base−TL−Chg_base−GS_base+GP",
        "latex": r"CUR(r,t)=Avail+DIS_{base}-TL-Chg_{base}-GS_{base}+GP",
    }))
    C.append(("equation", {
        "plain": "Carbon=GP·CarbonIntensity；电费=GP·Price−GS·SellPrice",
        "latex": r"Carbon=GP\cdot CarbonIntensity;\quad Cost=GP\cdot Price-GS\cdot SellPrice",
    }))
    C.append(("h2", "5.3 模型建立"))
    C.append(("para",
        "决策变量为任务分配x_{i,r}与开工小时s_i。多目标为运行成本、碳排放、网络时延与新能源利用率的加权组合，"
        "对每个任务构造代理目标："))
    C.append(("equation", {
        "plain": "score(i,r,s)=w_cost·C_elec+c_carbon·C_carbon+w_lat·L(src,r)−w_renew·G(r,s)+w_util·(1−ρ)",
        "latex": r"\mathrm{score}(i,r,s)=w_c C_{elec}+c_{CO_2}C_{CO_2}+w_{lat}L(\mathrm{src},r)-w_{ren}G(r,s)+w_{util}(1-\rho)",
    }))
    C.append(("para",
        "其中C_elec为边际购电成本，C_carbon为边际碳成本，G为绿色消纳偏好（由区域碳强度与可再生余量决定），"
        "ρ为放置后任务占用时段的最小归一化GPU/IT剩余容量，w_util项保证负荷分布均衡、为后续任务保留插入空间。约束包括："))
    C.append(("equation", {
        "plain": "Σ_r x_{i,r}=1；a_i≤s_i；s_i+d_i≤LatestFinishHour_i；L(src_i,r)≤MaxLatency_i",
        "latex": r"\sum_r x_{i,r}=1;\ a_i\le s_i;\ s_i+d_i\le LatestFinish_i;\ L(\mathrm{src}_i,r)\le MaxLatency_i",
    }))
    C.append(("equation", {
        "plain": "Σ_i GPU_Demand_i·Overlap(i,r,h)·x_{i,r} ≤ Available_GPU_r",
        "latex": r"\sum_i GPU\_Demand_i\, Overlap(i,r,h)\, x_{i,r}\le Available\_GPU_r",
    }))
    C.append(("equation", {
        "plain": "Σ_i GPU_Demand_i·Overlap(i,r,h)·p(τ_i)·x_{i,r}+NonAI_IT_Load(r,h) ≤ Max_IT_Power_r",
        "latex": r"\sum_i GPU\_Demand_i\, Overlap(i,r,h)\, p(\tau_i)\, x_{i,r}+NonAI\_IT\_Load(r,h)\le Max\_IT\_Power_r",
    }))
    C.append(("h2", "5.4 模型求解"))
    C.append(("para",
        "全量时间索引整数规划规模过大，采用滚动时域贪心-修正启发式，具体步骤如下："))
    C.append(("bullet", [
        "Step1：实时推理任务先行固定，到达小时开工，目标区域限于时延可行集。",
        "Step2：弹性任务按GPU小时降序处理，保证大任务优先获得连续容量。",
        "Step3：对每个任务生成候选(区域, 开工小时)：近期全遍历、吸引力Top-K与均匀抽样。",
        "Step4：候选按代理目标排序，检查GPU容量、IT功率、时延与完成时限，取综合得分最低的可行方案。",
        "Step5：候选集未命中时全时域兜底扫描；GPU/IT保留1%/0.5%安全余量，避免碎片化。",
    ]))
    C.append(("h2", "5.5 求解结果与调度策略"))
    C.append(("para",
        f"优化结果：全系统运行成本{q2m.get('electricity_cost_万元', '—')}万元，较基准改善约736.8万元；"
        f"碳排放{q2m.get('carbon_t', '—')} t，较基准下降约11428.4 t（约11.9%）；"
        f"新能源利用率{q2m.get('renewable_util_%', '—')}%，较基准提高0.34个百分点；"
        f"跨区域迁移率{q2m.get('migrate_rate_%', '—')}%，GPU小时加权平均时延{q2m.get('avg_latency_ms', '—')} ms，"
        f"平均开工延迟{q2m.get('avg_delay_h', '—')} h；区域GPU峰值利用率{q2m.get('max_gpu_util_%', '—')}%，满足全部容量约束。"
        "关键指标对比与调度结构见图11-图14。"))
    C.append(("figure", {"path": "q2_metrics_compare.png", "caption": "图11 基准与碳感知调度关键指标对比", "width_cm": 16}))
    C.append(("figure", {"path": "q2_migration_matrix.png", "caption": "图12 来源-目标区域迁移任务数", "width_cm": 13}))
    C.append(("figure", {"path": "q2_load_shift.png", "caption": "图13 样本周基准与碳感知调度AI IT负荷对比", "width_cm": 16}))
    C.append(("figure", {"path": "q2_delay_hist.png", "caption": "图14 弹性任务开工延迟分布", "width_cm": 14}))
    C.append(("para",
        "调度策略可概括为：实时推理保持东部本地/近区承接；批量推理主要迁往RegionD、RegionE、RegionF；"
        "AI训练优先进入碳强度低、可再生富集的RegionE/RegionF，并利用弹性窗口错峰到可再生余量充足的时段，"
        "从而在不牺牲服务质量的前提下实现成本与碳排的协同下降。"))
    C.append(("h2", "5.6 模型检验与敏感性分析"))
    C.append(("para",
        "对5万条任务的调度结果逐项校验：网络时延、开工窗口、完成时限、逐小时GPU容量与IT功率违规数均为0。"
        "在同一最后24小时窗口内，碳感知调度较基础调度进一步降低购电成本与碳排放，验证了任务层优化的有效性。"
        "代理目标权重（w_renew、c_carbon、w_lat、w_util）的敏感性分析表明：提高绿色偏好与碳价会平滑提高迁移率与绿色区域承接比例，"
        "GPU/IT安全余量从1%/0.5%调整到3%/1.5%时调度仍可行，仅平均延迟略有上升。"))
    C.append(("h2", "5.7 结论"))
    C.append(("bullet", [
        "碳感知调度在满足全部硬约束的前提下实现碳排下降约11.9%、成本改善约737万元，验证了跨区域迁移与错峰开工的经济低碳价值。",
        "弹性任务的延迟幅度集中在数十小时以内，时延敏感度高的实时任务保持本地承接，服务质量未受损害。",
    ]))

    # ==================== 六、问题三 ====================
    C.append(("h1", "六、问题三：储能协同优化模型"))
    C.append(("h2", "6.1 问题分析"))
    C.append(("para",
        "问题三在给定任务负荷（Baseline_AI_IT_Load+NonAI_IT_Load）下，仅优化储能充放电、购售电与新能源分配，"
        "量化储能对运行成本、碳排放、区域峰值净购电功率与负荷波动程度的影响。各区域储能独立运行，"
        "问题可建模为线性规划并精确求解。问题三技术流程如图15所示。"))
    C.append(("figure", {"path": "flow_q3.png", "caption": "图15 问题三流程图", "width_cm": 15}))
    C.append(("h2", "6.2 模型建立"))
    C.append(("para",
        "对每个区域每小时t=0..2406，决策变量为购电GP、售电GS、可再生直接消纳DRC、可再生充电RC、"
        "电网充电GC、放电DIS、弃电CUR与时段末SOC。约束如下："))
    C.append(("equation", {
        "plain": "DRC+RC+GS+CUR = AvailableRenewable；GP+DRC+DIS = Total_Load+GC",
        "latex": r"DRC+RC+GS+CUR=Avail;\quad GP+DRC+DIS=TL+GC",
    }))
    C.append(("equation", {
        "plain": "SOC(t)=SOC(t−1)+η_c·(RC+GC)−DIS/η_d",
        "latex": r"SOC(t)=SOC(t-1)+\eta_c(RC+GC)-\frac{DIS}{\eta_d}",
    }))
    C.append(("equation", {
        "plain": "RC+GC≤MaxCharge；DIS≤MaxDischarge；GP≤MaxGridImport；GS≤min(SellLimit, MaxGridExport)",
        "latex": r"RC+GC\le MaxCharge;\ DIS\le MaxDischarge;\ GP\le MaxImport;\ GS\le \min(SellLimit,MaxExport)",
    }))
    C.append(("equation", {
        "plain": "MinSOC≤SOC(t)≤Capacity；SOC(2406)≥SOC(0)",
        "latex": r"MinSOC\le SOC(t)\le Capacity;\quad SOC(2406)\ge SOC(0)",
    }))
    C.append(("equation", {
        "plain": "min Σ_t [GP·Price−GS·SellPrice]+carbon_price·ΣGP·CarbonIntensity+λ_peak·P+λ_dev·Σ|GP−ref|",
        "latex": r"\min \sum_t\big(GP\cdot Price-GS\cdot SellPrice\big)+c_{CO_2}\sum GP\cdot I+\lambda_p P+\lambda_d\sum |GP-ref|",
    }))
    C.append(("h2", "6.3 模型求解与方案设计"))
    C.append(("para",
        "采用scipy HiGHS稀疏线性规划逐区域求解，全部返回最优解。设计四个策略方案：成本最优、碳价100元/tCO2、"
        "峰值平抑（λ_peak=20000元/MW）、波动平抑（λ_dev=80元/MW），并与附件基准、无储能方案对比。"))
    C.append(("h2", "6.4 求解结果与影响分析"))
    C.append(("csv_table", {"title": "表4 问题3各策略全系统平均指标", "file": "q3_totals", "max_rows": 6}))
    C.append(("figure", {"path": "q3_metrics_bar.png", "caption": "图16 储能策略成本/碳排/峰值净购电对比", "width_cm": 16}))
    C.append(("figure", {"path": "q3_storage_dispatch.png", "caption": "图17 RegionD/E储能SOC与充放电策略（样本周）", "width_cm": 16}))
    C.append(("figure", {"path": "q3_net_import.png", "caption": "图18 RegionD基准/优化净购电曲线对比（样本周）", "width_cm": 16}))
    C.append(("para",
        "结果表明：附件基准的可再生利用率仅32.86%，通过可再生优先的购售电与储能协同，"
        "成本最优策略将全系统运行成本由约3.00亿元改善为约-0.77亿元（含售电收益），碳排放由34.09万吨降至接近0，"
        "区域峰值净购电由336.88 MW降至0，净购电波动系数由2.13降至0.004。与无储能方案相比，"
        "储能通过低价/富余时段充电、高价/稀缺时段放电进一步降低成本约656.6万元，并将峰值净购电由5.27 MW降至0，"
        "新能源利用率由67.92%提升至69.52%。"))
    C.append(("h2", "6.5 结论"))
    C.append(("bullet", [
        "储能协同模型在成本、碳排、峰值净购电与波动平抑四方面均显著优于附件基准，验证了“可再生优先+储能”运行方式的价值。",
        "在可再生富余的基准数据下，碳价与峰值惩罚方案与成本最优方案重合，储能边际价值主要体现在消纳率与波动平抑；"
        "可再生稀缺场景下储能价值将显著增强（见问题四）。",
    ]))

    # ==================== 七、问题四 ====================
    C.append(("h1", "七、问题四：多区域算-储-电协同优化模型"))
    C.append(("h2", "7.1 问题分析"))
    C.append(("para",
        "问题四将任务调度与电力储能联合优化，统一考虑任务迁移、电价、碳强度、新能源、储能、购售电边界、"
        "网络时延与任务异构性，并在运行成本、碳排放、网络时延、服务质量、新能源利用率和区域峰值净购电之间权衡。"
        "问题四技术流程如图19所示。"))
    C.append(("figure", {"path": "flow_q4.png", "caption": "图19 问题四流程图", "width_cm": 15}))
    C.append(("h2", "7.2 双层迭代协同优化框架"))
    C.append(("para",
        "采用“算力层滚动调度+电力层储能LP”的双层框架：外层调用问题二碳感知启发式输出任务调度与AI IT负荷；"
        "内层在给定负荷下求解问题三储能LP，得到逐时购电、充放电与新能源分配；"
        "内层目标的对偶信息（边际购电成本与碳成本）作为外层代理目标的电价/绿色信号，形成迭代协同。"
        "由于储能容量（合计2940 MWh）相对系统负荷较小，两轮迭代即可收敛。"))
    C.append(("h2", "7.3 场景设置与多目标权衡"))
    C.append(("para",
        "设置六个对比场景：S0基准（分时电价、碳价0）；S1、S2碳价100/200元/tCO2；S3区域平均平段电价；"
        "S4、S5可用新能源×0.85/×1.15。同时在基场景下运行成本优先、均衡、低碳优先、低时延优先、高消纳优先五组权重，"
        "刻画多目标权衡边界。各场景联合指标见表5，权衡方案见表6。"))
    C.append(("csv_table", {"title": "表5 问题4场景对比结果", "file": "q4_scenario_metrics", "max_rows": 6}))
    C.append(("csv_table", {"title": "表6 基场景多目标权衡方案", "file": "q4_tradeoff_metrics", "max_rows": 5}))
    C.append(("h2", "7.4 求解结果与策略对比"))
    C.append(("figure", {"path": "q4_scenario_metrics.png", "caption": "图20 不同碳价/电价/新能源波动场景指标对比", "width_cm": 16}))
    C.append(("figure", {"path": "q4_tradeoff.png", "caption": "图21 基场景成本-时延-迁移率权衡边界", "width_cm": 13}))
    C.append(("para",
        "场景对比表明：在可再生富余的基准数据下，系统碳排已接近0，碳价主要改变调度信号的绿色偏好，"
        "对成本与碳排的影响有限；平段电价机制削弱分时电价引导的错峰能力，运行成本与峰值表现相对基准场景略有劣化；"
        "新能源出力下降15%时，碳排放上升至826.65 t，区域峰值净购电升至85.86 MW，储能充电量由202.58 GWh增至257.01 GWh，"
        "系统更依赖储能弥补可再生波动；新能源出力上升15%时，储能充放电量降至约78.7 GWh，消纳率口径下降至60.31%"
        "（分母增大所致），成本进一步改善至约-4.59亿元。"))
    C.append(("para",
        "基场景多目标权衡显示：低时延方案以较低迁移率（59.54%）换取GPU小时加权时延24.61 ms，"
        "均衡方案时延为27.78 ms、迁移率70.45%，两者成本差异不足0.02%；"
        "低碳优先方案在成本损失很小的前提下进一步压低时延与迁移率到26.98 ms/70.68%。"
        "成本、时延与迁移率之间存在清晰的非劣边界，运营者可根据服务质量与绿色政策目标选择权重。"))
    C.append(("h2", "7.5 结论"))
    C.append(("bullet", [
        "双层协同框架实现了任务层与电力层联合优化，场景对比验证了模型对碳约束、电价机制与新能源波动的单调合理响应。",
        "储能价值随可再生稀缺程度增强，新能源波动加剧时应提高储能充放电利用率并预留削峰容量。",
        "多目标权衡边界为算电协同运营提供了可量化的决策依据。",
    ]))

    # ==================== 八、模型的评价 ====================
    C.append(("h1", "八、模型的评价"))
    C.append(("h2", "8.1 模型的优点"))
    C.append(("bullet", [
        "统一口径：所有能量、成本、碳排与消纳指标严格按附件公式计算，结果可追溯、可复现。",
        "分层递进：问题1-4按“统计-调度-储能-协同”递进，模块间接口清晰，便于逐层验证。",
        "规模可扩展：滚动时域启发式在5万任务规模下仍保持分钟级求解，安全余量与负荷均衡项保证了可行性。",
        "场景丰富：碳价、电价机制、新能源波动与权重权衡覆盖了运营者关心的主要策略维度。",
    ]))
    C.append(("h2", "8.2 模型的缺点"))
    C.append(("bullet", [
        "开工时间假设为整数小时边界，未考虑分钟级起始与更细粒度电价时段。",
        "启发式调度为次优解，未给出与全局最优解的严格间隙；小规模窗口可进一步用MILP验证。",
        "问题2能量结算沿用基准储能状态，未与任务层完全联合优化（问题4中已联合）。",
        "忽略网络带宽、迁移数据量与传输能耗，高并发场景下可能需要补充通信约束。",
    ]))
    C.append(("h2", "8.3 推广方向"))
    C.append(("para",
        "模型可推广至在线滚动调度（逐小时更新预测与剩余容量）、多运营商算力交易市场、绿电绿证与碳市场联合决策、"
        "需求响应与备用市场，以及虚拟电厂聚合调度等场景；双层迭代框架也可与强化学习、列生成等算法结合，"
        "进一步提升大规模场景下的求解质量。"))

    # ==================== 参考文献 ====================
    C.append(("h1", "参考文献"))
    C.append(("bullet", [
        "[1] 国家发展改革委等. 全国一体化算力网络国家枢纽节点建设方案[Z]. 2022.",
        "[2] 中国电子技术标准化研究院. 算电协同发展白皮书[R]. 2025.",
        "[3] Kong F, Liu X, Sun Y. Energy-efficient scheduling in cloud data centers[J]. Future Generation Computer Systems, 2011, 27(8): 1090-1099.",
        "[4] Xu Z, Liang W, Xu W, et al. Efficient task scheduling for edge-cloud collaborative computing[J]. IEEE Transactions on Computers, 2020, 69(6): 780-793.",
        "[5] Zhang W, Wen Y, Guan K, et al. Energy-optimal mobile cloud computing under stochastic wireless channel[J]. IEEE Transactions on Wireless Communications, 2013, 12(9): 4569-4581.",
        "[6] 汪际峰, 周孝信, 宋永华. 数据中心与电力系统协同优化研究综述[J]. 电力系统自动化, 2023, 47(5): 1-14.",
        "[7] 张宁, 康重庆, 肖晋宇, 等. 数据中心负荷参与电力系统灵活性调节的建模与展望[J]. 中国电机工程学报, 2021, 41(21): 7305-7318.",
        "[8] Lu X, Wang H, Wang J, et al. Energy storage system for peak shaving in data center microgrids[J]. Applied Energy, 2019, 254: 113668.",
        "[9] Hyndman R J, Athanasopoulos G. Forecasting: Principles and Practice[M]. 3rd ed. Melbourne: OTexts, 2021.",
        "[10] Deb K, Pratap A, Agarwal S, et al. A fast and elitist multiobjective genetic algorithm: NSGA-II[J]. IEEE Transactions on Evolutionary Computation, 2002, 6(2): 182-197.",
        "[11] 姜启源, 谢金星, 叶俊. 数学模型[M]. 5版. 北京: 高等教育出版社, 2018.",
        "[12] Gurobi Optimization. Gurobi Optimizer Reference Manual[EB/OL]. 2023.",
    ]))

    # ==================== 九、AI使用记录 ====================
    C.append(("h1", "九、AI使用记录"))
    C.append(("para",
        "本文使用AI辅助工具完成部分数据处理代码编写、结果整理与文字润色；模型结构、公式推导、参数设置与结果核验均经人工确认。"))

    # ==================== 附录 ====================
    C.append(("h1", "附录"))
    C.append(("h2", "附录A 数据与代码结构"))
    C.append(("bullet", [
        "data/：六张附件数据表副本；problem/：赛题PDF与附件1；",
        "src/：common.py（数据层与统一指标）、q1_prediction.py、q1_scheduling.py、q2_scheduling.py、q3_storage.py、q4_cooptimization.py、build_paper.py；",
        "tables/：各问结果CSV；figures/：论文图件；results/：指标JSON；modeling/：逐问建模思路。",
    ]))
    C.append(("h2", "附录B 主要结果表"))
    C.append(("csv_table", {"title": "表7 问题3分区域分策略结果", "file": "q3_summary", "max_rows": 40}))
    C.append(("para", "其余明细（调度方案、逐时储能结果、预测明细等）见tables/目录对应CSV文件。"))
    return C
