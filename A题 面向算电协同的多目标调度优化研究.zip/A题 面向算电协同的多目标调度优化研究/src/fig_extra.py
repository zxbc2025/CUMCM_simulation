# -*- coding: utf-8 -*-
"""补充图件：Q2指标对比与总体技术路线图。"""
from __future__ import annotations

import json

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from common import FIG_DIR, OUT_DIR

plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei"]
plt.rcParams["axes.unicode_minus"] = False


def q2_metrics_compare() -> None:
    path = OUT_DIR / "q2_metrics.json"
    if not path.exists():
        return
    m = json.loads(path.read_text(encoding="utf-8"))
    cats = ["基准", "Q2碳感知"]
    vals = [
        (m["baseline_cost_万元"], m["electricity_cost_万元"], "运行成本（万元）"),
        (m["baseline_carbon_t"], m["carbon_t"], "碳排放（tCO2）"),
        (m["baseline_renewable_util_%"], m["renewable_util_%"], "新能源利用率（%）"),
        (m["baseline_peak_net_import_MW"], m["peak_net_import_MW"], "峰值净购电（MW）"),
    ]
    fig, axes = plt.subplots(1, 4, figsize=(13, 3.6))
    for ax, (bv, qv, title) in zip(axes, vals):
        ax.bar(cats, [bv, qv], color=["#8C8C8C", "#4C72B0"])
        for i, v in enumerate([bv, qv]):
            ax.text(i, v, f"{v:.1f}", ha="center", va="bottom", fontsize=8)
        ax.set_title(title)
        ax.tick_params(axis="x", labelsize=9)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "q2_metrics_compare.png", dpi=150)
    plt.close(fig)


def roadmap() -> None:
    fig, ax = plt.subplots(figsize=(12, 5.2))
    ax.axis("off")
    boxes = [
        (0.05, 0.72, "附件数据\n任务/电力/储能/时延", "#DEEBF7"),
        (0.30, 0.72, "问题1：统计分析\n短期预测 + 基础调度", "#C6DBEF"),
        (0.55, 0.72, "问题2：碳感知\n任务调度", "#9ECAE1"),
        (0.80, 0.72, "问题3：储能\n协同LP", "#6BAED6"),
        (0.38, 0.25, "问题4：多区域算-储-电协同\n（双层迭代 + 场景对比）", "#4292C6"),
        (0.78, 0.25, "统一指标\n成本/碳排/时延/消纳/峰值", "#2171B5"),
    ]
    for x, y, text, color in boxes:
        ax.add_patch(plt.Rectangle((x, y), 0.17, 0.18, facecolor=color, edgecolor="#08306B", lw=1.2, transform=ax.transAxes))
        ax.text(x + 0.085, y + 0.09, text, ha="center", va="center", fontsize=10, transform=ax.transAxes)
    arrows = [
        (0.22, 0.81, 0.30, 0.81),
        (0.47, 0.81, 0.55, 0.81),
        (0.72, 0.81, 0.80, 0.81),
        (0.40, 0.72, 0.45, 0.43),
        (0.60, 0.72, 0.55, 0.43),
        (0.84, 0.72, 0.82, 0.43),
        (0.55, 0.25, 0.78, 0.25),
    ]
    for x0, y0, x1, y1 in arrows:
        ax.annotate("", xy=(x1, y1), xytext=(x0, y0), xycoords="axes fraction",
                    textcoords="axes fraction", arrowprops=dict(arrowstyle="->", color="#08306B", lw=1.5))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "technical_roadmap.png", dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    q2_metrics_compare()
    roadmap()
    print("extra figures done")
