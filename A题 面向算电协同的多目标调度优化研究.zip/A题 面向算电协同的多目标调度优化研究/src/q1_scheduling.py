# -*- coding: utf-8 -*-
"""
问题1第二部分：第2376-2399小时实际到达任务的基础算力调度。

建模思路：
- 第0-2375小时先按"本地、到达即开工"推演，得到窗口内残余GPU占用；
- 第2376-2399小时到达任务：
    * 实时推理固定到达小时开工，目标区域仅取时延可行集；
    * 批量推理/AI训练在容量可行前提下优先"早开工、低时延、负荷均衡"。
- 输出调度方案、最后24小时甘特图与区域GPU利用率。
"""
from __future__ import annotations

import json

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from common import (
    FIG_DIR,
    H_END,
    OUT_DIR,
    REGIONS,
    load_gpu,
    load_tasks,
    latency_matrix,
    prepare_tasks,
    save_json,
    save_table,
)

plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei"]
plt.rcParams["axes.unicode_minus"] = False

WINDOW_H0, WINDOW_H1 = 2376, 2399
N_HOURS = H_END + 1
TYPE_COLORS = {
    "RealTimeInference": "#C44E52",
    "BatchInference": "#55A868",
    "AITraining": "#4C72B0",
}


def prior_local_occupancy(tasks: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    """第0-2375小时任务按本地到达即开工推演的占用。"""
    gpu_occ = np.zeros((len(REGIONS), N_HOURS))
    ai_it = np.zeros((len(REGIONS), N_HOURS))
    pm = tasks.set_index("TaskID")["power_mw"]
    prior = tasks[tasks["ArrivalHour"] <= 2375]
    for _, t in prior.iterrows():
        s = t["ArrivalHour"]
        d = t["dur_h"]
        r = REGIONS.index(t["SourceRegion"])
        hrs = np.arange(int(np.floor(s)), int(np.ceil(s + d)) + 1)
        ov = np.maximum(0.0, np.minimum(hrs + 1.0, s + d) - np.maximum(hrs, s))
        valid = (hrs >= WINDOW_H0 - 10) & (hrs <= WINDOW_H1 + 6)
        hrs, ov = hrs[valid], ov[valid]
        gpu_occ[r, hrs] += t["GPU_Demand"] * ov
        ai_it[r, hrs] += t["GPU_Demand"] * ov * pm[t["TaskID"]]
    return gpu_occ, ai_it


def check_feasible(
    gpu_occ: np.ndarray,
    ai_it: np.ndarray,
    tasks: pd.DataFrame,
    t: pd.Series,
    region: str,
    start: int,
) -> bool:
    """检查容量、IT功率、时延与完成时限。"""
    lat = latency_matrix()
    src = REGIONS.index(t["SourceRegion"])
    dst = REGIONS.index(region)
    if lat[src, dst] > t["MaxLatency_ms"] + 1e-9:
        return False
    if start + t["dur_h"] > t["LatestFinishHour"] + 1e-9:
        return False
    if start < t["EarliestStartHour"]:
        return False
    gpu = load_gpu().set_index("Region")
    r = dst
    hrs = np.arange(start, int(np.ceil(start + t["dur_h"])) + 1)
    ov = np.maximum(0.0, np.minimum(hrs + 1.0, start + t["dur_h"]) - np.maximum(hrs, start))
    valid = (hrs >= 0) & (hrs < N_HOURS)
    hrs, ov = hrs[valid], ov[valid]
    if np.any(gpu_occ[r, hrs] + t["GPU_Demand"] * ov > gpu.loc[region, "Available_GPU"] + 1e-6):
        return False
    ai_inc = t["GPU_Demand"] * ov * t["power_mw"]
    if np.any(ai_it[r, hrs] + ai_inc > gpu.loc[region, "Max_IT_Power_MW"] + 1e-6):
        return False
    return True


def schedule_window(tasks: pd.DataFrame) -> tuple[list[dict], np.ndarray, np.ndarray]:
    """启发式基础调度：实时固定，弹性任务最早可行优先。"""
    gpu_occ, ai_it = prior_local_occupancy(tasks)
    win = tasks[(tasks["ArrivalHour"] >= WINDOW_H0) & (tasks["ArrivalHour"] <= WINDOW_H1)].copy()
    schedule: list[dict] = []
    lat = latency_matrix()
    gpu = load_gpu().set_index("Region")

    # 实时任务：到达即开工，目标区域按时延可行+剩余容量
    rt = win[win["TaskType"] == "RealTimeInference"].sort_values(["ArrivalHour", "GPU_Demand"], ascending=[True, False])
    for _, t in rt.iterrows():
        src = REGIONS.index(t["SourceRegion"])
        feasible = [
            REGIONS[j]
            for j in range(len(REGIONS))
            if lat[src, j] <= t["MaxLatency_ms"] + 1e-9
        ]
        feasible.sort(key=lambda r: (lat[src, REGIONS.index(r)], -gpu.loc[r, "Available_GPU"]))
        placed = False
        for region in feasible:
            if check_feasible(gpu_occ, ai_it, tasks, t, region, int(t["ArrivalHour"])):
                schedule.append({"task_id": int(t["TaskID"]), "region": region, "start_h": float(t["ArrivalHour"]), "dur_h": float(t["dur_h"])})
                _commit(gpu_occ, ai_it, t, region, int(t["ArrivalHour"]))
                placed = True
                break
        if not placed:
            raise RuntimeError(f"实时任务 {t['TaskID']} 无法调度")

    # 弹性任务：按到达时间、GPU小时排序，最早可行（区域按时延、开工时间排序）
    flex = win[win["TaskType"] != "RealTimeInference"].copy()
    flex["gpu_h"] = flex["GPU_Demand"] * flex["dur_h"]
    flex = flex.sort_values(["ArrivalHour", "gpu_h"], ascending=[True, False])
    for _, t in flex.iterrows():
        src = REGIONS.index(t["SourceRegion"])
        feasible = [
            REGIONS[j]
            for j in range(len(REGIONS))
            if lat[src, j] <= t["MaxLatency_ms"] + 1e-9
        ]
        feasible.sort(key=lambda r: lat[src, REGIONS.index(r)])
        placed = False
        latest = int(t["latest_start"])
        for region in feasible:
            for start in range(int(t["ArrivalHour"]), latest + 1):
                if check_feasible(gpu_occ, ai_it, tasks, t, region, start):
                    schedule.append({"task_id": int(t["TaskID"]), "region": region, "start_h": float(start), "dur_h": float(t["dur_h"])})
                    _commit(gpu_occ, ai_it, t, region, start)
                    placed = True
                    break
            if placed:
                break
        if not placed:
            raise RuntimeError(f"弹性任务 {t['TaskID']} 无法调度")
    return schedule, gpu_occ, ai_it


def _commit(gpu_occ: np.ndarray, ai_it: np.ndarray, t: pd.Series, region: str, start: int) -> None:
    r = REGIONS.index(region)
    hrs = np.arange(start, int(np.ceil(start + t["dur_h"])) + 1)
    ov = np.maximum(0.0, np.minimum(hrs + 1.0, start + t["dur_h"]) - np.maximum(hrs, start))
    valid = (hrs >= 0) & (hrs < N_HOURS)
    hrs, ov = hrs[valid], ov[valid]
    gpu_occ[r, hrs] += t["GPU_Demand"] * ov
    ai_it[r, hrs] += t["GPU_Demand"] * ov * t["power_mw"]


def build_output(schedule: list[dict], tasks: pd.DataFrame) -> pd.DataFrame:
    idx = {s["task_id"]: s for s in schedule}
    rows = tasks[tasks["TaskID"].isin(idx)].copy()
    rows["DestRegion"] = rows["TaskID"].map(lambda i: idx[i]["region"])
    rows["StartHour"] = rows["TaskID"].map(lambda i: idx[i]["start_h"])
    rows["FinishHour"] = rows["StartHour"] + rows["dur_h"]
    lat = latency_matrix()
    rows["Latency_ms"] = [
        lat[REGIONS.index(s), REGIONS.index(d)]
        for s, d in zip(rows["SourceRegion"], rows["DestRegion"])
    ]
    rows["Delay_h"] = rows["StartHour"] - rows["ArrivalHour"]
    rows = rows[
        ["TaskID", "TaskType", "SourceRegion", "DestRegion", "ArrivalHour", "StartHour",
         "FinishHour", "GPU_Demand", "EstimatedDuration_min", "Latency_ms", "MaxLatency_ms", "Delay_h"]
    ]
    return rows


def utilization_table(gpu_occ: np.ndarray, tasks: pd.DataFrame) -> pd.DataFrame:
    gpu = load_gpu().set_index("Region")["Available_GPU"]
    rows = []
    for r, region in enumerate(REGIONS):
        for h in range(WINDOW_H0, WINDOW_H1 + 7):
            rows.append(
                {
                    "Hour": h,
                    "Region": region,
                    "GPU_Usage_GPUh": gpu_occ[r, h],
                    "Available_GPU": gpu[region],
                    "Utilization_%": 100.0 * gpu_occ[r, h] / gpu[region],
                }
            )
    return pd.DataFrame(rows)


def figures(schedule_df: pd.DataFrame, util_df: pd.DataFrame) -> None:
    FIG_DIR.mkdir(exist_ok=True)

    # 甘特图：按区域分面板，展示最后24小时任务
    fig, axes = plt.subplots(6, 1, figsize=(10, 9), sharex=True)
    for ax, region in zip(axes, REGIONS):
        sub = schedule_df[
            (schedule_df["DestRegion"] == region)
            & (schedule_df["StartHour"] <= WINDOW_H1 + 5)
            & (schedule_df["FinishHour"] >= WINDOW_H0)
        ].sort_values(["StartHour", "FinishHour"])
        y = 0
        for _, t in sub.iterrows():
            ax.broken_barh(
                [(t["StartHour"], t["FinishHour"] - t["StartHour"])],
                (y, 0.8),
                facecolors=TYPE_COLORS[t["TaskType"]],
                edgecolor="white",
                linewidth=0.2,
            )
            y += 1
        ax.set_ylabel(region.replace("Region", "R"), rotation=0, ha="right", va="center")
        ax.set_ylim(-0.5, max(1, y + 0.5))
        ax.grid(axis="x", alpha=0.3)
    axes[0].set_xlim(WINDOW_H0 - 0.5, WINDOW_H1 + 6.5)
    axes[-1].set_xlabel("小时")
    fig.suptitle("第2376-2405小时基础调度甘特图（按目标区域）", fontsize=13)
    handles = [
        plt.Rectangle((0, 0), 1, 1, color=c, label=name)
        for name, c in TYPE_COLORS.items()
    ]
    axes[0].legend(handles=handles, loc="upper right", fontsize=8, ncol=3)
    fig.tight_layout(rect=[0, 0, 1, 0.98])
    fig.savefig(FIG_DIR / "q1_gantt.png", dpi=150)
    plt.close(fig)

    # 区域GPU利用率
    fig, ax = plt.subplots(figsize=(10, 4.6))
    pv = util_df.pivot_table(index="Hour", columns="Region", values="Utilization_%", fill_value=0)[REGIONS]
    pv.plot(ax=ax, lw=1.4)
    ax.set_title("第2376-2405小时各区域 GPU 利用率")
    ax.set_xlabel("小时")
    ax.set_ylabel("利用率（%）")
    ax.axvspan(WINDOW_H0, WINDOW_H1, color="gray", alpha=0.12)
    ax.text(WINDOW_H0 + 0.2, ax.get_ylim()[1] * 0.95, "主时域最后24小时", fontsize=9)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "q1_gpu_utilization.png", dpi=150)
    plt.close(fig)


def run() -> dict:
    tasks = prepare_tasks()
    schedule, gpu_occ, ai_it = schedule_window(tasks)
    sched_df = build_output(schedule, tasks)
    util_df = utilization_table(gpu_occ, tasks)
    save_table(sched_df, "q1_schedule")
    save_table(util_df, "q1_gpu_utilization")
    figures(sched_df, util_df)

    # 时限与容量校验
    w = load_tasks().set_index("TaskID")
    sched_df["LatestFinishHour"] = sched_df["TaskID"].map(lambda i: w.loc[i, "LatestFinishHour"])
    summary = {
        "window_tasks": int(len(schedule)),
        "migrated": int((sched_df["DestRegion"] != sched_df["SourceRegion"]).sum()),
        "max_delay_h": float(sched_df["Delay_h"].max()),
        "avg_delay_h": float(sched_df["Delay_h"].mean()),
        "latency_violations": int((sched_df["Latency_ms"] > sched_df["MaxLatency_ms"] + 1e-9).sum()),
        "deadline_violations": int((sched_df["FinishHour"] > sched_df["LatestFinishHour"] + 1e-9).sum()),
        "peak_util_%": float(util_df["Utilization_%"].max()),
        "avg_util_%": float(util_df[util_df["Hour"] <= WINDOW_H1]["Utilization_%"].mean()),
    }
    save_json(summary, "q1_schedule_summary")
    print(json.dumps(summary, ensure_ascii=False, indent=1))
    return summary


if __name__ == "__main__":
    run()
