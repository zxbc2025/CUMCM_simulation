# -*- coding: utf-8 -*-
"""
问题3：储能协同优化模型（给定任务负荷）。

给定 IT 负荷 = Baseline_AI_IT_Load + NonAI_IT_Load，
以小时为粒度建立每个区域的线性规划：
- 决策变量：购电、售电、可再生直接消纳、可再生/电网充电、放电、弃电、SOC；
- 约束：功率平衡、可再生分配平衡、SOC递推与上下限、充放电功率、购售电边界、
       期末 SOC 不低于初始 SOC；
- 目标：电费成本最小 / 成本+峰值惩罚 / 成本+平抑惩罚 / 含碳成本。
"""
from __future__ import annotations

import json

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.optimize import linprog

from common import (
    FIG_DIR,
    H_END,
    OUT_DIR,
    REGIONS,
    energy_dataframe,
    load_gpu,
    load_storage,
    save_json,
    save_table,
)

plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei"]
plt.rcParams["axes.unicode_minus"] = False

N = H_END + 1
# 变量块顺序
IDX = {"GP": 0, "GS": 1, "DRC": 2, "RC": 3, "GC": 4, "DIS": 5, "CUR": 6, "SOC": 7}
NV = 8


def fixed_load(region: str) -> tuple[np.ndarray, np.ndarray]:
    """给定 IT 负荷（MW）与设施侧总负荷（MW）。"""
    rt = energy_dataframe()
    gpu = load_gpu().set_index("Region")
    sub = rt[rt["Region"] == region].sort_values("Hour").reset_index(drop=True)
    it = (sub["Baseline_AI_IT_Load_MW"].to_numpy() + sub["NonAI_IT_Load_MW"].to_numpy())
    pue = float(gpu.loc[region, "PUE"])
    return it, it * pue


def params(region: str) -> dict:
    rt = energy_dataframe()
    st = load_storage().set_index("Region")
    sub = rt[rt["Region"] == region].sort_values("Hour").reset_index(drop=True)
    return {
        "price": sub["ElectricityPrice_CNY_per_MWh"].to_numpy(),
        "sell_price": sub["SellPrice_CNY_per_MWh"].to_numpy(),
        "carbon": sub["CarbonIntensity_tCO2_per_MWh"].to_numpy(),
        "avail": sub["AvailableRenewable_MW"].to_numpy(),
        "cap": float(st.loc[region, "StorageCapacity_MWh"]),
        "min_soc": float(st.loc[region, "MinSOC_MWh"]),
        "init_soc": float(st.loc[region, "InitialSOC_MWh"]),
        "max_chg": float(st.loc[region, "MaxChargePower_MW"]),
        "max_dis": float(st.loc[region, "MaxDischargePower_MW"]),
        "eff_c": float(st.loc[region, "ChargeEfficiency"]),
        "eff_d": float(st.loc[region, "DischargeEfficiency"]),
        "sell_limit": float(st.loc[region, "SellLimit_MW"]),
        "max_import": float(st.loc[region, "MaxGridImport_MW"]),
        "max_export": float(st.loc[region, "MaxGridExport_MW"]),
    }


def _var_blocks(n_extra: int = 0) -> tuple[np.ndarray, np.ndarray]:
    base = NV * N
    all_idx = np.arange(N * NV + n_extra)
    return all_idx[: base].reshape(N, NV), all_idx[base:]


def solve_region_lp(
    region: str,
    objective: str = "cost",
    carbon_price: float = 0.0,
    lam_peak: float = 0.0,
    lam_dev: float = 0.0,
    ref_gp: float | None = None,
    tl: np.ndarray | None = None,
    price_override: dict | None = None,
    renew_scale: float = 1.0,
) -> dict:
    """求解单区域储能LP（独立构造A_eq/A_ub）。"""
    if tl is None:
        _, tl = fixed_load(region)
    tl = np.asarray(tl, dtype=float)
    p = params(region)
    if price_override:
        p["price"] = np.full(N, price_override[region])
    p["avail"] = p["avail"] * renew_scale
    if ref_gp is None:
        rt = energy_dataframe()
        ref_gp = float(rt[rt["Region"] == region]["GridPurchase_MW"].mean())
    p["ref_gp"] = ref_gp
    need_peak = lam_peak > 0
    need_smooth = lam_dev > 0
    n_extra = (1 if need_peak else 0) + (2 * N if need_smooth else 0)
    var_idx, extra = _var_blocks(n_extra)
    n_var = NV * N + n_extra
    peak_offset = 1 if need_peak else 0

    eq_rows, eq_cols, eq_vals, b_eq = [], [], [], []
    ub_rows, ub_cols, ub_vals, b_ub = [], [], [], []

    def add(rows, cols, vals, b, coefs, rhs):
        for c, v in coefs:
            rows.append(len(b)); cols.append(v); vals.append(c)
        b.append(rhs)

    for h in range(N):
        v = var_idx[h]
        add(eq_rows, eq_cols, eq_vals, b_eq,
            [(1, v[IDX["DRC"]]), (1, v[IDX["RC"]]), (1, v[IDX["GS"]]), (1, v[IDX["CUR"]])],
            p["avail"][h])
        add(eq_rows, eq_cols, eq_vals, b_eq,
            [(1, v[IDX["GP"]]), (1, v[IDX["DRC"]]), (1, v[IDX["DIS"]]), (-1, v[IDX["GC"]])],
            tl[h])
        soc_coefs = [(1, v[IDX["SOC"]])]
        if h > 0:
            soc_coefs.append((-1, var_idx[h - 1][IDX["SOC"]]))
        soc_coefs += [(-p["eff_c"], v[IDX["RC"]]), (-p["eff_c"], v[IDX["GC"]]),
                      (1 / p["eff_d"], v[IDX["DIS"]])]
        add(eq_rows, eq_cols, eq_vals, b_eq, soc_coefs, p["init_soc"] if h == 0 else 0.0)
        add(ub_rows, ub_cols, ub_vals, b_ub,
            [(1, v[IDX["RC"]]), (1, v[IDX["GC"]])], p["max_chg"])
        add(ub_rows, ub_cols, ub_vals, b_ub, [(1, v[IDX["DIS"]])], p["max_dis"])
        if need_peak:
            add(ub_rows, ub_cols, ub_vals, b_ub, [(1, v[IDX["GP"]]), (-1, extra[0])], 0.0)
        if need_smooth:
            add(eq_rows, eq_cols, eq_vals, b_eq,
                [(1, v[IDX["GP"]]), (-1, extra[peak_offset + 2 * h]), (1, extra[peak_offset + 2 * h + 1])],
                ref_gp)
    add(ub_rows, ub_cols, ub_vals, b_ub, [(-1, var_idx[N - 1][IDX["SOC"]])], -p["init_soc"])

    A_eq = sparse.coo_matrix((eq_vals, (eq_rows, eq_cols)), shape=(len(b_eq), n_var)).tocsr()
    A_ub = sparse.coo_matrix((ub_vals, (ub_rows, ub_cols)), shape=(len(b_ub), n_var)).tocsr()

    c = np.zeros(n_var)
    for h in range(N):
        v = var_idx[h]
        c[v[IDX["GP"]]] = p["price"][h] + carbon_price * p["carbon"][h]
        c[v[IDX["GS"]]] = -p["sell_price"][h]
    if need_peak:
        c[extra[0]] = lam_peak
    if need_smooth:
        c[extra[peak_offset::2]] = lam_dev
        c[extra[peak_offset + 1::2]] = lam_dev

    bounds = []
    base_bounds = [
        (0, p["max_import"]),
        (0, min(p["sell_limit"], p["max_export"])),
        (0, None), (0, None), (0, None),
        (0, p["max_dis"]), (0, None),
        (p["min_soc"], p["cap"]),
    ]
    bounds = base_bounds * N
    if need_peak:
        bounds += [(0, None)]
    if need_smooth:
        bounds += [(0, None)] * (2 * N)

    res = linprog(
        c,
        A_ub=A_ub,
        b_ub=np.array(b_ub),
        A_eq=A_eq,
        b_eq=np.array(b_eq),
        bounds=bounds,
        method="highs",
    )
    if not res.success:
        raise RuntimeError(f"{region} {objective} LP失败: {res.message}")
    x = res.x
    return extract_result(region, x, var_idx, extra, p, tl, objective, carbon_price, lam_peak, lam_dev)


def extract_result(
    region: str,
    x: np.ndarray,
    var_idx: np.ndarray,
    extra: np.ndarray,
    p: dict,
    tl: np.ndarray,
    objective: str,
    carbon_price: float,
    lam_peak: float,
    lam_dev: float,
) -> dict:
    hours = np.arange(N)
    cols = {k: x[var_idx[:, IDX[k]]] for k in IDX}
    df = pd.DataFrame(
        {
            "Hour": hours,
            "Region": region,
            "GridPurchase_MW": cols["GP"],
            "GridSell_MW": cols["GS"],
            "RenewableDirect_MW": cols["DRC"],
            "RenewableCharge_MW": cols["RC"],
            "GridCharge_MW": cols["GC"],
            "DischargePower_MW": cols["DIS"],
            "Curtailment_MW": cols["CUR"],
            "SOC_MWh": cols["SOC"],
            "Total_Load_MW": tl,
            "Price": p["price"],
        }
    )
    gp = cols["GP"]
    gs = cols["GS"]
    net = gp - gs
    cost = float(np.sum(gp * p["price"] - gs * p["sell_price"]))
    carbon = float(np.sum(gp * p["carbon"]))
    renew_used = p["avail"] - cols["CUR"]
    metrics = {
        "region": region,
        "objective": objective,
        "cost_万元": cost / 1e4,
        "carbon_t": carbon,
        "peak_net_import_MW": float(max(0.0, net.max())),
        "net_import_cv": float(net.std() / max(1e-9, abs(net.mean()))),
        "renewable_util_%": 100.0 * float(np.sum(renew_used)) / max(1e-9, float(np.sum(p["avail"]))),
        "charge_GWh": float(np.sum(cols["RC"] + cols["GC"])) / 1e3,
        "discharge_GWh": float(np.sum(cols["DIS"])) / 1e3,
        "final_soc_MWh": float(cols["SOC"][-1]),
        "carbon_price": carbon_price,
        "lam_peak": lam_peak,
        "lam_dev": lam_dev,
        "status": "optimal",
    }
    return {"metrics": metrics, "df": df}


def baseline_metrics(region: str) -> dict:
    rt = energy_dataframe()
    sub = rt[rt["Region"] == region].sort_values("Hour")
    gp = sub["GridPurchase_MW"].to_numpy()
    gs = sub["GridSell_MW"].to_numpy()
    net = gp - gs
    return {
        "region": region,
        "objective": "baseline",
        "cost_万元": float(np.sum(gp * sub["ElectricityPrice_CNY_per_MWh"] - gs * sub["SellPrice_CNY_per_MWh"])) / 1e4,
        "carbon_t": float(np.sum(gp * sub["CarbonIntensity_tCO2_per_MWh"])),
        "peak_net_import_MW": float(max(0.0, net.max())),
        "net_import_cv": float(net.std() / max(1e-9, abs(net.mean()))),
        "renewable_util_%": 100.0
        * float(np.sum(sub["UsedRenewable_MW"] + sub["RenewableCharge_MW"] + sub["GridSell_MW"]))
        / max(1e-9, float(np.sum(sub["AvailableRenewable_MW"]))),
        "charge_GWh": float(np.sum(sub["ChargePower_MW"])) / 1e3,
        "discharge_GWh": float(np.sum(sub["DischargePower_MW"])) / 1e3,
        "final_soc_MWh": float(sub["SOC_MWh"].iloc[-1]),
        "status": "reference",
    }


def no_storage_metrics(region: str) -> dict:
    """无储能（充放电为0）可再生优先闭式结算。"""
    it, tl = fixed_load(region)
    p = params(region)
    d = p["avail"] - tl
    drc = np.minimum(p["avail"], tl)
    gs = np.minimum(np.maximum(0.0, d), min(p["sell_limit"], p["max_export"]))
    cur = np.maximum(0.0, p["avail"] - drc - gs)
    gp = np.maximum(0.0, tl - drc)
    net = gp - gs
    return {
        "region": region,
        "objective": "no_storage",
        "cost_万元": float(np.sum(gp * p["price"] - gs * p["sell_price"])) / 1e4,
        "carbon_t": float(np.sum(gp * p["carbon"])),
        "peak_net_import_MW": float(max(0.0, net.max())),
        "net_import_cv": float(net.std() / max(1e-9, abs(net.mean()))),
        "renewable_util_%": 100.0 * float(np.sum(p["avail"] - cur)) / max(1e-9, float(np.sum(p["avail"]))),
        "charge_GWh": 0.0,
        "discharge_GWh": 0.0,
        "final_soc_MWh": p["init_soc"],
        "status": "closed_form",
    }


def run() -> dict:
    scenarios = [
        ("cost", 0.0, 0.0, 0.0),
        ("carbon100", 100.0, 0.0, 0.0),
        ("peak", 0.0, 20000.0, 0.0),
        ("smooth", 0.0, 0.0, 80.0),
    ]
    summary_rows = []
    dispatch_rows = []
    for region in REGIONS:
        summary_rows.append(baseline_metrics(region))
        summary_rows.append(no_storage_metrics(region))
        for name, cp, lp, ld in scenarios:
            out = solve_region_lp(region, name, cp, lp, ld)
            summary_rows.append(out["metrics"])
            disp = out["df"]
            disp["Scenario"] = name
            dispatch_rows.append(disp)
    summary = pd.DataFrame(summary_rows)
    dispatch = pd.concat(dispatch_rows, ignore_index=True)
    save_table(summary, "q3_summary")
    save_table(dispatch, "q3_storage_dispatch")
    save_json(summary.round(4).to_dict(orient="records"), "q3_summary_json")
    figures(summary, dispatch)
    totals = summary.groupby("objective")[
        ["cost_万元", "carbon_t", "peak_net_import_MW", "net_import_cv", "renewable_util_%", "charge_GWh", "discharge_GWh"]
    ].mean().round(3)
    save_table(totals.reset_index(), "q3_totals")
    print(totals.to_string())
    return {"totals": totals.to_dict(), "summary": summary.to_dict(orient="records")}


def figures(summary: pd.DataFrame, dispatch: pd.DataFrame) -> None:
    FIG_DIR.mkdir(exist_ok=True)
    order = ["baseline", "no_storage", "cost", "carbon100", "peak", "smooth"]
    summary["objective"] = pd.Categorical(summary["objective"], categories=order, ordered=True)
    agg = summary.groupby("objective", observed=True).mean(numeric_only=True).loc[order]

    fig, axes = plt.subplots(1, 3, figsize=(12, 3.8))
    axes[0].bar(agg.index, agg["cost_万元"] / 1e4, color="#4C72B0")
    axes[0].set_title("平均运行成本（亿元）")
    axes[0].tick_params(axis="x", rotation=30)
    axes[1].bar(agg.index, agg["carbon_t"], color="#C44E52")
    axes[1].set_title("平均碳排放（tCO2）")
    axes[1].tick_params(axis="x", rotation=30)
    axes[2].bar(agg.index, agg["peak_net_import_MW"], color="#DD8452")
    axes[2].set_title("平均峰值净购电（MW）")
    axes[2].tick_params(axis="x", rotation=30)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "q3_metrics_bar.png", dpi=150)
    plt.close(fig)

    # 示例周：RegionD/E 的 SOC 与充放电
    fig, axes = plt.subplots(2, 1, figsize=(10, 6))
    for ax, region in zip(axes, ["RegionD", "RegionE"]):
        sub = dispatch[(dispatch.Region == region) & (dispatch.Scenario == "cost")]
        hrs = sub[(sub.Hour >= 1000) & (sub.Hour <= 1168)]
        ax.plot(hrs["Hour"], hrs["SOC_MWh"], color="#4C72B0", label="SOC")
        ax.plot(hrs["Hour"], hrs["RenewableCharge_MW"] + hrs["GridCharge_MW"], color="#55A868", label="充电功率")
        ax.plot(hrs["Hour"], hrs["DischargePower_MW"], color="#C44E52", label="放电功率")
        ax.set_title(f"{region} 储能优化结果（小时1000-1168）")
        ax.set_xlabel("小时")
        ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "q3_storage_dispatch.png", dpi=150)
    plt.close(fig)

    # 净购电对比：RegionD 示例周
    fig, ax = plt.subplots(figsize=(10, 4.2))
    rt = energy_dataframe()
    for scenario, style in [("baseline", "k--"), ("cost", "#4C72B0"), ("peak", "#DD8452")]:
        if scenario == "baseline":
            sub = rt[rt.Region == "RegionD"]
            y = sub["NetGridImport_MW"].to_numpy()
        else:
            sub = dispatch[(dispatch.Region == "RegionD") & (dispatch.Scenario == scenario)]
            y = (sub["GridPurchase_MW"] - sub["GridSell_MW"]).to_numpy()
        mask = (np.arange(N) >= 1000) & (np.arange(N) <= 1168)
        ax.plot(np.arange(N)[mask], y[mask], style, label=scenario, lw=1.4)
    ax.set_title("RegionD 净购电功率对比（小时1000-1168）")
    ax.set_xlabel("小时")
    ax.set_ylabel("MW")
    ax.legend()
    fig.tight_layout()
    fig.savefig(FIG_DIR / "q3_net_import.png", dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    run()
