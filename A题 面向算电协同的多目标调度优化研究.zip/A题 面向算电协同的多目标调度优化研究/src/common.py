# -*- coding: utf-8 -*-
"""
A题公共数据层与统一计算口径。

所有结果指标均按附件1的"建模边界统一口径"计算：
- AI_IT_Load(r,t) = sum GPU_Demand * Overlap * GPU_Power(TaskType)
- IT_Load = NonAI_IT_Load + AI_IT_Load; Total_Load = IT_Load * PUE
- GridPurchase + AvailableRenewable + DischargePower
      = Total_Load + ChargePower + GridSell + Curtailment
- CarbonEmission = GridPurchase * CarbonIntensity
- 电费 = GridPurchase * ElectricityPrice - GridSell * SellPrice
"""
from __future__ import annotations

import functools
import math
from pathlib import Path

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"
OUT_DIR = PROJECT_ROOT / "results"
TABLE_DIR = PROJECT_ROOT / "tables"
FIG_DIR = PROJECT_ROOT / "figures"
MODEL_DIR = PROJECT_ROOT / "modeling"

REGIONS = ["RegionA", "RegionB", "RegionC", "RegionD", "RegionE", "RegionF"]
TYPES = ["RealTimeInference", "BatchInference", "AITraining"]
FLEX_TYPES = ["BatchInference", "AITraining"]
H0, H_END = 0, 2406          # 电力与储能结算时域
MAIN_H0, MAIN_H1 = 0, 2399    # 任务到达主时域
TAIL_H0, TAIL_H1 = 2400, 2405  # 收尾时域


@functools.lru_cache(maxsize=1)
def load_gpu() -> pd.DataFrame:
    return pd.read_excel(DATA_DIR / "GPU_information.xlsx", sheet_name=0)


@functools.lru_cache(maxsize=1)
def load_latency() -> pd.DataFrame:
    return pd.read_excel(DATA_DIR / "network_latency.xlsx", sheet_name=0)


@functools.lru_cache(maxsize=1)
def load_power_mapping() -> pd.DataFrame:
    return pd.read_excel(DATA_DIR / "power_mapping.xlsx", sheet_name=0)


@functools.lru_cache(maxsize=1)
def load_storage() -> pd.DataFrame:
    return pd.read_excel(DATA_DIR / "storage_information.xlsx", sheet_name=0)


@functools.lru_cache(maxsize=1)
def load_tasks() -> pd.DataFrame:
    return pd.read_excel(DATA_DIR / "workload_trace.xlsx", sheet_name=0)


@functools.lru_cache(maxsize=1)
def load_region_time() -> pd.DataFrame:
    return pd.read_excel(DATA_DIR / "region_time_data.xlsx", sheet_name=0)


def latency_matrix() -> np.ndarray:
    """返回 6x6 时延矩阵，行=源区域，列=目标区域。"""
    lat = load_latency()
    m = np.zeros((len(REGIONS), len(REGIONS)))
    for _, r in lat.iterrows():
        m[REGIONS.index(r["FromRegion"]), REGIONS.index(r["ToRegion"])] = r["NetworkLatency_ms"]
    return m


def gpu_power(type_name: str) -> float:
    pm = load_power_mapping().set_index("TaskType")["GPU_Power_MW_per_EquivalentGPU"]
    return float(pm[type_name])


def prepare_tasks() -> pd.DataFrame:
    """为任务表补充持续小时、GPU小时、最晚开工小时等派生字段。"""
    w = load_tasks().copy()
    w["dur_h"] = w["EstimatedDuration_min"] / 60.0
    w["gpu_h"] = w["GPU_Demand"] * w["dur_h"]
    w["is_flex"] = w["TaskType"].isin(FLEX_TYPES)
    # 任务最迟在时点2406前完成，即 finish <= 2406，不占用第2406小时
    w["latest_start"] = np.floor(2406.0 - w["dur_h"] + 1e-9).astype(int)
    w["latest_start"] = w[["latest_start", "LatestFinishHour"]].min(axis=1).astype(int)
    w["power_mw"] = w["TaskType"].map(gpu_power)
    return w


def feasible_regions_for_task(lat: np.ndarray, src: str, max_latency: float) -> list[str]:
    si = REGIONS.index(src)
    return [REGIONS[j] for j in range(len(REGIONS)) if lat[si, j] <= max_latency + 1e-9]


def overlap_for_start(s: float, dur_h: float) -> tuple[np.ndarray, np.ndarray]:
    """整数小时开工时，任务在 [s, s+dur) 与各小时的占用小时数。"""
    h0 = int(math.floor(s))
    h1 = int(math.ceil(s + dur_h))
    hrs = np.arange(h0, h1 + 1)
    ov = np.maximum(0.0, np.minimum(hrs + 1.0, s + dur_h) - np.maximum(hrs, s))
    return hrs, ov


def schedule_to_load(
    schedule: list[dict], n_hours: int = H_END + 1
) -> tuple[np.ndarray, np.ndarray]:
    """
    schedule: [dict(task_id, region, start_h, dur_h)]。
    返回 ai_it[6,n_hours] 与 gpu_occ[6,n_hours]。
    """
    ai_it = np.zeros((len(REGIONS), n_hours))
    gpu_occ = np.zeros((len(REGIONS), n_hours))
    pm = load_power_mapping().set_index("TaskType")["GPU_Power_MW_per_EquivalentGPU"]
    w = load_tasks().set_index("TaskID")
    for item in schedule:
        row = w.loc[item["task_id"]]
        r = REGIONS.index(item["region"])
        hrs, ov = overlap_for_start(item["start_h"], item["dur_h"])
        valid = (hrs >= 0) & (hrs < n_hours)
        hrs, ov = hrs[valid], ov[valid]
        gpu_occ[r, hrs] += row["GPU_Demand"] * ov
        ai_it[r, hrs] += row["GPU_Demand"] * ov * float(pm[row["TaskType"]])
    return ai_it, gpu_occ


def energy_dataframe() -> pd.DataFrame:
    """区域-小时基础参数表（含基准AI负荷与基准储能结果）。"""
    rt = load_region_time().copy()
    rt["Region"] = rt["Region"].astype(str)
    rt = rt[(rt["Hour"] >= H0) & (rt["Hour"] <= H_END)].copy()
    return rt


def _renewable_first_dispatch(ai_it: np.ndarray) -> pd.DataFrame:
    """
    在给定AI IT负荷与基准储能充放/外送条件下，按"可再生优先"原则
    重新结算购电、弃电、碳排与电费。
    """
    rt = energy_dataframe()
    gpu = load_gpu().set_index("Region")
    rows = []
    for ridx, region in enumerate(REGIONS):
        sub = rt[rt["Region"] == region].sort_values("Hour").reset_index(drop=True)
        pue = float(gpu.loc[region, "PUE"])
        tl = (sub["NonAI_IT_Load_MW"].to_numpy() + ai_it[ridx]) * pue
        avail = sub["AvailableRenewable_MW"].to_numpy()
        chg = sub["ChargePower_MW"].to_numpy()
        dis = sub["DischargePower_MW"].to_numpy()
        gs_base = sub["GridSell_MW"].to_numpy()
        # 最小购电优先：先消耗可再生能源与储能放电
        gp = np.maximum(0.0, tl + chg + gs_base - avail - dis)
        cur = np.maximum(0.0, avail + dis - tl - chg - gs_base + gp)
        price = sub["ElectricityPrice_CNY_per_MWh"].to_numpy()
        carbon_i = sub["CarbonIntensity_tCO2_per_MWh"].to_numpy()
        sell_price = sub["SellPrice_CNY_per_MWh"].to_numpy()
        renew_used = avail - cur
        tmp = pd.DataFrame(
            {
                "Hour": sub["Hour"].to_numpy(),
                "Region": region,
                "AI_IT_Load_MW": ai_it[ridx],
                "Total_Load_MW": tl,
                "GridPurchase_MW": gp,
                "GridSell_MW": gs_base,
                "Curtailment_MW": cur,
                "RenewableUsed_MW": renew_used,
                "CarbonEmission_tCO2": gp * carbon_i,
                "ElectricityCost_CNY": gp * price - gs_base * sell_price,
                "Price": price,
                "CarbonIntensity": carbon_i,
                "AvailableRenewable_MW": avail,
                "ChargePower_MW": chg,
                "DischargePower_MW": dis,
            }
        )
        rows.append(tmp)
    return pd.concat(rows, ignore_index=True)


def baseline_ai_it_load() -> np.ndarray:
    """从附件直接取出基准AI IT负荷 [6, 2407]。"""
    rt = energy_dataframe()
    arr = np.zeros((len(REGIONS), H_END + 1))
    for ridx, region in enumerate(REGIONS):
        sub = rt[rt["Region"] == region].sort_values("Hour")
        arr[ridx, sub["Hour"].to_numpy()] = sub["Baseline_AI_IT_Load_MW"].to_numpy()
    return arr


def metrics_from_ai_it(ai_it: np.ndarray, label: str = "") -> dict:
    """由AI IT负荷矩阵计算全系统指标（可再生优先口径 + 基准储能）。"""
    df = _renewable_first_dispatch(ai_it)
    total = {
        "label": label,
        "electricity_cost_万元": float(df["ElectricityCost_CNY"].sum()) / 1e4,
        "carbon_t": float(df["CarbonEmission_tCO2"].sum()),
        "renewable_util_%": 100.0
        * float(df["RenewableUsed_MW"].sum())
        / max(1e-9, float(df["AvailableRenewable_MW"].sum())),
        "grid_purchase_GWh": float(df["GridPurchase_MW"].sum()) / 1e3,
        "grid_sell_GWh": float(df["GridSell_MW"].sum()) / 1e3,
        "peak_net_import_MW": float((df["GridPurchase_MW"] - df["GridSell_MW"]).max()),
        "ai_it_energy_MWh": float(df["AI_IT_Load_MW"].sum()),
    }
    return total


def schedule_metrics(
    schedule: list[dict], tasks: pd.DataFrame | None = None, label: str = ""
) -> dict:
    """调度方案综合指标（含时延、迁移、开工延迟与能量指标）。"""
    if tasks is None:
        tasks = prepare_tasks()
    ai_it, gpu_occ = schedule_to_load(schedule)
    m = metrics_from_ai_it(ai_it, label)
    idx = {t["task_id"]: t for t in schedule}
    rows = tasks[tasks["TaskID"].isin(idx)].copy()
    rows["dest"] = rows["TaskID"].map(lambda i: idx[i]["region"])
    rows["start"] = rows["TaskID"].map(lambda i: idx[i]["start_h"])
    rows["lat"] = [
        latency_matrix()[REGIONS.index(s), REGIONS.index(d)]
        for s, d in zip(rows["SourceRegion"], rows["dest"])
    ]
    rows["delay_h"] = rows["start"] - rows["ArrivalHour"]
    m["migrated_n"] = int((rows["dest"] != rows["SourceRegion"]).sum())
    m["migrate_rate_%"] = 100.0 * m["migrated_n"] / len(rows)
    m["avg_latency_ms"] = float(np.average(rows["lat"], weights=rows["gpu_h"]))
    m["avg_delay_h"] = float(np.average(rows["delay_h"], weights=rows["gpu_h"]))
    m["total_gpu_h"] = float(rows["gpu_h"].sum())
    m["max_gpu_util_%"] = float(
        (gpu_occ.sum(axis=0) / sum(load_gpu()["Available_GPU"])).max() * 100
    )
    return m


def baseline_schedule_metrics() -> dict:
    """基准调度（本地、到达即开工）指标。"""
    return metrics_from_ai_it(baseline_ai_it_load(), "baseline")


def save_table(df: pd.DataFrame, name: str) -> None:
    TABLE_DIR.mkdir(exist_ok=True)
    df.to_csv(TABLE_DIR / f"{name}.csv", index=False, encoding="utf-8-sig")


def save_json(obj, name: str) -> None:
    import json

    OUT_DIR.mkdir(exist_ok=True)
    with open(OUT_DIR / f"{name}.json", "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1, default=float)
