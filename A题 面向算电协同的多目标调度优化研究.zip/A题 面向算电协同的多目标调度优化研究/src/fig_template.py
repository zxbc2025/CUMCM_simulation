# -*- coding: utf-8 -*-
"""按优秀论文C023风格生成系统示意图与各问流程图。"""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Rectangle

from common import FIG_DIR

plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei"]
plt.rcParams["axes.unicode_minus"] = False


def _box(ax, x, y, w, h, text, fc="#DEEBF7", ec="#08306B", fs=10):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.008",
                                fc=fc, ec=ec, lw=1.2, mutation_aspect=1))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs)


def _arrow(ax, p0, p1, color="#08306B", lw=1.5, style="-|>"):
    ax.add_patch(FancyArrowPatch(p0, p1, arrowstyle=style, mutation_scale=12,
                                 color=color, lw=lw))


def system_diagram() -> None:
    fig, ax = plt.subplots(figsize=(11, 6.2))
    ax.axis("off")
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6)
    ax.set_title("算电协同系统示意图", fontsize=14)
    # 东部
    _box(ax, 0.3, 4.4, 2.6, 1.2, "RegionA 东部\n实时业务中心", "#C6DBEF")
    _box(ax, 3.3, 4.4, 2.6, 1.2, "RegionB 东部\n综合业务中心", "#C6DBEF")
    _box(ax, 6.3, 4.4, 2.6, 1.2, "RegionC 东部\n边缘算力节点", "#C6DBEF")
    # 西部
    _box(ax, 0.3, 1.0, 2.6, 1.2, "RegionD 西部\n算力中心", "#9ECAE1")
    _box(ax, 3.3, 1.0, 2.6, 1.2, "RegionE 光伏\n资源富集", "#FDEFD0")
    _box(ax, 6.3, 1.0, 2.6, 1.2, "RegionF 风电\n资源富集", "#D7F0DB")
    # 资源与储能
    _box(ax, 0.3, 0.15, 1.2, 0.6, "电网购售电", "#F0F0F0")
    _box(ax, 2.0, 0.15, 1.2, 0.6, "新能源\n光伏/风电", "#FDEBD0")
    _box(ax, 3.7, 0.15, 1.2, 0.6, "储能系统\n充放电", "#E2EFDA")
    _box(ax, 5.4, 0.15, 1.2, 0.6, "AI任务\n实时/批量/训练", "#DEEBF7")
    _box(ax, 7.1, 0.15, 2.2, 0.6, "广域网络\n时延约束", "#EDEDED")
    for x in [1.6, 4.6, 7.6]:
        _arrow(ax, (x + 1.0, 4.4), (x + 0.2, 2.2))
        _arrow(ax, (x + 0.2, 2.2), (x + 1.0, 4.4))
    _arrow(ax, (1.6, 0.75), (1.6, 1.0))
    _arrow(ax, (4.6, 0.75), (4.6, 1.0))
    _arrow(ax, (7.6, 0.75), (7.6, 1.0))
    ax.text(5.0, 3.3, "任务迁移：低时延优先 / 低成本低碳优先", ha="center", fontsize=11,
            bbox=dict(boxstyle="round", fc="#FFF7E6", ec="#D9822B"))
    fig.tight_layout()
    fig.savefig(FIG_DIR / "system_diagram.png", dpi=150)
    plt.close(fig)


def problem_flow(name: str, title: str, steps: list[str]) -> None:
    fig, ax = plt.subplots(figsize=(9.5, 5.6))
    ax.axis("off")
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6)
    ax.set_title(title, fontsize=13)
    n = len(steps)
    for i, s in enumerate(steps):
        x = 0.5 + (i % 4) * 2.4
        y = 4.6 - (i // 4) * 2.2
        _box(ax, x, y, 2.0, 1.4, s, fs=9.5)
        if i % 4 < 3 and i + 1 < n and i // 4 == (i + 1) // 4:
            _arrow(ax, (x + 2.0, y + 0.7), (x + 2.4, y + 0.7))
        elif i + 1 < n:
            _arrow(ax, (x + 1.0, y), (x + 1.0, y - 0.8), style="-|>")
            ax.plot([x + 1.0, x + 3.4], [y - 0.8, y - 0.8], color="#08306B", lw=1.5)
            ax.plot([x + 3.4, x + 3.4], [y - 0.8, y - 1.4], color="#08306B", lw=1.5)
    fig.tight_layout()
    fig.savefig(FIG_DIR / f"flow_{name}.png", dpi=150)
    plt.close(fig)


def main() -> None:
    system_diagram()
    problem_flow("q1", "问题一流程图", [
        "数据清洗与聚合\n（区域×类型×小时）",
        "统计分析\nGPU需求/GPU小时",
        "季节均值预测模型\n训练0-2351/验证2352-2375",
        "重训0-2375并预测\n2376-2399",
        "基准占用推演\n0-2375本地调度",
        "最后24小时任务调度\n实时固定+弹性最早可行",
        "容量/功率/时延校验\n甘特图与利用率",
        "结果输出\n调度方案与预测误差",
    ])
    problem_flow("q2", "问题二流程图", [
        "读入任务与电力参数\n统一口径预处理",
        "计算可再生余量\n价格/碳/绿色信号",
        "实时任务固定\n到达小时开工",
        "弹性任务按GPU小时\n降序处理",
        "候选(区域,小时)\n可行性+代理目标评分",
        "容量/功率/时延\n安全余量校验",
        "统一口径结算\n成本/碳排/消纳/时延",
        "结果对比与策略\n迁移矩阵/负荷曲线",
    ])
    problem_flow("q3", "问题三流程图", [
        "给定任务负荷\nBaseline AI+NonAI",
        "储能LP变量\n购售电/充放电/SOC",
        "功率平衡约束\n可再生分配约束",
        "SOC递推与边界\n期末SOC约束",
        "成本最优/碳价\n峰值/平抑四场景",
        "HiGHS逐区域求解\n全部optimal",
        "与基准/无储能对比\n成本/碳排/峰值/CV",
        "SOC与充放电曲线\n影响分析",
    ])
    problem_flow("q4", "问题四流程图", [
        "统一目标与权重\n六项指标权衡",
        "外层：碳感知调度\n任务迁移+开工时段",
        "生成AI IT负荷\n逐区域逐小时",
        "内层：储能LP\n购售电与充放电",
        "边际电价/绿色信号\n反馈外层",
        "碳价场景\n0/100/200元/t",
        "电价机制与\n新能源波动场景",
        "联合指标与\n多目标权衡输出",
    ])
    print("template figures done")


if __name__ == "__main__":
    main()
