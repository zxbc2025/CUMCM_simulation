# -*- coding: utf-8 -*-
"""
问题2：碳感知任务调度模型（0-2399小时实际任务 + 收尾时域）。

求解方法：滚动时域贪心-修正启发式
- 实时推理：到达小时开工，目标区域限制在时延可行集；
- 批量推理/AI训练：候选(目标区域, 开工小时)按代理目标排序，
  在GPU容量、IT功率、时延与完成时限全部可行的方案中取最优；
- 代理目标 = 边际购电成本 + 碳成本 + 时延惩罚 - 绿色消纳偏好。

能量指标按附件1统一口径重算（可再生优先 + 基准储能），
并与附件基准（本地到达即开工）对比。
"""
from __future__ import annotations

import json
import time

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from common import (
    FIG_DIR,
    H_END,
    OUT_DIR,
    REGIONS,
    TYPES,
    baseline_ai_it_load,
    energy_dataframe,
    latency_matrix,
    load_gpu,
    prepare_tasks,
    save_json,
    save_table,
    schedule_metrics,
)

plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei"]
plt.rcParams["axes.unicode_minus"] = False


def build_signals(price_override: dict | None = None, renew_scale: float = 1.0):
    """构造逐区域逐小时电价/碳/可再生/余量等信号。"""
    rt = energy_dataframe()
    gpu = load_gpu().set_index("Region")
    n_h = H_END + 1
    price = np.zeros((len(REGIONS), n_h))
    sell = np.zeros((len(REGIONS), n_h))
    carbon = np.zeros((len(REGIONS), n_h))
    avail = np.zeros((len(REGIONS), n_h))
    nonai = np.zeros((len(REGIONS), n_h))
    chg = np.zeros((len(REGIONS), n_h))
    dis = np.zeros((len(REGIONS), n_h))
    gs = np.zeros((len(REGIONS), n_h))
    pue = np.array([gpu.loc[r, "PUE"] for r in REGIONS])
    for ridx, region in enumerate(REGIONS):
        sub = rt[rt["Region"] == region].sort_values("Hour")
        hs = sub["Hour"].to_numpy()
        price[ridx, hs] = sub["ElectricityPrice_CNY_per_MWh"].to_numpy()
        sell[ridx, hs] = sub["SellPrice_CNY_per_MWh"].to_numpy()
        carbon[ridx, hs] = sub["CarbonIntensity_tCO2_per_MWh"].to_numpy()
        avail[ridx, hs] = sub["AvailableRenewable_MW"].to_numpy() * renew_scale
        nonai[ridx, hs] = sub["NonAI_IT_Load_MW"].to_numpy()
        chg[ridx, hs] = sub["ChargePower_MW"].to_numpy()
        dis[ridx, hs] = sub["DischargePower_MW"].to_numpy()
        gs[ridx, hs] = sub["GridSell_MW"].to_numpy()
    if price_override:
        for ridx, region in enumerate(REGIONS):
            price[ridx, :] = price_override[region]
    # 可再生优先口径下的"可再生余量"（可吸收AI负荷而无需购电的空间）
    headroom = avail + dis - nonai * pue[:, None] - chg - gs
    grid_frac = (headroom <= 0).astype(float)
    renew_norm = np.clip(0.6 - carbon, 0.0, 0.4)
    return {
        "price": price,
        "sell": sell,
        "carbon": carbon,
        "avail": avail,
        "headroom": headroom,
        "grid_frac": grid_frac,
        "renew_norm": renew_norm,
        "pue": pue,
        "nonai": nonai,
    }


def _hour_rank(sig: dict, weights: dict) -> list[np.ndarray]:
    """每个(类型功率)下的逐区域小时吸引力排序。"""
    pm = {"RealTimeInference": 0.08, "BatchInference": 0.10, "AITraining": 0.16}
    ranks = []
    for tt in TYPES:
        p = pm[tt]
        base = sig["grid_frac"] * (sig["price"] + weights["c_carbon"] * sig["carbon"]) * p * sig["pue"][:, None]
        bonus = weights["w_renew"] * sig["renew_norm"] * p * sig["pue"][:, None]
        score = base - bonus
        order = np.argsort(score, axis=1)
        ranks.append(order)
    return ranks


def _candidate_hours(
    task: pd.Series,
    ranks: list[np.ndarray],
    dest_idx: int,
    top_k: int = 8,
    near_h: int = 36,
    sample_n: int = 8,
) -> np.ndarray:
    """生成候选开工小时：近期全遍历 + 吸引力Top-K + 均匀抽样。"""
    a = int(task["ArrivalHour"])
    b = int(task["latest_start"])
    if b < a:
        return np.array([], dtype=int)
    width = b - a + 1
    if width <= near_h + top_k + sample_n:
        return np.arange(a, b + 1)
    type_idx = TYPES.index(task["TaskType"])
    order = ranks[type_idx][dest_idx]
    cand = set(np.arange(a, min(b, a + near_h) + 1))
    inwin = order[(order >= a) & (order <= b)]
    cand.update(inwin[:top_k].tolist())
    cand.update(np.linspace(a, b, sample_n, dtype=int).tolist())
    return np.array(sorted(cand), dtype=int)


def schedule_horizon(
    weights: dict,
    renew_scale: float = 1.0,
    price_override: dict | None = None,
    progress: bool = True,
) -> list[dict]:
    """滚动时域启发式调度全部任务。"""
    tasks = prepare_tasks()
    sig = build_signals(price_override, renew_scale)
    ranks = _hour_rank(sig, weights)
    pm = {"RealTimeInference": 0.08, "BatchInference": 0.10, "AITraining": 0.16}
    region_avg = np.zeros((len(TYPES), len(REGIONS)))
    for ti, tt in enumerate(TYPES):
        p = pm[tt]
        for j in range(len(REGIONS)):
            base = sig["grid_frac"][j, :2406] * (
                sig["price"][j, :2406] + weights["c_carbon"] * sig["carbon"][j, :2406]
            ) * p * sig["pue"][j]
            bonus = weights["w_renew"] * sig["renew_norm"][j, :2406] * p * sig["pue"][j]
            region_avg[ti, j] = float(np.mean(base - bonus))
    gpu = load_gpu().set_index("Region")
    avail_gpu = np.array([gpu.loc[r, "Available_GPU"] for r in REGIONS])
    max_it = np.array([gpu.loc[r, "Max_IT_Power_MW"] for r in REGIONS])
    lat = latency_matrix()

    res_gpu = np.tile(avail_gpu[:, None], (1, H_END + 1)).astype(float)
    res_it = np.tile(max_it[:, None], (1, H_END + 1)).astype(float) - sig["nonai"]
    schedule: list[dict] = []
    templates = _build_templates(tasks)

    order = tasks["ArrivalHour"].argsort(kind="stable")
    ordered = tasks.iloc[order].copy()
    flex = ordered[ordered["is_flex"]].sort_values(["gpu_h", "ArrivalHour"], ascending=[False, True])
    ordered = pd.concat([ordered[~ordered["is_flex"]], flex], ignore_index=True)
    t0 = time.time()
    for n, (_, t) in enumerate(ordered.iterrows()):
        src = REGIONS.index(t["SourceRegion"])
        feasible = [
            j
            for j in range(len(REGIONS))
            if lat[src, j] <= t["MaxLatency_ms"] + 1e-9
        ]
        type_idx = TYPES.index(t["TaskType"])
        p = t["power_mw"]
        if not t["is_flex"]:
            start = int(t["ArrivalHour"])
            best = None
            best_score = np.inf
            for j in feasible:
                util = 1.0 - res_gpu[j, start] / avail_gpu[j]
                score = _candidate_score(sig, weights, lat[src, j], j, start, p) + weights.get("w_util", 60.0) * util
                if _can_place(res_gpu, res_it, avail_gpu, max_it, t, j, start, templates[float(t["dur_h"])]) and score < best_score:
                    best, best_score = (j, start), score
            if best is None:
                raise RuntimeError(f"实时任务 {t['TaskID']} 无法调度")
            _place(schedule, res_gpu, res_it, t, best[0], best[1], templates[float(t["dur_h"])])
            continue

        # 弹性任务：快速候选集优先，未命中再扩大候选集，最后全时域兜底
        tmpl = templates[float(t["dur_h"])]
        best_overall: tuple | None = None
        best_score = np.inf
        for j in sorted(feasible, key=lambda j: region_avg[type_idx, j]):
            hours = _candidate_hours(t, ranks, j, near_h=12, top_k=6, sample_n=0)
            if len(hours) == 0:
                continue
            base_score = (_hour_score_array(sig, weights, j, p) + weights["w_lat"] * lat[src, j])[hours]
            got = _eval_candidate_set(res_gpu, res_it, avail_gpu, max_it, t, j, hours, base_score,
                                      weights.get("w_util", 300.0), tmpl)
            if got is not None and got[1] < best_score:
                best_overall, best_score = (j, got[0]), got[1]
        if best_overall is None:
            for j in sorted(feasible, key=lambda j: region_avg[type_idx, j]):
                hours = _candidate_hours(t, ranks, j)
                if len(hours) == 0:
                    continue
                base_score = (_hour_score_array(sig, weights, j, p) + weights["w_lat"] * lat[src, j])[hours]
                got = _eval_candidate_set(res_gpu, res_it, avail_gpu, max_it, t, j, hours, base_score,
                                          weights.get("w_util", 300.0), tmpl)
                if got is not None and got[1] < best_score:
                    best_overall, best_score = (j, got[0]), got[1]
        if best_overall is not None:
            _place(schedule, res_gpu, res_it, t, best_overall[0], best_overall[1], tmpl)
            placed = True
        else:
            # 兜底：全时域扫描
            placed = False
            for j in feasible:
                for hh in range(int(t["ArrivalHour"]), int(t["latest_start"]) + 1):
                    if _can_place(res_gpu, res_it, avail_gpu, max_it, t, j, hh, tmpl):
                        _place(schedule, res_gpu, res_it, t, j, hh, tmpl)
                        placed = True
                        break
                if placed:
                    break
        if not placed:
            a0, b0 = int(t["ArrivalHour"]), int(t["latest_start"])
            debug = {
                "task": int(t["TaskID"]),
                "type": t["TaskType"],
                "arrival": a0,
                "latest_start": b0,
                "feasible": [REGIONS[j] for j in feasible],
                "res_gpu_min": {
                    REGIONS[j]: float(res_gpu[j, a0 : b0 + 1].min())
                    for j in feasible
                },
                "res_gpu_mean": {
                    REGIONS[j]: float(res_gpu[j, a0 : b0 + 1].mean())
                    for j in feasible
                },
                "res_it_min": {
                    REGIONS[j]: float(res_it[j, a0 : b0 + 1].min())
                    for j in feasible
                },
            }
            sig_local = sig
            debug["lowest_it_hours"] = {}
            for j in feasible:
                idxs = np.argsort(res_it[j, a0 : b0 + 1])[:5] + a0
                debug["lowest_it_hours"][REGIONS[j]] = [
                    {
                        "hour": int(hh),
                        "res_gpu": float(res_gpu[j, hh]),
                        "res_it": float(res_it[j, hh]),
                        "nonai": float(sig_local["nonai"][j, hh]),
                    }
                    for hh in idxs
                ]
            raise RuntimeError(f"任务 {t['TaskID']} 无法调度: {json.dumps(debug, ensure_ascii=False)}")
        if progress and (n + 1) % 5000 == 0:
            print(f"  scheduled {n + 1}/{len(ordered)} tasks, {time.time() - t0:.1f}s", flush=True)
    return schedule


def _hour_score_array(sig: dict, weights: dict, j: int, p: float) -> np.ndarray:
    base = sig["grid_frac"][j] * (sig["price"][j] + weights["c_carbon"] * sig["carbon"][j]) * p * sig["pue"][j]
    bonus = weights["w_renew"] * sig["renew_norm"][j] * p * sig["pue"][j]
    return base - bonus


def _candidate_score(sig: dict, weights: dict, latency: float, j: int, h: int, p: float) -> float:
    base = sig["grid_frac"][j, h] * (sig["price"][j, h] + weights["c_carbon"] * sig["carbon"][j, h]) * p * sig["pue"][j]
    bonus = weights["w_renew"] * sig["renew_norm"][j, h] * p * sig["pue"][j]
    return float(base - bonus + weights["w_lat"] * latency)


def _build_templates(tasks: pd.DataFrame) -> dict[float, tuple[np.ndarray, np.ndarray]]:
    """按持续时间预计算重叠模板（相对小时偏移与占用小时数）。"""
    tmpl: dict[float, tuple[np.ndarray, np.ndarray]] = {}
    for d in np.sort(tasks["dur_h"].unique()):
        offs = np.arange(0, int(np.ceil(float(d))) + 1)
        ov = np.clip(float(d) - offs, 0.0, 1.0) * (offs < float(d))
        tmpl[float(d)] = (offs, ov)
    return tmpl


def _can_place(
    res_gpu: np.ndarray,
    res_it: np.ndarray,
    avail_gpu: np.ndarray,
    max_it: np.ndarray,
    t: pd.Series,
    j: int,
    s: int,
    tmpl: tuple[np.ndarray, np.ndarray],
    gpu_reserve_frac: float = 0.01,
    it_reserve_frac: float = 0.005,
) -> bool:
    offs, ov = tmpl
    hrs = s + offs
    if hrs[-1] >= H_END + 1:
        return False
    need_gpu = t["GPU_Demand"] * ov
    if np.any(res_gpu[j, hrs] - need_gpu < gpu_reserve_frac * avail_gpu[j] - 1e-6):
        return False
    if np.any(res_it[j, hrs] - need_gpu * t["power_mw"] < it_reserve_frac * max_it[j] - 1e-6):
        return False
    return True


def _feasible_min_res(
    res_gpu: np.ndarray,
    res_it: np.ndarray,
    avail_gpu: np.ndarray,
    max_it: np.ndarray,
    t: pd.Series,
    j: int,
    s: int,
    tmpl: tuple[np.ndarray, np.ndarray],
) -> float:
    """可行则返回放置后最小归一化剩余容量，不可行返回None。"""
    offs, ov = tmpl
    hrs = s + offs
    if hrs[-1] >= H_END + 1:
        return None
    need_gpu = t["GPU_Demand"] * ov
    need_it = need_gpu * t["power_mw"]
    if np.any(res_gpu[j, hrs] - need_gpu < 0.01 * avail_gpu[j] - 1e-6):
        return None
    if np.any(res_it[j, hrs] - need_it < 0.005 * max_it[j] - 1e-6):
        return None
    gpu_norm = (res_gpu[j, hrs] - need_gpu) / max(avail_gpu[j], 1e-9)
    it_norm = (res_it[j, hrs] - need_it) / max(max_it[j], 1e-9)
    return float(min(gpu_norm.min(), it_norm.min()))


def _eval_candidate_set(
    res_gpu: np.ndarray,
    res_it: np.ndarray,
    avail_gpu: np.ndarray,
    max_it: np.ndarray,
    t: pd.Series,
    j: int,
    hours: np.ndarray,
    base_score: np.ndarray,
    w_util: float,
    tmpl: tuple[np.ndarray, np.ndarray],
) -> tuple[int, float] | None:
    """在候选开工小时中返回 (综合最优小时, 得分)。"""
    best_h, best_s = None, np.inf
    for idx, h in enumerate(hours):
        hh = int(h)
        mr = _feasible_min_res(res_gpu, res_it, avail_gpu, max_it, t, j, hh, tmpl)
        if mr is None:
            continue
        score = float(base_score[idx]) + w_util * (1.0 - mr)
        if score < best_s:
            best_h, best_s = hh, score
    return (best_h, best_s) if best_h is not None else None


def _place(
    schedule: list[dict],
    res_gpu: np.ndarray,
    res_it: np.ndarray,
    t: pd.Series,
    j: int,
    s: int,
    tmpl: tuple[np.ndarray, np.ndarray],
) -> None:
    offs, ov = tmpl
    hrs = s + offs
    need_gpu = t["GPU_Demand"] * ov
    res_gpu[j, hrs] -= need_gpu
    res_it[j, hrs] -= need_gpu * t["power_mw"]
    schedule.append(
        {"task_id": int(t["TaskID"]), "region": REGIONS[j], "start_h": float(s), "dur_h": float(t["dur_h"])}
    )


def compare_metrics(schedule: list[dict], label: str) -> dict:
    # 基准用附件基准AI负荷
    from common import metrics_from_ai_it

    m = schedule_metrics(schedule, label=label)
    base = metrics_from_ai_it(baseline_ai_it_load(), label="baseline")
    m["baseline_cost_万元"] = base["electricity_cost_万元"]
    m["baseline_carbon_t"] = base["carbon_t"]
    m["baseline_renewable_util_%"] = base["renewable_util_%"]
    m["baseline_peak_net_import_MW"] = base["peak_net_import_MW"]
    return m


def migration_matrix(schedule: list[dict]) -> pd.DataFrame:
    tasks = prepare_tasks()
    idx = {s["task_id"]: s["region"] for s in schedule}
    rows = tasks[tasks["TaskID"].isin(idx)].copy()
    rows["DestRegion"] = rows["TaskID"].map(idx)
    mat = rows.pivot_table(index="SourceRegion", columns="DestRegion", values="TaskID", aggfunc="count", fill_value=0)
    mat = mat.reindex(index=REGIONS, columns=REGIONS, fill_value=0)
    return mat.reset_index().rename(columns={"index": "SourceRegion"})


def figures(schedule: list[dict], m: dict, label: str = "q2") -> None:
    FIG_DIR.mkdir(exist_ok=True)
    tasks = prepare_tasks()
    idx = {s["task_id"]: s for s in schedule}
    rows = tasks[tasks["TaskID"].isin(idx)].copy()
    rows["DestRegion"] = rows["TaskID"].map(lambda i: idx[i]["region"])
    rows["StartHour"] = rows["TaskID"].map(lambda i: idx[i]["start_h"])
    rows["Latency_ms"] = [
        latency_matrix()[REGIONS.index(s), REGIONS.index(d)]
        for s, d in zip(rows["SourceRegion"], rows["DestRegion"])
    ]
    rows["Delay_h"] = rows["StartHour"] - rows["ArrivalHour"]

    # 迁移矩阵热力图
    mat = migration_matrix(schedule)
    fig, ax = plt.subplots(figsize=(7.5, 6))
    im = ax.imshow(mat.drop(columns="SourceRegion").to_numpy(), cmap="YlGnBu")
    ax.set_xticks(range(6), REGIONS, rotation=45)
    ax.set_yticks(range(6), REGIONS)
    for i in range(6):
        for j in range(6):
            ax.text(j, i, int(mat.iloc[i, j + 1]), ha="center", va="center", fontsize=9)
    ax.set_title("Q2 调度：来源区域到目标区域迁移任务数")
    fig.colorbar(im, ax=ax)
    fig.tight_layout()
    fig.savefig(FIG_DIR / f"{label}_migration_matrix.png", dpi=150)
    plt.close(fig)

    # 开工延迟分布
    fig, ax = plt.subplots(figsize=(8, 4.2))
    flex = rows[rows.TaskType != "RealTimeInference"]
    ax.hist(flex["Delay_h"], bins=np.arange(0, max(24, flex["Delay_h"].max() + 2)), color="#4C72B0", alpha=0.85)
    ax.set_title("弹性任务开工延迟分布（小时）")
    ax.set_xlabel("延迟（小时）")
    ax.set_ylabel("任务数")
    fig.tight_layout()
    fig.savefig(FIG_DIR / f"{label}_delay_hist.png", dpi=150)
    plt.close(fig)

    # 区域AI IT负荷：样本周（小时1000-1168）
    ai_it, _ = schedule_to_load(schedule)
    fig, axes = plt.subplots(2, 1, figsize=(10, 6.5), sharex=True)
    hrs = np.arange(1000, 1168)
    base = baseline_ai_it_load()
    axes[0].stackplot(hrs, *[base[i, hrs] for i in range(6)], labels=REGIONS, alpha=0.8)
    axes[0].set_title("基准 AI IT 负荷（本地到达即开工）")
    axes[0].set_ylabel("MW")
    axes[1].stackplot(hrs, *[ai_it[i, hrs] for i in range(6)], labels=REGIONS, alpha=0.8)
    axes[1].set_title("Q2 碳感知调度 AI IT 负荷")
    axes[1].set_xlabel("小时")
    axes[1].set_ylabel("MW")
    axes[1].legend(loc="upper right", fontsize=8, ncol=3)
    fig.tight_layout()
    fig.savefig(FIG_DIR / f"{label}_load_shift.png", dpi=150)
    plt.close(fig)

    # 指标对比
    fig, axes = plt.subplots(1, 4, figsize=(13, 3.6))
    cats = ["基准", "Q2碳感知"]
    vals = [
        (m["baseline_cost_万元"], m["electricity_cost_万元"], "运行成本（万元）"),
        (m["baseline_carbon_t"], m["carbon_t"], "碳排放（tCO2）"),
        (m["baseline_renewable_util_%"], m["renewable_util_%"], "新能源利用率（%）"),
        (m["baseline_peak_net_import_MW"], m["peak_net_import_MW"], "峰值净购电（MW）"),
    ]
    for ax, (bv, qv, title) in zip(axes, vals):
        ax.bar(cats, [bv, qv], color=["#8C8C8C", "#4C72B0"])
        for i, v in enumerate([bv, qv]):
            ax.text(i, v, f"{v:.1f}", ha="center", va="bottom", fontsize=8)
        ax.set_title(title)
        ax.tick_params(axis="x", labelsize=9)
    fig.tight_layout()
    fig.savefig(FIG_DIR / f"{label}_metrics_compare.png", dpi=150)
    plt.close(fig)


def schedule_to_load(schedule: list[dict]) -> tuple[np.ndarray, np.ndarray]:
    from common import schedule_to_load as stl

    return stl(schedule)


def run(weights: dict | None = None, label: str = "q2") -> dict:
    if weights is None:
        weights = {"w_cost": 1.0, "c_carbon": 80.0, "w_lat": 0.01, "w_renew": 200.0}
    t0 = time.time()
    schedule = schedule_horizon(weights)
    m = compare_metrics(schedule, label)
    m["runtime_s"] = round(time.time() - t0, 1)
    save_json(m, f"{label}_metrics")
    save_table(migration_matrix(schedule), f"{label}_migration_matrix")
    save_table(_schedule_table(schedule), f"{label}_schedule")
    figures(schedule, m, label)
    print(json.dumps({k: round(v, 4) if isinstance(v, float) else v for k, v in m.items()}, ensure_ascii=False, indent=1))
    return m


def _schedule_table(schedule: list[dict]) -> pd.DataFrame:
    tasks = prepare_tasks()
    idx = {s["task_id"]: s for s in schedule}
    rows = tasks[tasks["TaskID"].isin(idx)].copy()
    rows["DestRegion"] = rows["TaskID"].map(lambda i: idx[i]["region"])
    rows["StartHour"] = rows["TaskID"].map(lambda i: idx[i]["start_h"])
    rows["FinishHour"] = rows["StartHour"] + rows["dur_h"]
    rows["Latency_ms"] = [
        latency_matrix()[REGIONS.index(s), REGIONS.index(d)]
        for s, d in zip(rows["SourceRegion"], rows["DestRegion"])
    ]
    rows["Delay_h"] = rows["StartHour"] - rows["ArrivalHour"]
    return rows[
        ["TaskID", "TaskType", "SourceRegion", "DestRegion", "ArrivalHour", "StartHour",
         "FinishHour", "GPU_Demand", "EstimatedDuration_min", "Latency_ms", "MaxLatency_ms", "Delay_h"]
    ]


if __name__ == "__main__":
    run()
