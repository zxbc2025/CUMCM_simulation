# -*- coding: utf-8 -*-
"""约束与一致性校验：时延、时限、GPU容量、IT功率。"""
from __future__ import annotations

import json

import numpy as np
import pandas as pd

from common import (
    H_END,
    OUT_DIR,
    REGIONS,
    TABLE_DIR,
    load_gpu,
    latency_matrix,
    prepare_tasks,
    save_json,
)


def check_schedule_table(name: str) -> dict:
    path = TABLE_DIR / f"{name}.csv"
    if not path.exists():
        return {"file": name, "status": "missing"}
    df = pd.read_csv(path)
    tasks = prepare_tasks().set_index("TaskID")
    df["LatestFinishHour"] = df["TaskID"].map(lambda i: tasks.loc[i, "LatestFinishHour"])
    df["MaxLatency_ms"] = df["TaskID"].map(lambda i: tasks.loc[i, "MaxLatency_ms"])
    df["SourceRegion"] = df["TaskID"].map(lambda i: tasks.loc[i, "SourceRegion"])
    df["ArrivalHour"] = df["TaskID"].map(lambda i: tasks.loc[i, "ArrivalHour"])
    df["EstimatedDuration_min"] = df["TaskID"].map(lambda i: tasks.loc[i, "EstimatedDuration_min"])
    lat = latency_matrix()
    gpu = load_gpu().set_index("Region")

    lat_viol = 0
    deadline_viol = 0
    start_viol = 0
    for _, r in df.iterrows():
        if lat[REGIONS.index(r["SourceRegion"]), REGIONS.index(r["DestRegion"])] > r["MaxLatency_ms"] + 1e-9:
            lat_viol += 1
        if r["FinishHour"] > r["LatestFinishHour"] + 1e-9:
            deadline_viol += 1
        if r["StartHour"] < r["ArrivalHour"] - 1e-9:
            start_viol += 1

    # GPU/IT功率逐小时校验
    gpu_occ = np.zeros((len(REGIONS), H_END + 1))
    it = np.zeros((len(REGIONS), H_END + 1))
    for _, r in df.iterrows():
        s = float(r["StartHour"])
        d = float(r["EstimatedDuration_min"]) / 60.0
        j = REGIONS.index(r["DestRegion"])
        hrs = np.arange(int(np.floor(s)), int(np.ceil(s + d)) + 1)
        ov = np.maximum(0.0, np.minimum(hrs + 1.0, s + d) - np.maximum(hrs, s))
        valid = (hrs >= 0) & (hrs < H_END + 1)
        gpu_occ[j, hrs[valid]] += r["GPU_Demand"] * ov[valid]
        p = tasks.loc[r["TaskID"], "power_mw"]
        it[j, hrs[valid]] += r["GPU_Demand"] * ov[valid] * p
    gpu_viol = 0
    it_viol = 0
    for j, region in enumerate(REGIONS):
        gpu_viol += int(np.sum(gpu_occ[j] > gpu.loc[region, "Available_GPU"] + 1e-6))
        it_viol += int(np.sum(it[j] > gpu.loc[region, "Max_IT_Power_MW"] + 1e-6))
    return {
        "file": name,
        "tasks": int(len(df)),
        "latency_violations": lat_viol,
        "deadline_violations": deadline_viol,
        "start_violations": start_viol,
        "gpu_capacity_hour_violations": gpu_viol,
        "it_power_hour_violations": it_viol,
        "ok": lat_viol + deadline_viol + start_viol + gpu_viol + it_viol == 0,
    }


def run() -> dict:
    files = ["q1_schedule", "q2_schedule"]
    results = {f: check_schedule_table(f) for f in files}
    # Q4 场景调度（若已保存）
    import glob

    for p in sorted(glob.glob(str(TABLE_DIR / "q4_*_schedule.csv"))):
        name = p.split("\\")[-1].replace(".csv", "")
        results[name] = check_schedule_table(name)
    save_json(results, "validation_summary")
    print(json.dumps(results, ensure_ascii=False, indent=1))
    return results


if __name__ == "__main__":
    run()
