# -*- coding: utf-8 -*-
"""
问题4：多区域算-储-电协同优化与场景对比。

双层框架：
- 外层：Q2 碳感知滚动启发式（任务迁移 + 开工时段）；
- 内层：Q3 储能LP（给定任务负荷，优化储能/购售电/新能源分配）。

场景：
- S0 基准：分时电价、碳价0、可再生基准；
- S1/S2 碳约束：碳价100/200 元/tCO2（调度信号与储能目标同时含碳成本）；
- S3 电价机制：区域平均平段电价；
- S4/S5 新能源波动：可用可再生 ×0.85 / ×1.15。
"""
from __future__ import annotations

import json

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import q2_scheduling
import q3_storage
from common import (
    FIG_DIR,
    H_END,
    OUT_DIR,
    REGIONS,
    energy_dataframe,
    load_gpu,
    prepare_tasks,
    save_json,
    save_table,
    schedule_metrics,
    schedule_to_load,
)

plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei"]
plt.rcParams["axes.unicode_minus"] = False


def region_total_load(ai_it: np.ndarray) -> dict[str, np.ndarray]:
    """由任务调度AI负荷生成各区域设施侧总负荷。"""
    rt = energy_dataframe()
    gpu = load_gpu().set_index("Region")
    tl = {}
    for ridx, region in enumerate(REGIONS):
        sub = rt[rt["Region"] == region].sort_values("Hour")
        nonai = sub["NonAI_IT_Load_MW"].to_numpy()
        pue = float(gpu.loc[region, "PUE"])
        tl[region] = (nonai + ai_it[ridx]) * pue
    return tl


def run_joint(
    name: str,
    weights: dict,
    carbon_price: float = 0.0,
    price_override: dict | None = None,
    renew_scale: float = 1.0,
) -> dict:
    """一次算-储-电联合优化。"""
    schedule = q2_scheduling.schedule_horizon(
        weights,
        renew_scale=renew_scale,
        price_override=price_override,
        progress=False,
    )
    ai_it, gpu_occ = schedule_to_load(schedule)
    tl_map = region_total_load(ai_it)
    storage = {}
    for region in REGIONS:
        out = q3_storage.solve_region_lp(
            region,
            objective="cost",
            carbon_price=carbon_price,
            tl=tl_map[region],
            price_override=price_override,
            renew_scale=renew_scale,
        )
        storage[region] = out

    task_m = schedule_metrics(schedule, label=name)
    cost = sum(s["metrics"]["cost_万元"] for s in storage.values())
    carbon = sum(s["metrics"]["carbon_t"] for s in storage.values())
    peak = max(s["metrics"]["peak_net_import_MW"] for s in storage.values())
    renew = sum(s["metrics"]["renewable_util_%"] * 1 for s in storage.values()) / len(REGIONS)
    charge = sum(s["metrics"]["charge_GWh"] for s in storage.values())
    discharge = sum(s["metrics"]["discharge_GWh"] for s in storage.values())
    joint = {
        "scenario": name,
        "cost_万元": cost,
        "carbon_t": carbon,
        "renewable_util_%_avg": renew,
        "peak_net_import_MW": peak,
        "storage_charge_GWh": charge,
        "storage_discharge_GWh": discharge,
        "migrate_rate_%": task_m["migrate_rate_%"],
        "avg_latency_ms": task_m["avg_latency_ms"],
        "avg_delay_h": task_m["avg_delay_h"],
        "max_gpu_util_%": task_m["max_gpu_util_%"],
        "task_count": len(schedule),
        "carbon_price": carbon_price,
        "renew_scale": renew_scale,
        "price_override": price_override is not None,
    }
    _save_schedule(schedule, name)
    return {
        "joint": joint,
        "schedule": schedule,
        "storage": storage,
        "task_metrics": task_m,
    }


def _save_schedule(schedule: list[dict], name: str) -> None:
    import q2_scheduling

    save_table(q2_scheduling._schedule_table(schedule), f"q4_{name}_schedule")


DEFAULT_WEIGHTS = {"w_cost": 1.0, "c_carbon": 80.0, "w_lat": 0.01, "w_renew": 200.0, "w_util": 300.0}


def run() -> dict:
    scenarios = [
        ("S0_base", DEFAULT_WEIGHTS, 0.0, None, 1.0),
        ("S1_carbon100", {**DEFAULT_WEIGHTS, "c_carbon": 180.0, "w_renew": 300.0}, 100.0, None, 1.0),
        ("S2_carbon200", {**DEFAULT_WEIGHTS, "c_carbon": 280.0, "w_renew": 400.0}, 200.0, None, 1.0),
        ("S3_flat_price", DEFAULT_WEIGHTS, 0.0, _flat_prices(), 1.0),
        ("S4_low_renew", DEFAULT_WEIGHTS, 0.0, None, 0.85),
        ("S5_high_renew", DEFAULT_WEIGHTS, 0.0, None, 1.15),
    ]
    rows = []
    schedules = {}
    for name, weights, cp, po, rs in scenarios:
        print(f"[Q4] 场景 {name} 开始...", flush=True)
        out = run_joint(name, weights, cp, po, rs)
        rows.append(out["joint"])
        schedules[name] = out
        print(f"[Q4] 场景 {name} 完成: {out['joint']['cost_万元']:.1f} 万元, "
              f"{out['joint']['carbon_t']:.0f} tCO2", flush=True)

    joint_df = pd.DataFrame(rows)
    save_table(joint_df, "q4_scenario_metrics")
    save_json(rows, "q4_scenario_metrics_json")

    # 权重权衡（基场景）
    trade_weights = [
        ("cost_first", {**DEFAULT_WEIGHTS, "c_carbon": 20.0, "w_renew": 80.0}),
        ("balanced", DEFAULT_WEIGHTS),
        ("low_carbon", {**DEFAULT_WEIGHTS, "c_carbon": 220.0, "w_renew": 450.0}),
        ("low_latency", {**DEFAULT_WEIGHTS, "w_lat": 0.06, "w_renew": 80.0}),
        ("high_renew", {**DEFAULT_WEIGHTS, "w_renew": 600.0}),
    ]
    trade_rows = []
    for name, weights in trade_weights:
        print(f"[Q4] 权衡方案 {name} 开始...", flush=True)
        out = run_joint(name, weights, 0.0, None, 1.0)
        row = {"scheme": name, **out["joint"]}
        trade_rows.append(row)
        print(f"[Q4] 权衡方案 {name} 完成", flush=True)
    trade_df = pd.DataFrame(trade_rows)
    save_table(trade_df, "q4_tradeoff_metrics")
    save_json(trade_rows, "q4_tradeoff_metrics_json")

    figures(joint_df, trade_df)
    return {"scenarios": rows, "tradeoff": trade_rows}


def _flat_prices() -> dict:
    rt = energy_dataframe()
    return {
        region: float(rt[rt["Region"] == region]["ElectricityPrice_CNY_per_MWh"].mean())
        for region in REGIONS
    }


def figures(joint_df: pd.DataFrame, trade_df: pd.DataFrame) -> None:
    FIG_DIR.mkdir(exist_ok=True)
    # 场景指标对比
    fig, axes = plt.subplots(2, 3, figsize=(13, 7.5))
    cols = ["cost_万元", "carbon_t", "renewable_util_%_avg", "peak_net_import_MW", "migrate_rate_%", "avg_delay_h"]
    titles = ["运行成本（万元）", "碳排放（tCO2）", "平均新能源利用率（%）", "峰值净购电（MW）", "迁移率（%）", "平均开工延迟（h）"]
    for ax, col, title in zip(axes.ravel(), cols, titles):
        ax.bar(joint_df["scenario"], joint_df[col], color="#4C72B0")
        ax.set_title(title)
        ax.tick_params(axis="x", rotation=35, labelsize=8)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "q4_scenario_metrics.png", dpi=150)
    plt.close(fig)

    # 权衡散点：成本-时延-迁移率（基场景碳排已接近0，主要权衡在成本/时延/迁移）
    fig, ax = plt.subplots(figsize=(8.5, 6))
    sc = ax.scatter(
        trade_df["cost_万元"] / 1e4,
        trade_df["avg_latency_ms"],
        s=90,
        c=trade_df["migrate_rate_%"],
        cmap="YlGnBu",
        edgecolor="k",
    )
    for _, r in trade_df.iterrows():
        ax.annotate(r["scheme"], (r["cost_万元"] / 1e4, r["avg_latency_ms"]), fontsize=9, xytext=(5, 5), textcoords="offset points")
    ax.set_xlabel("运行成本（亿元）")
    ax.set_ylabel("GPU小时加权平均时延（ms）")
    ax.set_title("基场景多目标权衡：成本-时延-迁移率")
    fig.colorbar(sc, ax=ax, label="迁移率（%）")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "q4_tradeoff.png", dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    run()
