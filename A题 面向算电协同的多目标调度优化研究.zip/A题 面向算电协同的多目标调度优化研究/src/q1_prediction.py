# -*- coding: utf-8 -*-
"""
问题1第一部分：工作负载统计分析 + 短期预测模型。

建模口径：
- 训练 0-2351，调参验证 2352-2375，重训 0-2375，测试 2376-2399。
- 对每个(区域, 任务类型)序列建立"季节特征+滞后项"岭回归模型，
  再汇总得到全系统逐时GPU需求预测。
- 对照基准：同小时前一天（Lag-24）季节朴素法。
"""
from __future__ import annotations

import json

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from common import (
    FIG_DIR,
    OUT_DIR,
    REGIONS,
    TABLE_DIR,
    TYPES,
    load_tasks,
    save_json,
    save_table,
)

plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei"]
plt.rcParams["axes.unicode_minus"] = False

TRAIN_H0, TRAIN_H1 = 0, 2351
VAL_H0, VAL_H1 = 2352, 2375
TEST_H0, TEST_H1 = 2376, 2399


def build_hourly_series() -> pd.DataFrame:
    w = load_tasks().copy()
    g = (
        w.groupby(["ArrivalHour", "SourceRegion", "TaskType"])
        .agg(
            gpu_sum=("GPU_Demand", "sum"),
            gpu_h=("GPU_Demand", lambda s: float(np.sum(s * w.loc[s.index, "EstimatedDuration_min"] / 60.0))),
            count=("TaskID", "count"),
        )
        .reset_index()
    )
    g.rename(columns={"ArrivalHour": "Hour", "SourceRegion": "Region"}, inplace=True)
    return g


def workload_statistics() -> pd.DataFrame:
    w = load_tasks().copy()
    w["dur_h"] = w["EstimatedDuration_min"] / 60.0
    w["gpu_h"] = w["GPU_Demand"] * w["dur_h"]
    tab = (
        w.groupby(["SourceRegion", "TaskType"])
        .agg(
            task_count=("TaskID", "count"),
            gpu_demand_sum=("GPU_Demand", "sum"),
            gpu_h_sum=("gpu_h", "sum"),
            mean_gpu=("GPU_Demand", "mean"),
            mean_dur_min=("EstimatedDuration_min", "mean"),
        )
        .round(2)
        .reset_index()
    )
    return tab


def _ridge_fit(X: np.ndarray, y: np.ndarray, alpha: float) -> np.ndarray:
    n, d = X.shape
    A = X.T @ X + alpha * np.eye(d)
    return np.linalg.solve(A, X.T @ y)


def _base_feat(h: np.ndarray) -> np.ndarray:
    """时间基特征（不含滞后项）。"""
    cols = [
        np.ones_like(h, dtype=float),
        h / 2400.0,
        np.sin(2 * np.pi * h / 24.0),
        np.cos(2 * np.pi * h / 24.0),
        np.sin(2 * np.pi * h / 168.0),
        np.cos(2 * np.pi * h / 168.0),
    ]
    for k in range(24):
        cols.append((h % 24 == k).astype(float))
    for k in range(7):
        cols.append(((h // 24) % 7 == k).astype(float))
    return np.column_stack(cols)


def _fit_features(hours: np.ndarray, series: np.ndarray) -> np.ndarray:
    """训练特征矩阵：滞后项仅使用序列内部历史值。"""
    lut = {int(hh): v for hh, v in zip(hours, series)}
    base = _base_feat(hours)
    lag1 = np.array([lut.get(int(hh - 1), np.nan) for hh in hours])
    lag24 = np.array([lut.get(int(hh - 24), np.nan) for hh in hours])
    lag168 = np.array([lut.get(int(hh - 168), np.nan) for hh in hours])
    return np.column_stack([base, lag1, lag24, lag168])


def _pred_feature(hh: int, known: dict[int, float], prev: dict[int, float]) -> np.ndarray:
    """单步预测特征：滞后项取已知历史，缺失时取上一步预测。"""
    lag1 = known.get(hh - 1, prev.get(hh - 1, np.nan))
    lag24 = known.get(hh - 24, prev.get(hh - 24, np.nan))
    lag168 = known.get(hh - 168, prev.get(hh - 168, np.nan))
    return np.concatenate([_base_feat(np.array([hh]))[0], [lag1, lag24, lag168]])


def fit_predict_series(
    hours: np.ndarray, values: np.ndarray, alpha: float, pred_hours: np.ndarray
) -> np.ndarray:
    """岭回归拟合 + 递归一步预测。"""
    train_mask = (hours >= TRAIN_H0) & (hours <= TRAIN_H1)
    X = _fit_features(hours[train_mask], values[train_mask])
    y = values[train_mask]
    ok = np.isfinite(X).all(axis=1) & np.isfinite(y)
    beta = _ridge_fit(X[ok], y[ok], alpha)
    known = dict(zip(hours[train_mask].astype(int), values[train_mask]))
    prev: dict[int, float] = {}
    preds = []
    for hh in pred_hours:
        xj = _pred_feature(int(hh), known, prev)
        p = float(xj @ beta)
        preds.append(p)
        prev[int(hh)] = p
    return np.array(preds)


def seasonal_naive(hours: np.ndarray, values: np.ndarray, pred_hours: np.ndarray) -> np.ndarray:
    """Lag-24 季节朴素基准。"""
    lut = dict(zip(hours.astype(int), values))
    return np.array([lut.get(int(hh - 24), np.nan) for hh in pred_hours])


def seasonal_mean_model(
    train_hours: np.ndarray, train_vals: np.ndarray, pred_hours: np.ndarray
) -> np.ndarray:
    """小时哑变量季节均值模型（等价于小时效应 OLS）。"""
    means = np.array(
        [train_vals[train_hours % 24 == k].mean() for k in range(24)]
    )
    return means[np.mod(pred_hours, 24).astype(int)]


def residual_std(train_hours: np.ndarray, train_vals: np.ndarray) -> float:
    """季节均值模型的训练残差标准差（用于预测区间）。"""
    pred = seasonal_mean_model(train_hours, train_vals, train_hours)
    return float(np.std(train_vals - pred))


def mape(a: np.ndarray, p: np.ndarray) -> float:
    mask = a > 1e-9
    return float(np.mean(np.abs((a[mask] - p[mask]) / a[mask])) * 100)


def metrics(a: np.ndarray, p: np.ndarray) -> dict:
    return {
        "rmse": float(np.sqrt(np.mean((a - p) ** 2))),
        "mae": float(np.mean(np.abs(a - p))),
        "mape_%": mape(a, p),
    }


def run() -> dict:
    g = build_hourly_series()
    stats = workload_statistics()
    save_table(stats, "q1_workload_statistics")

    model_names = ["seasonal_mean", "ridge", "seasonal_naive"]
    rows = []
    for _, row in g.drop_duplicates(["Region", "TaskType"]).iterrows():
        sub = g[(g.Region == row.Region) & (g.TaskType == row.TaskType)].sort_values("Hour")
        hours = sub["Hour"].to_numpy()
        values = sub["gpu_sum"].to_numpy()
        val_mask = (hours >= VAL_H0) & (hours <= VAL_H1)
        test_mask = (hours >= TEST_H0) & (hours <= TEST_H1)
        train_mask_v = hours <= TRAIN_H1
        train_mask_t = hours <= 2375
        preds = {
            "seasonal_mean": seasonal_mean_model(hours[train_mask_v], values[train_mask_v], hours[val_mask]),
            "ridge": fit_predict_series(hours, values, 1.0, hours[val_mask]),
            "seasonal_naive": seasonal_naive(hours, values, hours[val_mask]),
        }
        for name, p in preds.items():
            for hh, a, pj in zip(hours[val_mask], values[val_mask], p):
                rows.append(
                    {"Phase": "validate", "Hour": int(hh), "Region": row.Region, "TaskType": row.TaskType,
                     "model": name, "actual": a, "pred": pj}
                )
        preds_test = {
            "seasonal_mean": seasonal_mean_model(hours[train_mask_t], values[train_mask_t], hours[test_mask]),
            "ridge": fit_predict_series(hours, values, 1.0, hours[test_mask]),
            "seasonal_naive": seasonal_naive(hours, values, hours[test_mask]),
        }
        for name, p in preds_test.items():
            for hh, a, pj in zip(hours[test_mask], values[test_mask], p):
                rows.append(
                    {"Phase": "test", "Hour": int(hh), "Region": row.Region, "TaskType": row.TaskType,
                     "model": name, "actual": a, "pred": pj}
                )

    pred_df = pd.DataFrame(rows)
    save_table(pred_df, "q1_forecast_detail")

    # 全系统总预测（按小时聚合）
    metric_rows = []
    agg_by_model = {}
    for phase in ["validate", "test"]:
        for name in model_names:
            sub = pred_df[(pred_df.Phase == phase) & (pred_df.model == name)]
            agg = sub.groupby("Hour")[["actual", "pred"]].sum()
            agg_by_model[(phase, name)] = agg
            metric_rows.append({"phase": phase, "model": name, **metrics(agg["actual"].to_numpy(), agg["pred"].to_numpy())})
    metric_df = pd.DataFrame(metric_rows)
    save_table(metric_df, "q1_prediction_metrics")

    # 验证期 RMSE 最优模型作为最终预测模型
    val_stats = metric_df[metric_df.phase == "validate"].set_index("model")["rmse"]
    best_model = val_stats.idxmin()
    agg_val = agg_by_model[("validate", best_model)]
    agg_test = agg_by_model[("test", best_model)]

    # 测试期明细：最终模型 + 80% 预测区间（按总序列残差）
    w = load_tasks()
    total_series = w.groupby("ArrivalHour")["GPU_Demand"].sum().sort_index()
    hours_all = total_series.index.to_numpy()
    values_all = total_series.to_numpy()
    train_t = hours_all <= 2375
    sm_pred_all = seasonal_mean_model(hours_all[train_t], values_all[train_t], hours_all)
    resid_std = float(np.std(values_all[:2376] - sm_pred_all[:2376]))
    test_rows = pred_df[(pred_df.Phase == "test") & (pred_df.model == best_model)].copy()
    test_rows["lower"] = test_rows["pred"] - 1.28 * resid_std
    test_rows["upper"] = test_rows["pred"] + 1.28 * resid_std
    test_rows["lower"] = test_rows["lower"].clip(lower=0)
    save_table(test_rows, "q1_forecast_test")

    summary = {
        "best_model": best_model,
        "residual_std_total": resid_std,
        "validate": {name: metrics(agg_by_model[("validate", name)]["actual"].to_numpy(), agg_by_model[("validate", name)]["pred"].to_numpy()) for name in model_names},
        "test": {name: metrics(agg_by_model[("test", name)]["actual"].to_numpy(), agg_by_model[("test", name)]["pred"].to_numpy()) for name in model_names},
        "total_gpu_h": float(load_tasks().eval("GPU_Demand*EstimatedDuration_min/60").sum()),
    }
    save_json(summary, "q1_prediction_summary")
    _figures(stats, agg_val, agg_test, agg_by_model, summary)
    return summary


def _figures(
    stats: pd.DataFrame,
    agg_val: pd.DataFrame,
    agg_test: pd.DataFrame,
    agg_by_model: dict,
    summary: dict,
) -> None:
    FIG_DIR.mkdir(exist_ok=True)
    model_label = {
        "seasonal_mean": "季节均值模型",
        "ridge": "岭回归模型",
        "seasonal_naive": "季节朴素法",
    }
    best = summary["best_model"]

    # 图1：分区域分类型任务规模
    fig, ax = plt.subplots(figsize=(9, 4.6))
    pv = stats.pivot_table(index="SourceRegion", columns="TaskType", values="gpu_h_sum", fill_value=0)
    pv = pv.loc[REGIONS]
    pv.plot.bar(ax=ax, stacked=True, color=["#4C72B0", "#DD8452", "#55A868"])
    ax.set_title("各区域三类任务的 GPU 小时需求")
    ax.set_ylabel("GPU 小时")
    ax.set_xlabel("来源区域")
    ax.legend(title="任务类型")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "q1_workload_by_region.png", dpi=150)
    plt.close(fig)

    # 图2：小时级到达模式
    w = load_tasks().copy()
    w["hod"] = w["ArrivalHour"] % 24
    hod = w.groupby(["hod", "TaskType"])["GPU_Demand"].mean().unstack()[TYPES]
    fig, ax = plt.subplots(figsize=(9, 4.2))
    hod.plot(ax=ax, marker="o", ms=3, lw=1.5)
    ax.set_title("不同类型任务的平均小时到达 GPU 需求")
    ax.set_xlabel("小时（0-23）")
    ax.set_ylabel("平均 GPU 需求")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "q1_hourly_pattern.png", dpi=150)
    plt.close(fig)

    # 图3：验证期
    fig, ax = plt.subplots(figsize=(9, 4.0))
    ax.plot(agg_val.index, agg_val["actual"], label="实际", color="k", lw=1.6)
    ax.plot(agg_val.index, agg_val["pred"], label=f"{model_label[best]}预测", color="#C44E52", lw=1.4)
    ax.plot(
        agg_val.index,
        agg_by_model[("validate", "seasonal_naive")]["pred"],
        label="季节朴素法", color="#8C8C8C", lw=1.2, ls="--",
    )
    ax.set_title("验证期（2352-2375 小时）全系统 GPU 需求预测对比")
    ax.set_xlabel("小时")
    ax.set_ylabel("GPU 需求")
    ax.legend()
    fig.tight_layout()
    fig.savefig(FIG_DIR / "q1_validation_forecast.png", dpi=150)
    plt.close(fig)

    # 图4：测试期
    fig, ax = plt.subplots(figsize=(9, 4.0))
    ax.plot(agg_test.index, agg_test["actual"], label="实际", color="k", lw=1.8)
    ax.plot(agg_test.index, agg_test["pred"], label=f"{model_label[best]}预测", color="#C44E52", lw=1.6, marker="o", ms=3)
    ax.fill_between(
        agg_test.index,
        agg_test["pred"] - 1.28 * summary["residual_std_total"],
        agg_test["pred"] + 1.28 * summary["residual_std_total"],
        color="#C44E52", alpha=0.18, label="80% 预测区间",
    )
    ax.set_title("测试期（2376-2399 小时）全系统 GPU 需求预测与区间")
    ax.set_xlabel("小时")
    ax.set_ylabel("GPU 需求")
    ax.legend()
    fig.tight_layout()
    fig.savefig(FIG_DIR / "q1_test_forecast.png", dpi=150)
    plt.close(fig)

    with open(OUT_DIR / "q1_figure_notes.json", "w", encoding="utf-8") as f:
        json.dump({"best_model": best}, f, ensure_ascii=False)


if __name__ == "__main__":
    res = run()
    print("best_model", res["best_model"])
    for phase in ["validate", "test"]:
        for name in ["seasonal_mean", "ridge", "seasonal_naive"]:
            print(phase, name, {k: round(v, 3) for k, v in res[phase][name].items()})
