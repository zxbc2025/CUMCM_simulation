# 问题1建模思路（统计分析与短期预测 + 基础算力调度）

## 1. 从题意到变量

题意要求：对六区域、三类任务的 GPU 需求做统计分析；建立短期预测模型；
建立基础算力调度模型并给出第 2376-2399 小时实际到达任务的调度方案；
跨越 2399 的任务在收尾时域结清，并展示最后 24 小时甘特图与区域 GPU 利用率。

定义：
- `g_{r,\tau}(h)`：第 h 小时到达区域 r 的 τ 类任务 GPU 需求总和；
- `GH_{r,\tau}(h)`：第 h 小时到达任务的 GPU 小时需求（GPU_Demand × 时长/60）；
- `x_{i,r}`：任务 i 是否调度到区域 r（0/1），`s_i` 为开工小时；
- `y_{i,h}`：任务 i 在第 h 小时的占用小时数（按实际重叠折算）。

## 2. 预测模型

以 0-2351 小时训练、2352-2375 小时调参验证、0-2375 小时重训、
2376-2399 小时最终测试。对每个 (区域, 类型) 序列建立：

1. 季节均值模型（小时哑变量 OLS，等价于"各小时历史均值"）：
   `yhat(h) = sum_k beta_k * I(h mod 24 = k)`；
2. 对照模型：带滞后项与三角季节项的岭回归、Lag-24 季节朴素法。

预测区间使用训练残差标准差：`PI80 = yhat ± 1.28*sigma`。

## 3. 基础调度模型（MILP 形式）

目标：最小化加权开工延迟与迁移时延：
`min sum_i [w1*(s_i - arrival_i) + w2*Latency(source_i, r_i)]`

约束：
- 任务分配唯一：`sum_r x_{i,r} = 1`；
- 开工窗口：`arrival_i <= s_i <= latest_start_i`；
- 时延：`Latency(source_i,r) <= MaxLatency_i`；
- GPU 容量：`sum_i GPU_Demand_i * y_{i,h} * x_{i,r} <= Available_GPU_r`；
- IT 功率：`sum_i GPU_Demand_i * y_{i,h} * p(tau_i) * x_{i,r} + NonAI <= Max_IT_Power_r`；
- 完成时限：`s_i + dur_i <= LatestFinishHour_i`。

由于全量 5 万任务的时间索引整数规划规模过大，实现采用
"先到先服务-最早可行"启发式：实时任务固定到达小时开工；
弹性任务在时延可行区域内按最早可行（区域按时延升序、开工小时升序）安置。
第 0-2375 小时任务按"本地到达即开工"推演，为最后 24 小时窗口提供残余占用。

## 4. 代码建模流程（src/q1_prediction.py, src/q1_scheduling.py）

1. 读 workload_trace.xlsx，构造逐小时逐区域逐类型 GPU 需求与 GPU 小时序列；
2. 输出 workload_statistics 表，画区域-类型 GPU 小时堆叠图与小时到达模式；
3. 逐序列训练季节均值/岭回归/季节朴素模型，验证期选优；
4. 重训并预测 2376-2399，输出预测明细、误差指标与预测区间图；
5. 读 GPU_information/network_latency/power_mapping，计算容量与功率约束；
6. 推演 0-2375 本地基准占用，调度 2376-2399 到达任务；
7. 输出 q1_schedule.csv、q1_gpu_utilization.csv，画甘特图与利用率曲线；
8. 校验时延、容量、功率、时限，保存 q1_schedule_summary.json。

## 5. 验证

- 预测：验证期与测试期 RMSE/MAE/MAPE 对比表；
- 调度：latency_violations=0、deadline_violations=0、GPU 峰值利用率 ≤100%；
- 基准对照：附件基准 GPU 利用率最高达 135.58%，说明基准本身不可行；
  本模型调度方案全部可行。
