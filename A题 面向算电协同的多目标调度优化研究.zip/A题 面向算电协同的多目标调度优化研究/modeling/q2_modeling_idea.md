# 问题2建模思路（碳感知任务调度）

## 1. 从题意到变量

题意：以 0-2399 小时实际任务与逐时电力参数为输入，决策任务迁移目标区域与
开工时段，评价运行成本、碳排放、网络时延、新能源利用率。

决策变量：
- `x_{i,r}`：任务 i 分配到区域 r（0/1）；
- `s_i`：任务开工小时（整数，非抢占，不可拆分）。

派生变量（附件1统一口径）：
- `AI_IT_Load(r,t) = sum_i GPU_Demand_i * Overlap(i,r,t) * p(tau_i)`；
- `Total_Load(r,t) = (NonAI_IT_Load(r,t)+AI_IT_Load(r,t)) * PUE(r)`；
- 可再生优先结算：购电 `GP(r,t) = max(0, TL+Chg_base+GS_base-Avail-DIS_base)`；
- 弃电 `Curtailment = Avail+DIS-TL-Chg-GS+GP`；
- 碳排 = `GP * CarbonIntensity`；电费 = `GP*Price - GS*SellPrice`。

## 2. 多目标

`min (F_cost, F_carbon, F_latency, -F_renew)`，采用加权代理目标：

`score(i,r,s) = w_cost * marginal_cost + c_carbon * marginal_carbon
              + w_lat * Latency(source,r) - w_renew * green_bonus
              + w_util * (1 - min_normalized_residual)`

其中 `marginal_cost` 只在可再生余量不足的时段计入购电成本；
`green_bonus` 用 `(0.6 - CarbonIntensity)` 截断刻画绿色区域偏好；
`w_util` 项使调度尽量均匀占用 GPU 与 IT 功率余量，保证后续任务可插入。

## 3. 求解：滚动时域贪心-修正启发式

1. 实时推理任务优先：到达小时开工，目标区域限于时延可行集；
2. 弹性任务按 GPU 小时降序处理（大任务先落位）；
3. 每个任务生成候选 (区域, 开工小时)：近期全遍历 + 吸引力 Top-K + 均匀抽样；
4. 候选按代理目标排序，取可行且综合得分最低者；
5. 无可行候选时全时域兜底扫描；
6. 每步检查 GPU 容量、IT 功率、时延、完成时限。

容量校验保留 1% GPU、0.5% IT 的安全余量，避免碎片化导致后续任务不可插入。

## 4. 代码建模流程（src/q2_scheduling.py）

1. 读入全部附件，构造逐区域逐小时价格/碳强度/可再生/非AI负荷数组；
2. 计算可再生余量 headroom、grid_frac、绿色偏好；
3. 预计算每类型每区域的吸引力小时排名；
4. 先排实时任务，再按 GPU 小时降序排弹性任务；
5. 每任务在候选集内做可行性与综合得分评估，落位并扣减余量；
6. 输出 q2_schedule.csv、迁移矩阵、延迟分布、区域 AI IT 负荷对比图；
7. 用统一口径重算成本、碳排、消纳率、峰值净购电并与基准对比。

## 5. 验证

- 全部任务满足时延、容量、功率、时限（调度器强制检查）；
- 最大 GPU 利用率 77.57% < 100%，基准高达 135.58%（基准不可行）；
- 对比指标：成本改善 697.6 万元，碳排下降 10734.8 t，消纳率提升 0.32 个百分点。
