# 问题3建模思路（储能协同优化）

## 1. 从题意到变量

题意：在给定任务调度与逐时负荷基础上（Baseline_AI_IT_Load + NonAI_IT_Load），
仅优化储能充放电、购售电与新能源分配，分析储能对成本、碳排、峰值净购电、
负荷波动的影响。

变量（每区域每小时 t=0..2406）：
- `GP(t)` 购电、`GS(t)` 售电、`DRC(t)` 可再生直接消纳；
- `RC(t)` 可再生充电、`GC(t)` 电网充电、`DIS(t)` 放电、`CUR(t)` 弃电；
- `SOC(t)` 时段末荷电状态。

## 2. 约束

- 可再生分配：`DRC + RC + GS + CUR = AvailableRenewable`；
- 电力平衡：`GP + DRC + DIS = Total_Load + GC`；
- SOC 递推：`SOC(t) = SOC(t-1) + eff_c*(RC+GC) - DIS/eff_d`；
- 充放电功率、购售电、外送边界：`RC+GC<=MaxCharge`，`DIS<=MaxDischarge`，
  `GP<=MaxGridImport`，`GS<=min(SellLimit, MaxGridExport)`；
- SOC 上下限与期末约束：`MinSOC<=SOC<=Capacity`，`SOC(2406)>=InitialSOC`。

## 3. 目标与方案

`min sum_t [GP(t)*Price(t) - GS(t)*SellPrice(t)] + 惩罚项`

方案：
- 成本最优：惩罚项为 0；
- 碳价场景：购电目标加 `carbon_price * CarbonIntensity`；
- 峰值平抑：加 `lam_peak * P`，其中 `GP(t) <= P`；
- 波动平抑：加 `lam_dev * sum(|GP(t)-ref|)`，用偏差变量线性化。

## 4. 代码建模流程（src/q3_storage.py）

1. 读 region_time_data、storage_information、GPU_information；
2. 计算给定 IT 负荷与设施负荷；
3. 对每个区域用 scipy.optimize.linprog（HiGHS）稀疏求解 4 个场景；
4. 无储能场景用可再生优先闭式结算；
5. 输出 q3_summary、q3_storage_dispatch、q3_totals；
6. 画指标对比柱状图、SOC/充放电曲线、净购电对比曲线。

## 5. 验证

- LP 全部返回 optimal；
- SOC(2406) >= InitialSOC 由约束保证；
- 与附件基准、无储能方案对比成本/碳排/峰值/CV。
