# A题 面向算电协同的多目标调度优化研究

2026年暑期培训第二次模拟题 A题完整建模交付。

## 目录

- `problem/`：赛题PDF与附件1；
- `data/`：六张附件数据表；
- `modeling/`：逐问建模思路（变量、公式、算法、验证、代码流程）；
- `src/`：全部求解与绘图代码；
- `tables/`：结果CSV；
- `figures/`：论文图件；
- `results/`：指标JSON与校验记录；
- `paper/`：`论文_C023版.docx`（按优秀论文C023模板重排，可直接使用）、
  `论文.docx`（旧版）与 `main.tex`（LaTeX源）。

## 运行顺序

```text
python src/q1_prediction.py      # 问题1统计与预测
python src/q1_scheduling.py      # 问题1最后24小时基础调度
python src/q2_scheduling.py      # 问题2碳感知任务调度
python src/q3_storage.py         # 问题3储能协同LP
python src/q4_cooptimization.py  # 问题4联合优化与场景对比（约30-40分钟）
python src/fig_extra.py          # 补充图件
python src/validate.py           # 约束校验
python src/build_paper.py        # 生成论文.docx与main.tex
```

建议在 `src/` 目录下运行，Python 3.10+，依赖 numpy、pandas、scipy、matplotlib、
python-docx（`pip install numpy pandas scipy matplotlib python-docx`）。

## 关键结论

- 附件基准为“本地到达即开工”，GPU峰值利用率最高135.58%，不满足容量约束；
- 问题1：季节均值预测模型测试期MAPE 19.31%；最后24小时538个任务调度全可行；
- 问题2：碳感知调度较基准碳排下降约11.9%，成本改善约737万元；
- 问题3：储能+可再生优先使成本由约3.0亿元改善为约-0.77亿元，消纳率提升至69.52%；
- 问题4：碳价、电价机制、新能源波动场景对比与多目标权衡见 `tables/q4_*.csv`。
