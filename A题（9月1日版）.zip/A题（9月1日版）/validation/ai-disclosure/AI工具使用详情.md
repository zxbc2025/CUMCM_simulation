# AI 工具使用详情

- 竞赛年份：2026
- 参赛模式：training
- 生成日期：2026-08-31T08:18:35.146837+00:00

> 本文档记录 AI 工具的辅助使用情况。参赛队仍需对作品的原创性、真实性和准确性负责。

## 1. 题目解读、问题卡片、依赖图、建模路线与图表登记

- 事件编号：`AI-001`
- 时间：2026-08-31T15:00:00+08:00
- 工具：Codex / deepseek-v4-pro（OpenAI）
- 使用环节：problem-framing
- 输入材料范围：赛题正文+附录1+6张附件数据表
- 关键交互记录：ai-interactions/AI-001.md
- 关联产物：mode, Q1-problem-card, Q2-problem-card, Q3-problem-card, Q4-problem-card, dependency-map, Q1-forecast-route, Q1-schedule-route, Q2-route, Q3-route, Q4-route, figure-register, visual-spec
- 采纳情况：modified
- 人工修改：团队逐阶段确认模式/卡片/路线/图表
- 人工核验：逐阶段门禁确认
- 与核心建模关系：candidate-proposal
- 外部传输：否
- 团队独立完成说明：训练模拟题，所有核心决策由团队确认

## 2. 数据审计、模型实现、求解与结果台账

- 事件编号：`AI-002`
- 时间：2026-08-31T16:00:00+08:00
- 工具：Codex / deepseek-v4-pro（OpenAI）
- 使用环节：implementation
- 输入材料范围：附件数据与已确认路线
- 关键交互记录：ai-interactions/AI-002.md
- 关联产物：data-audit, result-ledger, validation-report
- 采纳情况：modified
- 人工修改：团队复核关键数值与口径
- 人工核验：结果台账溯源校验通过
- 与核心建模关系：supporting
- 外部传输：否
- 团队独立完成说明：训练模拟题

## 3. 论文撰写、引用与图表组织

- 事件编号：`AI-003`
- 时间：2026-08-31T17:00:00+08:00
- 工具：Codex / deepseek-v4-pro（OpenAI）
- 使用环节：paper-writing
- 输入材料范围：已确认叙事与结果台账
- 关键交互记录：ai-interactions/AI-003.md
- 关联产物：narrative
- 采纳情况：modified
- 人工修改：团队确认叙事v1与摘要口径
- 人工核验：叙事门禁确认
- 与核心建模关系：supporting
- 外部传输：否
- 团队独立完成说明：训练模拟题

## 最终人工确认

- 确认人：team
- 确认时间：2026-08-31T18:00:00+08:00
- 确认结论：团队已复核 AI 使用台账记录与披露材料
