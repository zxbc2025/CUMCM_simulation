## 统一口径与基础公式

设任务 $i$ 类型为 $k_i$，在区域 $r$ 时段 $t$ 的重叠时长为 $\mathrm{Overlap}(i,r,t)$，$g_i$ 为其 GPU 需求，$p_{k_i}$ 为对应单位功率（实时 0.08 / 批量 0.10 / 训练 0.16 MW·GPU⁻¹）。统一口径公式如下。

AI IT 负荷：

$$
\mathrm{AI\_IT\_Load}(r,t)=\sum_{i} g_i\,p_{k_i}\,\mathrm{Overlap}(i,r,t)
$$

IT 负荷与设施负荷（$\rho_r$ 为 PUE）：

$$
\mathrm{IT\_Load}(r,t)=\mathrm{NonAI}(r,t)+\mathrm{AI\_IT\_Load}(r,t),\qquad
\mathrm{Total\_Load}(r,t)=\rho_r\,\mathrm{IT\_Load}(r,t)
$$

GPU 小时容量约束（每小时按实际重叠时长折算）：

$$
\sum_{i} g_i\,\mathrm{Overlap}(i,r,t)\le A_r
$$

其中 $A_r$ 为区域 $r$ 可调度 GPU 容量。区域逐时功率平衡（含储能）：

$$
\mathrm{GP}(r,t)+\mathrm{UR}(r,t)+\mathrm{Dis}(r,t)=
\mathrm{Total\_Load}(r,t)+\mathrm{Ch}(r,t)+\mathrm{GS}(r,t)+\mathrm{Curt}(r,t)
$$

式中 $\mathrm{GP},\mathrm{GS},\mathrm{UR},\mathrm{Dis},\mathrm{Ch},\mathrm{Curt}$ 分别为购电、外送、直接消纳、放电、充电与弃电功率。碳排放与电费：

$$
E=\sum_{r,t}\mathrm{GP}(r,t)\,c(r,t),\qquad
C=\sum_{r,t}\Big[\mathrm{GP}(r,t)\,p(r,t)-\mathrm{GS}(r,t)\,s(r,t)\Big]
$$

其中 $p(r,t),s(r,t),c(r,t)$ 为购电价、售电价与碳强度。新能源利用率：

$$
U=\frac{\sum_{r,t}\big(\mathrm{UR}(r,t)+\mathrm{Ch}^{\mathrm{ren}}(r,t)+\mathrm{GS}(r,t)\big)}{\sum_{r,t}\mathrm{Ren}(r,t)}
$$

储能 SOC 递推（$\eta_c,\eta_d$ 为充/放电效率，时段末口径）：

$$
\mathrm{SOC}(r,t)=\mathrm{SOC}(r,t-1)+\eta_c\,\mathrm{Ch}(r,t)-\frac{\mathrm{Dis}(r,t)}{\eta_d},\qquad
\mathrm{SOC}(r,2406)\ge \mathrm{InitialSOC}(r)
$$

## 问题一：统计、预测与基础算力调度

### 统计与预测

任务构成与 GPU 需求分布见图 F1，到达过程与自相关见图 F2。

{{figure:F1}}

{{figure:F2}}

逐时到达近似白噪声（自相关≈0，方差/均值比 0.97），故采用分位数梯度提升树 LightGBM [@ke2017]（特征=日历+滞后统计）输出条件分位数，并与历史均值、持久性基线对比；聚合 MAPE 为 {{result:R-Q1-03}}，区间覆盖率（10–90%）在聚合层达 1.00。

预测与实际对比见图 F5，误差结构见图 F6，逐区域×类型评价见表 T3。

{{figure:F5}}

{{figure:F6}}

{{table:T3}}

### 末窗口调度模型（时间索引 0-1 整数规划）

决策变量 $x_{i,r,s}\in\{0,1\}$ 表示任务 $i$ 在区域 $r$ 于整小时 $s$ 开工（实时任务固定 $s=a_i$，$a_i$ 为到达时点）。可行区域集由时延决定：$\mathcal{R}_i=\{r: L_{o_i,r}\le M_i\}$；可行开工时点集 $\mathcal{S}_i=\{s: a_i\le s\le 2406-d_i\}$。模型为：

$$
\min\ U_{\max}
$$

$$
\text{s.t.}\quad \sum_{r\in\mathcal{R}_i}\sum_{s\in\mathcal{S}_i}x_{i,r,s}=1,\quad \forall i
$$

$$
\sum_i g_i\sum_{s\in\mathcal{S}_i}\mathrm{Overlap}(i,r,s,t)\,x_{i,r,s}\le A_r,\quad \forall r,t
$$

$$
\sum_i g_i p_{k_i}\sum_{s\in\mathcal{S}_i}\mathrm{Overlap}(i,r,s,t)\,x_{i,r,s}+\mathrm{NonAI}(r,t)\le \mathrm{Max\_IT}(r),\quad \forall r,t
$$

$$
U_{\max}\ge \frac{1}{A_r}\sum_i g_i\sum_{s\in\mathcal{S}_i}\mathrm{Overlap}(i,r,s,t)\,x_{i,r,s},\quad \forall r,t
$$

目标为最小化峰值利用率 $U_{\max}$，实现跨区域负载均衡；时延、完成时限（$s+d_i\le 2406$）与实时任务"到达即开工"由可行集/固定开工隐含满足；不可抢占由区间重叠结构自动满足。求解得最晚完成 {{result:R-Q1-02}}、零越限、迁移率 74.0%，六区域末 24 时利用率均衡（34%–40%）。

甘特图见图 F3，各区域利用率见图 F4。

{{figure:F3}}

{{figure:F4}}

## 问题二：碳感知任务调度

决策变量同问题一（任务迁移区域+开工时段），内层功率分配在无储能口径下解析（消纳→外送→弃电）。多目标加权目标：

$$
\min\quad C+w_c\,E+w_l\,\Lambda+w_r\,(1-U)
$$

其中 $\Lambda$ 为 GPU-h 加权平均时延（$\Lambda=\sum_i g_i d_i L_{o_i,r_i}/\sum_i g_i d_i$）；$w_c,w_l,w_r$ 为权重。因"可用新能源普遍高于负荷"，可再生优先口径下边际购电为零，另设敏感性口径：按附件基准可再生消纳剖面 $\mathrm{UR}^{\mathrm{base}}(r,t)$ 重算成本与碳排：

$$
\tilde{C}=\sum_{r,t} p(r,t)\,\max\big(0,\ \mathrm{load}(r,t)-\mathrm{UR}^{\mathrm{base}}(r,t)\big),\qquad
\tilde{E}=\sum_{r,t} c(r,t)\,\max\big(0,\ \mathrm{load}(r,t)-\mathrm{UR}^{\mathrm{base}}(r,t)\big)
$$

求解采用两阶段启发式（倒序处理晚到任务+容量压力+收尾预留+占位腾挪修复），保证 GPU 与 IT 功率 0 越限。优化结果：全网成本 {{result:R-Q2-01}}（可再生优先口径）、碳排 {{result:R-Q2-02}}、新能源利用率 55.1%、约 63.4% 任务迁移（A/B/C→D/E/F 为主）、GPU-h 加权平均时延 23.3ms；敏感性口径成本 14.95 亿元、碳排 133.4 万吨，较基准 18.02 亿元 / 204.5 万吨分别下降 17.0% 与 34.7%。

迁移结构见图 F7，成本—时延权衡见图 F8，代表性区域负荷与购电见图 F9；指标对比见表 T4。

{{figure:F7}}

{{figure:F8}}

{{figure:F9}}

{{table:T4}}

## 问题三：储能协同优化（区域独立线性规划）

给定 IT 负荷（Baseline_AI_IT_Load + NonAI），每区域独立建立连续线性规划。逐时决策变量为 $\mathrm{GP},\mathrm{GS},\mathrm{UR},\mathrm{Ch}^{\mathrm{ren}},\mathrm{Ch}^{\mathrm{grid}},\mathrm{Dis},\mathrm{Curt},\mathrm{SOC}$，目标为最小化运行成本：

$$
\min\quad \sum_{t}\Big[\mathrm{GP}(r,t)\,p(r,t)-\mathrm{GS}(r,t)\,s(r,t)\Big]
$$

约束包括：功率平衡（见统一口径）、新能源分配 $\mathrm{UR}+\mathrm{Ch}^{\mathrm{ren}}+\mathrm{GS}+\mathrm{Curt}=\mathrm{Ren}$、SOC 递推与边界、充放电功率上限、购售电与 SellLimit 边界，以及期末约束 $\mathrm{SOC}(2406)\ge\mathrm{InitialSOC}$。结果：附件基准成本 18.02 亿元 → 无储能优化 −3.45 亿元 → 储能优化 {{result:R-Q3-01}}，碳排 {{result:R-Q3-02}}，新能源利用率提升至 78%–99%（东部约 78%，西部/新能源区 97%–99%）。

SOC/充放电曲线见图 F10，三场景对比见图 F11，指标表见表 T5。

{{figure:F10}}

{{figure:F11}}

{{table:T5}}

## 问题四：多区域算—储—电协同

将问题二调度模型与问题三储能模型统一为分解式协同优化：外层任务调度以储能 LP 的负荷影子价格（对偶变量）引导任务 (r,s) 选择，内层储能 LP 在给定负荷下优化运行，迭代至 KPI 变化小于 1%。多目标统一为六指标加权与 $\varepsilon$-约束：

$$
\min\quad \lambda_1\hat{C}+\lambda_2\hat{E}+\lambda_3\hat{\Lambda}+\lambda_4(1-\hat{U})+\lambda_5\hat{\mathrm{Pk}}+\lambda_6\hat{\mathrm{Var}}
$$

其中 $\hat{\cdot}$ 为归一化，$\mathrm{Pk}$ 为区域峰值净购电，$\mathrm{Var}$ 为净购电波动。场景对比设碳约束（无/60%）、电价机制（TOU/平均/高波动）与新能源波动（基准/±30%/平滑）三组。基准场景成本 {{result:R-Q4-01}}、迁移率 63.4%、时延 23.3ms；新能源 −30% 承压场景碳排 {{result:R-Q4-02}}、峰值净购电 509MW，碳约束（60% 限）在此场景仅小幅降碳（3.30 万→3.20 万吨）。

场景矩阵热力图见图 F12，优化与基准雷达对比见图 F13，迁移率与储能电量见图 F14，场景结果表见表 T6。

{{figure:F12}}

{{figure:F13}}

{{figure:F14}}

{{table:T6}}

