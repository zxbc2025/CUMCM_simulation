| 类别 | 符号 | 含义 |
|---|---|---|
| 集合 | $\mathcal{R}$ | 六区域集合 RegionA-F |
| 集合 | $\mathcal{T}$ | 小时集合 0-2406（主时域 0-2399，收尾 2400-2405） |
| 集合 | $\mathcal{I}$ | 任务集合（50000 个） |
| 参数 | $a_i,d_i,g_i,k_i,o_i$ | 任务到达时点/时长/GPU 需求/类型/来源区域 |
| 参数 | $M_i, L_{o,r}$ | 任务最大时延 / 来源到执行区域单向时延 |
| 参数 | $A_r, U_r, \rho_r$ | 可调度 GPU 容量 / 最大 IT 功率 / PUE |
| 参数 | $p_r(t), s_r(t), c_r(t)$ | 购电价 / 售电价 / 碳强度 |
| 参数 | $\mathrm{Ren}_r(t)$ | 可用新能源出力 |
| 参数 | $C_r, \underline{S}_r, S_r^0$ | 储能容量 / SOC 下限 / 初始 SOC |
| 变量 | $x_{i,r}, z_{i,s}$ | 任务区域指派 / 开工时点决策 |
| 变量 | $\mathrm{GP},\mathrm{GS},\mathrm{UR},\mathrm{Curt}$ | 购电 / 外送 / 直接消纳 / 弃电功率 |
| 变量 | $\mathrm{Ch},\mathrm{Dis},\mathrm{SOC}$ | 充 / 放电功率与 SOC |
| 指标 | $\eta_{\mathrm{ren}}$ | 新能源利用率 |
