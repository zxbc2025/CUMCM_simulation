import os, re, json
work = r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work"
ms = open(os.path.join(work, "paper", "manuscript.md"), encoding="utf-8").read()
ledger = json.load(open(os.path.join(work, "result-ledger.json"), encoding="utf-8"))
fr = json.load(open(os.path.join(work, "figure-register.json"), encoding="utf-8"))
tr = json.load(open(os.path.join(work, "table-register.json"), encoding="utf-8"))
entries = {e["id"]: e for e in ledger["results"]}
figs = {f["id"]: f for f in fr["figures"]}
tabs = {t["id"]: t for t in tr["tables"]}
def render_result(e):
    v = e["value"]; d = e.get("display_digits")
    vt = ("{:.%df}" % d).format(v) if (d is not None and isinstance(v, (int, float))) else str(v)
    return (vt + " " + str(e.get("unit", ""))).strip()
def render_figure(e):
    out = os.path.join(work, e["output_file"]).replace("\\", "/")
    cap = e.get("caption") or e["claim"]
    return "![%s](%s){#fig:%s}" % (cap, out, e["id"])
def render_table(e):
    body = open(os.path.join(work, e["source_file"]), encoding="utf-8").read().strip()
    cap = e.get("caption", "")
    label = ("Table: %s {#tbl:%s}" % (cap, e["id"])) if cap else ("{#tbl:%s}" % e["id"])
    return body + "\n\n" + label
def sub(m):
    kind, ident = m.group(1), m.group(2)
    if kind == "result": return render_result(entries[ident])
    if kind == "figure": return render_figure(figs[ident])
    if kind == "table": return render_table(tabs[ident])
    return m.group(0)
resolved = re.sub(r"\{\{(result|figure|table):([A-Za-z0-9_.-]+)\}\}", sub, ms)
open(os.path.join(work, "build", "manuscript.resolved.md"), "w", encoding="utf-8").write(resolved)
idx = resolved.find("F14")
print(resolved[max(0, idx-800):idx+150])
