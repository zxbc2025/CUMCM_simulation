# -*- coding: utf-8 -*-
import os, sys, time
sys.path.insert(0, r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\code")
import q2_schedule as q2
import numpy as np

def ev(sched):
    m = q2.evaluate(sched)
    tot_gh = float(np.sum(sched["GPU"] * sched["EstimatedDuration_min"] / 60.0))
    m["avg_latency_ms"] = m["latency"] / tot_gh
    m["migration_rate"] = float((sched["SourceRegion"] != sched["Region"]).mean())
    return m

combos = [(0.30,0.0),(0.15,0.0),(0.10,0.0),(0.05,0.0),(0.02,0.0),(0.0,0.0),(0.10,0.02),(0.05,0.02)]
for lw, pw in combos:
    t0 = time.time()
    sched, _, _ = q2.run_schedule(lat_weight=lw, carbon_weight=0.0, pressure_weight=pw)
    m = ev(sched)
    print("lat=%.2f press=%.2f | mig=%.3f avg_lat=%.1fms cost_sens=%.1e carbon_sens=%.1e | %.1fs" % (
        lw, pw, m["migration_rate"], m["avg_latency_ms"], m["cost_sens"], m["carbon_sens"], time.time()-t0))
