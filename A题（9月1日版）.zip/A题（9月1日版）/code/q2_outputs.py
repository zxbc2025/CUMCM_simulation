# -*- coding: utf-8 -*-
import os, sys, json
import numpy as np, pandas as pd
sys.path.insert(0, r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\code")
import q2_schedule as q2
from common import REGIONS, RESULTS, FIGURES, duration_hours
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from style import save, REGION_LABEL

src = r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\results\q2_schedule_diag.csv"
sched = pd.read_csv(src)
sched.to_csv(os.path.join(RESULTS, "q2_schedule.csv"), index=False, encoding="utf-8-sig")

m = q2.evaluate(sched)
tot_gh = float(np.sum(sched["GPU"] * (sched["FinishHour"] - sched["StartHour"])))
m["avg_latency_ms"] = m["latency"] / tot_gh
m["migration_rate"] = float((sched["SourceRegion"] != sched["Region"]).mean())
gh2, pw2 = q2._usage(sched.to_dict("records"))
m["gpu_viol"] = int(np.sum(gh2 > q2.CAP_GPU[:, None] + 1e-6))
m["it_viol"] = int(np.sum(pw2 > (q2.CAP_IT[:, None] - q2.NONAI) + 1e-6))
print("主方案:", {k: (round(v,4) if isinstance(v,float) else v) for k,v in m.items() if k in ["cost","carbon","cost_sens","carbon_sens","renew_util","avg_latency_ms","migration_rate","gpu_viol","it_viol"]})

# 基线(附件 0-2405)
rt = q2.rt
rt2 = rt.copy(); rt2["cost"] = rt2["ElectricityPrice_CNY_per_MWh"]*rt2["GridPurchase_MW"] - rt2["SellPrice_CNY_per_MWh"]*rt2["GridSell_MW"]
main = rt2[rt2["Hour"] <= 2405]
base = dict(scenario="baseline", cost=main["cost"].sum(), carbon=main["CarbonEmission_tCO2"].sum(),
            renew_util=(main["UsedRenewable_MW"]+main["RenewableCharge_MW"]+main["GridSell_MW"]).sum()/main["AvailableRenewable_MW"].sum()*100,
            latency=float("nan"), migration_rate=0.0, grid_purchase=main["GridPurchase_MW"].sum(), cost_sens=float("nan"), carbon_sens=float("nan"))
opt = dict(scenario="optimized", **{k: m[k] for k in ["cost","carbon","renew_util","latency","migration_rate","grid_purchase","cost_sens","carbon_sens"]})
pd.DataFrame([base, opt]).to_csv(os.path.join(RESULTS, "q2_compare.csv"), index=False, encoding="utf-8-sig")

# pareto: lat3(主) + lat0(后台结果, 若已生成)
rows = []
rows.append(dict(lat_weight=3.0, cost=m["cost"], carbon=m["carbon"], latency=m["latency"], avg_latency_ms=m["avg_latency_ms"], renew_util=m["renew_util"], migration_rate=m["migration_rate"], cost_sens=m["cost_sens"], carbon_sens=m["carbon_sens"]))
lat0f = os.path.join(RESULTS, "q2_lat0_metrics.json")
if os.path.exists(lat0f):
    j = json.load(open(lat0f, encoding="utf-8"))
    rows.append(dict(lat_weight=0.0, cost=j["cost"], carbon=j["carbon"], latency=j["latency"], avg_latency_ms=j["avg_latency_ms"], renew_util=j["renew_util"], migration_rate=j["migration_rate"], cost_sens=j["cost_sens"], carbon_sens=j["carbon_sens"]))
pd.DataFrame(rows).to_csv(os.path.join(RESULTS, "q2_pareto.csv"), index=False, encoding="utf-8-sig")
print("pareto rows:", len(rows))

# F7 迁移热力图
ct = pd.crosstab(sched["SourceRegion"], sched["Region"])[REGIONS]
fig, ax = plt.subplots(figsize=(6.5,5))
im = ax.imshow(ct.values, cmap="Blues", aspect="auto")
ax.set_xticks(range(6)); ax.set_xticklabels([REGION_LABEL[r] for r in REGIONS])
ax.set_yticks(range(6)); ax.set_yticklabels([REGION_LABEL[r] for r in REGIONS])
for i in range(6):
    for j in range(6):
        ax.text(j, i, f"{ct.values[i,j]}", ha="center", va="center", fontsize=8)
ax.set_xlabel("执行区域"); ax.set_ylabel("来源区域"); ax.set_title("任务迁移结构 (来源→执行, 任务数)")
fig.colorbar(im, ax=ax)
save(fig, os.path.join(FIGURES, "F7.pdf"))

# F8 成本-时延散点
pareto = pd.DataFrame(rows)
if len(pareto) >= 2:
    fig, ax = plt.subplots(figsize=(6.5,4.2))
    sc = ax.scatter(pareto["avg_latency_ms"], pareto["cost"]/1e6, c=pareto["migration_rate"], cmap="viridis", s=70)
    for _, r in pareto.iterrows():
        ax.annotate(f"λ={r['lat_weight']:.1f}", (r["avg_latency_ms"], r["cost"]/1e6), fontsize=8, xytext=(4,4), textcoords="offset points")
    ax.set_xlabel("GPU-h加权平均时延 (ms)"); ax.set_ylabel("运行成本 (百万元)")
    ax.set_title("成本—时延权衡 (敏感性口径)")
    fig.colorbar(sc, ax=ax, label="迁移率")
    save(fig, os.path.join(FIGURES, "F8.pdf"))

# F9 RegionD 曲线
ai = np.zeros((6, q2.NH))
for row in sched.itertuples():
    ri = q2.RIDX[row.Region]; d = duration_hours(row.EstimatedDuration_min); g = row.GPU; p = q2.POWER_MAP[row.TaskType]
    s0 = float(row.StartHour)
    hours = np.arange(int(np.floor(s0)), int(np.ceil(s0+d)))
    hours = hours[(hours>=0)&(hours<q2.NH)]
    for t in hours:
        ai[ri,t] += g*p*max(0.0, min(s0+d,t+1)-max(s0,t))
load_opt = q2.NONAI + ai
gp_opt = np.maximum(load_opt - q2.REN, 0)
rtidx = rt.set_index(["Region","Hour"])
load_base = np.array([rtidx.loc[(r,h),"NonAI_IT_Load_MW"] + rtidx.loc[(r,h),"Baseline_AI_IT_Load_MW"] for r in REGIONS for h in range(2406)]).reshape(6,2406)*np.array([q2.gpu.loc[r,"PUE"] for r in REGIONS])[:,None]
gp_base = np.array([rtidx.loc[(r,h),"GridPurchase_MW"] for r in REGIONS for h in range(2406)]).reshape(6,2406)
fig, axes = plt.subplots(2,1,figsize=(10,6))
ri = q2.RIDX["RegionD"]
axes[0].plot(np.arange(2406), load_opt[ri], color="#0072B2", lw=0.7, label="优化 IT 负荷")
axes[0].plot(np.arange(2406), load_base[ri], color="#999999", lw=0.7, ls="--", label="基准 IT 负荷")
axes[0].set_ylabel("MW"); axes[0].set_title("RegionD 逐时 IT 负荷 (优化 vs 基准)"); axes[0].legend(fontsize=8)
axes[1].plot(np.arange(2406), gp_opt[ri], color="#D55E00", lw=0.7, label="优化购电")
axes[1].plot(np.arange(2406), gp_base[ri], color="#999999", lw=0.7, ls="--", label="基准购电")
axes[1].set_xlabel("小时"); axes[1].set_ylabel("MW"); axes[1].set_title("RegionD 逐时购电 (优化 vs 基准)"); axes[1].legend(fontsize=8)
save(fig, os.path.join(FIGURES, "F9.pdf"))
print("Q2 输出固化完成")
