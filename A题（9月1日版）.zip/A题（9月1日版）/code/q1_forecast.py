# -*- coding: utf-8 -*-
"""Q1 短期预测: 分位数LightGBM, 严格切分, 基线对比 (F5, F6, q1_forecast.csv, q1_metrics.csv)."""
import os, sys, json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load_workload, REGIONS, TYPES, RESULTS, FIGURES, hour_series_by_region_type
from style import save, TYPE_COLOR, TYPE_LABEL, REGION_LABEL
import lightgbm as lgb

wt = load_workload()
series = hour_series_by_region_type(wt, metric="GPU_Demand")  # (region,type)->长度2400

TRAIN_END, VAL_END, TEST_START, TEST_END = 2352, 2376, 2376, 2400

def features(ser, t):
    hod = t % 24
    return np.array([
        hod, np.sin(2*np.pi*hod/24), np.cos(2*np.pi*hod/24),
        t // 24,  # 天数
        ser[t-1] if t >= 1 else 0.0,
        ser[t-24] if t >= 24 else ser[t-1] if t >= 1 else 0.0,
        float(np.mean(ser[max(0,t-24):t])) if t >= 1 else 0.0,
    ], dtype=float)

def build_matrix(ser, lo, hi):
    X, y = [], []
    for t in range(lo, hi):
        X.append(features(ser, t)); y.append(ser[t])
    return np.array(X), np.array(y)

def train_quantile(ser, alpha, Xtr, ytr, Xva, yva):
    model = lgb.LGBMRegressor(objective="quantile", alpha=alpha, n_estimators=300,
                              learning_rate=0.05, num_leaves=15, min_child_samples=5,
                              subsample=0.8, colsample_bytree=0.8, random_state=42, verbose=-1)
    model.fit(Xtr, ytr, eval_set=[(Xva, yva)],
              callbacks=[lgb.early_stopping(50, verbose=False)])
    return model

records = []
for (r, k), ser in series.items():
    Xtr, ytr = build_matrix(ser, 0, TRAIN_END)
    Xva, yva = build_matrix(ser, TRAIN_END, VAL_END)
    # 调参阶段: 在验证集上早停
    m_lo  = train_quantile(ser, 0.10, Xtr, ytr, Xva, yva)
    m_mid = train_quantile(ser, 0.50, Xtr, ytr, Xva, yva)
    m_hi  = train_quantile(ser, 0.90, Xtr, ytr, Xva, yva)
    # 重训: 0-2375
    Xtr2, ytr2 = build_matrix(ser, 0, TEST_START)
    for m in (m_lo, m_mid, m_hi):
        m.set_params(n_estimators=m.best_iteration_)
        m.fit(Xtr2, ytr2)
    Xte, yte = build_matrix(ser, TEST_START, TEST_END)
    p_lo  = np.maximum(m_lo.predict(Xte), 0)
    p_mid = np.maximum(m_mid.predict(Xte), 0)
    p_hi  = np.maximum(m_hi.predict(Xte), 0)
    # 基线: 历史均值(0-2375) 与 持久性(前24h滚动均值, 因果)
    hist_mean = float(np.mean(ytr2))
    persist = np.array([float(np.mean(ser[max(0,t-24):t])) if t >= 1 else hist_mean for t in range(TEST_START, TEST_END)])
    for j, t in enumerate(range(TEST_START, TEST_END)):
        records.append(dict(hour=t, region=r, type=k, actual=yte[j],
                            pred_low=p_lo[j], pred_med=p_mid[j], pred_high=p_hi[j],
                            baseline_histmean=hist_mean, baseline_persist=persist[j]))
    mape_m = np.mean(np.abs(p_mid-yte)/np.maximum(yte, 1.0))*100
    mape_p = np.mean(np.abs(persist-yte)/np.maximum(yte, 1.0))*100
    mape_h = np.mean(np.abs(hist_mean-yte)/np.maximum(yte, 1.0))*100
    rmse_m = float(np.sqrt(np.mean((p_mid-yte)**2)))
    picp = float(np.mean((yte >= p_lo) & (yte <= p_hi)))
    print(f"{r} {k}: MAPE_model={mape_m:.1f}% persist={mape_p:.1f}% histmean={mape_h:.1f}% RMSE={rmse_m:.1f} PICP={picp:.2f}")

df = pd.DataFrame(records)
df.to_csv(os.path.join(RESULTS, "q1_forecast.csv"), index=False, encoding="utf-8-sig")

# 聚合指标(全网/按类型)
agg = df.groupby(["hour"]).agg(actual=("actual","sum"), pred_med=("pred_med","sum"), pred_low=("pred_low","sum"), pred_high=("pred_high","sum"), base_h=("baseline_histmean","sum"), base_p=("baseline_persist","sum"))
mape = lambda a,p: float(np.mean(np.abs(p-a)/np.maximum(a,1.0))*100)
metrics = {
  "aggregate": {"MAPE_model": mape(agg["actual"], agg["pred_med"]),
                 "MAPE_persist": mape(agg["actual"], agg["base_p"]),
                 "MAPE_histmean": mape(agg["actual"], agg["base_h"]),
                 "RMSE_model": float(np.sqrt(np.mean((agg["actual"]-agg["pred_med"])**2))),
                 "PICP": float(np.mean((agg["actual"]>=agg["pred_low"])&(agg["actual"]<=agg["pred_high"])))}
}
# 区域x类型指标
g = df.groupby(["region","type"])
mt = pd.DataFrame({
  "MAPE_model": g.apply(lambda d: np.mean(np.abs(d["pred_med"]-d["actual"])/np.maximum(d["actual"],1.0))*100, include_groups=False),
  "MAPE_persist": g.apply(lambda d: np.mean(np.abs(d["baseline_persist"]-d["actual"])/np.maximum(d["actual"],1.0))*100, include_groups=False),
  "MAPE_histmean": g.apply(lambda d: np.mean(np.abs(d["baseline_histmean"]-d["actual"])/np.maximum(d["actual"],1.0))*100, include_groups=False),
  "RMSE_model": g.apply(lambda d: np.sqrt(np.mean((d["pred_med"]-d["actual"])**2)), include_groups=False),
  "PICP": g.apply(lambda d: np.mean((d["actual"]>=d["pred_low"])&(d["actual"]<=d["pred_high"])), include_groups=False),
})
mt.round(2).to_csv(os.path.join(RESULTS, "q1_metrics.csv"), encoding="utf-8-sig")
print("aggregate:", metrics["aggregate"])

# ---------- F5: 预测 vs 实际 (全网 + 按类型) ----------
df["type_label"] = df["type"].map(TYPE_LABEL)
fig, axes = plt.subplots(2, 2, figsize=(10, 6.5))
panels = [("全网", df), ("RealTimeInference", df[df["type"]=="RealTimeInference"]),
          ("BatchInference", df[df["type"]=="BatchInference"]), ("AITraining", df[df["type"]=="AITraining"])]
for ax, (title, sub) in zip(axes.ravel(), panels):
    g2 = sub.groupby("hour").agg(a=("actual","sum"), lo=("pred_low","sum"), md=("pred_med","sum"), hi=("pred_high","sum"))
    ax.fill_between(g2.index, g2["lo"], g2["hi"], color="#0072B2", alpha=0.25, label="10–90% 区间")
    ax.plot(g2.index, g2["md"], color="#D55E00", lw=1.2, label="预测中位数")
    ax.plot(g2.index, g2["a"], color="#000000", lw=1.0, ls="--", label="实际")
    ax.set_title(title); ax.set_xlabel("小时"); ax.set_ylabel("GPU 需求")
    ax.legend(fontsize=7)
fig.suptitle("第 2376–2399 小时 GPU 需求预测 vs 实际")
save(fig, os.path.join(FIGURES, "F5.pdf"))

# ---------- F6: 误差热力图 ----------
pv = mt["MAPE_model"].unstack()[TYPES]
pv_b = mt["MAPE_persist"].unstack()[TYPES]
fig, axes = plt.subplots(1, 2, figsize=(9, 3.6))
for ax, mat, title in [(axes[0], pv, "模型 MAPE (%)"), (axes[1], pv_b, "持久性基线 MAPE (%)")]:
    im = ax.imshow(mat.values, cmap="YlOrRd", aspect="auto")
    ax.set_xticks(range(3)); ax.set_xticklabels([TYPE_LABEL[k] for k in TYPES])
    ax.set_yticks(range(6)); ax.set_yticklabels([REGION_LABEL[r] for r in REGIONS])
    for i in range(6):
        for j in range(3):
            ax.text(j, i, f"{mat.values[i,j]:.0f}", ha="center", va="center", fontsize=8)
    ax.set_title(title); fig.colorbar(im, ax=ax)
save(fig, os.path.join(FIGURES, "F6.pdf"))
print("Q1 预测完成")
