# -*- coding: utf-8 -*-
import os, sys, time
sys.path.insert(0, r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\code")
import q2_schedule as q2
import numpy as np, pandas as pd, json
t0=time.time()
sched, gh, pw = q2.run_schedule(lat_weight=0.0, carbon_weight=0.0)
m = q2.evaluate(sched)
tot_gh = float(np.sum(sched['GPU']*(sched['FinishHour']-sched['StartHour'])))
m['avg_latency_ms'] = m['latency']/tot_gh
m['migration_rate'] = float((sched['SourceRegion']!=sched['Region']).mean())
gh2,pw2 = q2._usage(sched.to_dict('records'))
m['gpu_viol'] = int(np.sum(gh2 > q2.CAP_GPU[:,None]+1e-6)); m['it_viol'] = int(np.sum(pw2 > (q2.CAP_IT[:,None]-q2.NONAI)+1e-6))
json.dump({k: (float(v) if isinstance(v,(int,float,np.floating)) else v) for k,v in m.items()}, open(r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\results\q2_lat0_metrics.json",'w'))
print('lat0 done', round(time.time()-t0,1), 's', {k: round(v,3) if isinstance(v,float) else v for k,v in m.items() if k in ['migration_rate','avg_latency_ms','cost_sens','gpu_viol','it_viol']})
