# -*- coding: utf-8 -*-
"""Q1 统计分析: 需求画像 + 到达过程特征 (F1, F2, q1_stats.csv, q1_arrival.csv)."""
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (load_workload, REGIONS, TYPES, RESULTS, FIGURES, WORK)
from style import save, TYPE_COLOR, TYPE_LABEL, REGION_LABEL

wt = load_workload()

# ---------- 1) 区域x类型统计画像 ----------
wt2 = wt.copy()
wt2["gpu_h"] = wt2["GPU_Demand"] * wt2["EstimatedDuration_min"] / 60.0
rows = []
for r in REGIONS:
    for k in TYPES:
        sub = wt2[(wt2["SourceRegion"] == r) & (wt2["TaskType"] == k)]
        rows.append({
            "Region": r, "TaskType": k,
            "TaskCount": len(sub),
            "GPU_Sum": round(sub["GPU_Demand"].sum(), 0),
            "GPU_Mean": round(sub["GPU_Demand"].mean(), 2),
            "GPU_Median": round(sub["GPU_Demand"].median(), 2),
            "GPU_Max": round(sub["GPU_Demand"].max(), 2),
            "GPUhour_Sum": round(sub["gpu_h"].sum(), 1),
            "Dur_Mean_min": round(sub["EstimatedDuration_min"].mean(), 1),
        })
stats = pd.DataFrame(rows)
stats.to_csv(os.path.join(RESULTS, "q1_stats.csv"), index=False, encoding="utf-8-sig")

# 汇总数字
type_counts = wt["TaskType"].value_counts()
print("任务总数:", len(wt))
print("类型构成:", type_counts.to_dict())
print("来源构成:", wt["SourceRegion"].value_counts().to_dict())
print("GPU需求描述:", wt["GPU_Demand"].describe().round(2).to_dict())
print("GPU需求按类型:", wt.groupby("TaskType")["GPU_Demand"].agg(["mean", "median", "max"]).round(1).to_dict("index"))

# ---------- 2) 到达过程 ----------
cnt = wt["ArrivalHour"].value_counts().sort_index()
cnt = cnt.reindex(range(2400), fill_value=0)
gpu_h = wt2.groupby("ArrivalHour")["gpu_h"].sum().reindex(range(2400), fill_value=0.0)
arrival = pd.DataFrame({"hour": np.arange(2400), "task_count": cnt.values, "gpu_hour": gpu_h.values})
arrival.to_csv(os.path.join(RESULTS, "q1_arrival.csv"), index=False, encoding="utf-8-sig")

# 自相关
x = gpu_h.values.astype(float)
lags = [1, 2, 3, 24, 48, 72, 168]
ac = [float(np.corrcoef(x[:-k], x[k:])[0, 1]) for k in lags if k < len(x)]
acf = pd.DataFrame({"lag": lags, "acf": [round(a, 3) for a in ac]})
print("自相关:", dict(zip(lags, [round(a, 3) for a in ac])))
print("逐时到达数 min/max/mean:", cnt.min(), cnt.max(), round(cnt.mean(), 1))
print("方差/均值比:", round(float(cnt.var() / cnt.mean()), 2))
print("逐时GPU-hour min/max/mean:", round(float(gpu_h.min()), 1), round(float(gpu_h.max()), 1), round(float(gpu_h.mean()), 1))

# ---------- F1: 任务构成 + GPU需求分布 ----------
fig, axes = plt.subplots(1, 2, figsize=(9, 3.6))
# 左: 区域堆叠柱状(按类型任务数)
pivot = pd.crosstab(wt["SourceRegion"], wt["TaskType"])[TYPES]
bottom = np.zeros(len(REGIONS))
for k in TYPES:
    axes[0].bar(REGIONS, pivot[k], bottom=bottom, label=TYPE_LABEL[k], color=TYPE_COLOR[k], width=0.62)
    bottom += pivot[k].values
axes[0].set_xticks(range(len(REGIONS))); axes[0].set_xticklabels([REGION_LABEL[r] for r in REGIONS], rotation=0)
axes[0].set_ylabel("任务数")
axes[0].set_title("各区域任务构成")
axes[0].legend()
# 右: GPU需求按类型箱线图
bp = axes[1].boxplot([wt[wt["TaskType"] == k]["GPU_Demand"].values for k in TYPES],
                     tick_labels=[TYPE_LABEL[k] for k in TYPES], patch_artist=True, showfliers=False)
for patch, k in zip(bp["boxes"], TYPES):
    patch.set_facecolor(TYPE_COLOR[k])
    patch.set_alpha(0.7)
axes[1].set_ylabel("GPU 需求 (等效GPU)")
axes[1].set_title("GPU 需求分布")
save(fig, os.path.join(FIGURES, "F1.pdf"))

# ---------- F2: 到达序列 + 自相关 ----------
fig, axes = plt.subplots(2, 1, figsize=(9, 6), gridspec_kw={"height_ratios": [2, 1]})
axes[0].plot(arrival["hour"], arrival["gpu_hour"], color="#444444", lw=0.8)
axes[0].axhline(gpu_h.mean(), color="#D55E00", ls="--", lw=1, label="均值")
axes[0].set_xlabel("小时 (0–2399)")
axes[0].set_ylabel("到达 GPU-hour")
axes[0].set_title("逐时到达 GPU-hour 需求序列")
axes[0].legend()
ax2 = axes[1]
ax2.bar(acf["lag"], acf["acf"], width=6, color="#0072B2")
ax2.axhline(0, color="k", lw=0.8)
ax2.set_xlabel("滞后 (小时)")
ax2.set_ylabel("自相关系数")
ax2.set_title("GPU-hour 序列自相关 (ACF)")
save(fig, os.path.join(FIGURES, "F2.pdf"))

print("Q1 统计完成")
