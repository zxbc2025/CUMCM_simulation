# -*- coding: utf-8 -*-
p = r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\code\q2_schedule.py"
s = open(p, encoding="utf-8").read()

# 1) 加载基准可再生消纳 UsedRenewable 并计算敏感性边际
old = '''REN = np.zeros((N_REG, NH)); NONAI = np.zeros((N_REG, NH)); BAI = np.zeros((N_REG, NH))
for r in REGIONS:
    sub = rt[rt["Region"] == r].set_index("Hour")
    h = np.arange(NH)
    P[RIDX[r], h] = sub.loc[h, "ElectricityPrice_CNY_per_MWh"].values
    SP[RIDX[r], h] = sub.loc[h, "SellPrice_CNY_per_MWh"].values
    CI[RIDX[r], h] = sub.loc[h, "CarbonIntensity_tCO2_per_MWh"].values
    REN[RIDX[r], h] = sub.loc[h, "AvailableRenewable_MW"].values
    NONAI[RIDX[r], h] = sub.loc[h, "NonAI_IT_Load_MW"].values
    BAI[RIDX[r], h] = sub.loc[h, "Baseline_AI_IT_Load_MW"].values'''
new = '''REN = np.zeros((N_REG, NH)); NONAI = np.zeros((N_REG, NH)); BAI = np.zeros((N_REG, NH)); UREN_BASE = np.zeros((N_REG, NH))
for r in REGIONS:
    sub = rt[rt["Region"] == r].set_index("Hour")
    h = np.arange(NH)
    P[RIDX[r], h] = sub.loc[h, "ElectricityPrice_CNY_per_MWh"].values
    SP[RIDX[r], h] = sub.loc[h, "SellPrice_CNY_per_MWh"].values
    CI[RIDX[r], h] = sub.loc[h, "CarbonIntensity_tCO2_per_MWh"].values
    REN[RIDX[r], h] = sub.loc[h, "AvailableRenewable_MW"].values
    NONAI[RIDX[r], h] = sub.loc[h, "NonAI_IT_Load_MW"].values
    BAI[RIDX[r], h] = sub.loc[h, "Baseline_AI_IT_Load_MW"].values
    UREN_BASE[RIDX[r], h] = sub.loc[h, "UsedRenewable_MW"].values'''
assert old in s
s = s.replace(old, new)

# 2) set_scenario 重算敏感性边际
old2 = '''    MRG_P = np.zeros_like(P); MRG_C = np.zeros_like(P)
    for ri in range(N_REG):
        sh = shortfall_share(ri, np.arange(NH))
        MRG_P[ri] = P[ri] * sh
        MRG_C[ri] = CI[ri] * sh'''
new2 = '''    MRG_P = np.zeros_like(P); MRG_C = np.zeros_like(P)
    MRG_P_SENS = np.zeros_like(P); MRG_C_SENS = np.zeros_like(P)
    for ri in range(N_REG):
        sh = shortfall_share(ri, np.arange(NH))
        MRG_P[ri] = P[ri] * sh
        MRG_C[ri] = CI[ri] * sh
        # 敏感性口径: 按基准可再生消纳剖面, 新增负荷按购电价/碳强度全额计入
        with np.errstate(divide="ignore", invalid="ignore"):
            shs = np.where(LOAD_EST[ri] > 0, np.maximum(0, LOAD_EST[ri] - UREN_BASE[ri]) / LOAD_EST[ri], 0.0)
        MRG_P_SENS[ri] = P[ri] * shs
        MRG_C_SENS[ri] = CI[ri] * shs'''
assert old2 in s
s = s.replace(old2, new2)

# 3) 模块级初始化敏感性矩阵 (在 MRG 计算处)
old3 = '''MRG_P = np.zeros((N_REG, NH)); MRG_C = np.zeros((N_REG, NH))
for ri in range(N_REG):
    sh = shortfall_share(ri, np.arange(NH))
    MRG_P[ri] = P[ri] * sh
    MRG_C[ri] = CI[ri] * sh'''
new3 = '''MRG_P = np.zeros((N_REG, NH)); MRG_C = np.zeros((N_REG, NH))
MRG_P_SENS = np.zeros((N_REG, NH)); MRG_C_SENS = np.zeros((N_REG, NH))
for ri in range(N_REG):
    sh = shortfall_share(ri, np.arange(NH))
    MRG_P[ri] = P[ri] * sh
    MRG_C[ri] = CI[ri] * sh
    with np.errstate(divide="ignore", invalid="ignore"):
        shs = np.where(LOAD_EST[ri] > 0, np.maximum(0, LOAD_EST[ri] - UREN_BASE[ri]) / LOAD_EST[ri], 0.0)
    MRG_P_SENS[ri] = P[ri] * shs
    MRG_C_SENS[ri] = CI[ri] * shs'''
assert old3 in s
s = s.replace(old3, new3)

# 4) run_schedule 的 cost/carbon 项改用敏感性口径
old4 = "score = np.sum(gh_add * (MRG_P[ri_arr][:, hours] + carbon_weight * MRG_C[ri_arr][:, hours]), axis=1) \\"
new4 = "score = np.sum(gh_add * (MRG_P_SENS[ri_arr][:, hours] + carbon_weight * MRG_C_SENS[ri_arr][:, hours]), axis=1) \\"
assert old4 in s
s = s.replace(old4, new4)
open(p, "w", encoding="utf-8").write(s)
print("q2_schedule.py sensitivity caliber added")
