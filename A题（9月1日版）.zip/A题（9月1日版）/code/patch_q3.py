# -*- coding: utf-8 -*-
p = r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\code\q3_storage.py"
s = open(p, encoding="utf-8").read()

# 1) no_storage / optimized 均改用纯成本目标
old = 'res_op, n, idx, Pk, L, P, SP, C = solve_region(r, no_storage=False, weights=(0.5,0.2,0.2,0.1), denom=denom)'
new = 'res_op, n, idx, Pk, L, P, SP, C = solve_region(r, no_storage=False, weights=(1.0,0.0,0.0,0.0), denom=denom)'
assert old in s, "optimized weights line not found"
s = s.replace(old, new)

# 2) metrics 增加 renew_util: 需要 R 数组; 在 main 循环中由 curves 计算
old_loop = '''    x = res_op.x
    curves = []
    for t in range(N):
        curves.append(dict(Hour=t, Region=r, SOC=x[idx(t,7)], Charge=x[idx(t,3)]+x[idx(t,4)],
                           Discharge=x[idx(t,6)], GridPurchase=x[idx(t,0)], GridSell=x[idx(t,1)],
                           UsedRenewable=x[idx(t,2)], Curtailment=x[idx(t,5)], NetImport=x[idx(t,0)]-x[idx(t,1)]))
    opt_curves.append(pd.DataFrame(curves))'''
new_loop = '''    x = res_op.x
    curves = []
    for t in range(N):
        curves.append(dict(Hour=t, Region=r, SOC=x[idx(t,7)], Charge=x[idx(t,3)]+x[idx(t,4)],
                           Discharge=x[idx(t,6)], GridPurchase=x[idx(t,0)], GridSell=x[idx(t,1)],
                           UsedRenewable=x[idx(t,2)], Curtailment=x[idx(t,5)], NetImport=x[idx(t,0)]-x[idx(t,1)]))
    cdf = pd.DataFrame(curves)
    m_op["renew_util"] = round((cdf["UsedRenewable"].sum() + cdf["GridSell"].sum()) / R.sum() * 100, 1)
    opt_curves.append(cdf)'''
assert old_loop in s, "loop block not found"
s = s.replace(old_loop, new_loop)
open(p, "w", encoding="utf-8").write(s)
print("q3_storage.py patched for pure cost + renew_util")
