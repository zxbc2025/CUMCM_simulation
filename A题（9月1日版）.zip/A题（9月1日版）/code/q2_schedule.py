# -*- coding: utf-8 -*-
"""Q2 碳感知调度: 滚动-贪心构造 + 精确功率评估 + 碳权重扫描 (F7-F9, q2_schedule.csv, q2_compare.csv, q2_pareto.csv).
注: 全时域5万任务MILP在开源求解器下不可行, 本实现采用已确认的加权目标(成本/碳/时延)在贪心+局部搜索框架内执行,
并以小窗口精确MILP校验代表性切片; 结果如实标注为启发式."""
import os, sys, time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (load_workload, load_gpu_info, load_region_time, REGIONS, TYPES, POWER_MAP,
                    RESULTS, FIGURES, feasible_regions, latency_matrix, duration_hours, overlap)
from style import save, TYPE_COLOR, TYPE_LABEL, REGION_LABEL

wt = load_workload()
gpu = load_gpu_info()
rt = load_region_time().sort_values(["Region","Hour"]).reset_index(drop=True)
lat = latency_matrix()
N_REG = len(REGIONS); RIDX = {r: i for i, r in enumerate(REGIONS)}

# 逐时电力参数矩阵 (region x hour, 0..2405 共2406列)
NH = 2406
P = np.zeros((N_REG, NH)); SP = np.zeros((N_REG, NH)); CI = np.zeros((N_REG, NH))
REN = np.zeros((N_REG, NH)); NONAI = np.zeros((N_REG, NH)); BAI = np.zeros((N_REG, NH)); UREN_BASE = np.zeros((N_REG, NH))
for r in REGIONS:
    sub = rt[rt["Region"] == r].set_index("Hour")
    h = np.arange(NH)
    P[RIDX[r], h] = sub.loc[h, "ElectricityPrice_CNY_per_MWh"].values
    SP[RIDX[r], h] = sub.loc[h, "SellPrice_CNY_per_MWh"].values
    CI[RIDX[r], h] = sub.loc[h, "CarbonIntensity_tCO2_per_MWh"].values
    REN[RIDX[r], h] = sub.loc[h, "AvailableRenewable_MW"].values
    NONAI[RIDX[r], h] = sub.loc[h, "NonAI_IT_Load_MW"].values
    BAI[RIDX[r], h] = sub.loc[h, "Baseline_AI_IT_Load_MW"].values
    UREN_BASE[RIDX[r], h] = sub.loc[h, "UsedRenewable_MW"].values
LOAD_EST = NONAI + BAI  # 边际成本代理用期望负荷
CAP_GPU = np.array([gpu.loc[r, "Available_GPU"] for r in REGIONS])
CAP_IT = np.array([gpu.loc[r, "Max_IT_Power_MW"] for r in REGIONS])

tasks = wt.reset_index(drop=True)
tasks["d"] = tasks["EstimatedDuration_min"] / 60.0
tasks["p"] = tasks["TaskType"].map(POWER_MAP)

def shortfall_share(ri, t):
    with np.errstate(divide="ignore", invalid="ignore"):
        sh = np.where(LOAD_EST[ri, t] > 0, np.maximum(0, LOAD_EST[ri, t] - REN[ri, t]) / LOAD_EST[ri, t], 0.0)
    return sh

# 预计算 per (region, hour) 成本/碳边际代理
MRG_P = np.zeros((N_REG, NH)); MRG_C = np.zeros((N_REG, NH))
MRG_P_SENS = np.zeros((N_REG, NH)); MRG_C_SENS = np.zeros((N_REG, NH))
for ri in range(N_REG):
    sh = shortfall_share(ri, np.arange(NH))
    MRG_P[ri] = P[ri] * sh
    MRG_C[ri] = CI[ri] * sh
    with np.errstate(divide="ignore", invalid="ignore"):
        shs = np.where(LOAD_EST[ri] > 0, np.maximum(0, LOAD_EST[ri] - UREN_BASE[ri]) / LOAD_EST[ri], 0.0)
    MRG_P_SENS[ri] = P[ri] * shs
    MRG_C_SENS[ri] = CI[ri] * shs

def run_schedule(lat_weight=3.0, carbon_weight=0.0, max_delay_batch=16, max_delay_train=32, delay_penalty=1.0, step=4, pressure_weight=0.0):
    used_gh = np.zeros((N_REG, NH)); used_pw = np.zeros((N_REG, NH))
    sched = []
    rt_mask = tasks["TaskType"] == "RealTimeInference"
    order = pd.concat([tasks[rt_mask].sort_values("ArrivalHour"), tasks[~rt_mask].sort_values("ArrivalHour", ascending=False)]).itertuples()
    for row in order:
        d = row.d; g = float(row.GPU_Demand); p = row.p; a = int(row.ArrivalHour)
        feas = np.array([RIDX[r] for r in feasible_regions(row.SourceRegion, row.TaskType, lat)], dtype=int)
        if row.TaskType == "RealTimeInference":
            starts = np.array([a], dtype=float)
        else:
            max_delay = max_delay_batch if row.TaskType == "BatchInference" else max_delay_train
            s_max = int(min(2405, 2406 - d))
            starts = np.arange(a, s_max + 1, step)
            starts = starts[starts - a <= max_delay]
            if starts.size == 0:
                starts = np.array([a], dtype=float)
        # 收尾容量预留: 早到任务(到达<2393)可在D/E/F迁移, 但不得占用D/E/F收尾时段(完成>=2393), 留给晚到任务
        if a < 2393:
            cand = []
            for r in feas:
                rname = REGIONS[r]
                for s0 in starts:
                    if rname in ("RegionD", "RegionE", "RegionF") and s0 + d >= 2393:
                        continue
                    cand.append((r, s0))
            if not cand:
                cand = [(r, s0) for r in feas for s0 in starts]
            ri_arr = np.array([r for r, _ in cand], dtype=int)
            s_arr = np.array([float(s0) for _, s0 in cand])
        else:
            ri_arr = np.repeat(feas, starts.size)
            s_arr = np.tile(starts, len(feas))
        h0 = int(np.floor(s_arr.min())); h1 = int(np.ceil((s_arr + d).max()))
        hours = np.arange(max(0, h0), min(NH, h1))
        if hours.size == 0:
            continue
        ov = np.clip(np.minimum(s_arr[:, None] + d, hours[None, :] + 1.0) - np.maximum(s_arr[:, None], hours[None, :]), 0.0, 1.0)
        gh_add = g * ov; pw_add = g * p * ov
        used_gh_c = used_gh[ri_arr][:, hours]; used_pw_c = used_pw[ri_arr][:, hours]
        cap_ok = ~np.any((used_gh_c + gh_add > CAP_GPU[ri_arr, None] + 1e-6) |
                         (used_pw_c + pw_add > CAP_IT[ri_arr, None] - NONAI[ri_arr][:, hours] + 1e-6), axis=1)
        if not np.any(cap_ok):
            # 放宽: 允许全部可行开工(含更大延迟)
            s_max = int(min(2405, 2406 - d))
            starts2 = np.arange(a, s_max + 1)
            ri_arr2 = np.repeat(feas, starts2.size); starts2 = np.tile(starts2, len(feas))
            s_arr2 = starts2.astype(float)
            h0 = int(np.floor(s_arr2.min())); h1 = int(np.ceil((s_arr2 + d).max()))
            hours2 = np.arange(max(0, h0), min(NH, h1))
            ov2 = np.clip(np.minimum(s_arr2[:, None] + d, hours2[None, :] + 1.0) - np.maximum(s_arr2[:, None], hours2[None, :]), 0.0, 1.0)
            gh2 = g*ov2; pw2 = g*p*ov2
            used_gh_c2 = used_gh[ri_arr2][:, hours2]; used_pw_c2 = used_pw[ri_arr2][:, hours2]
            cap_ok2 = ~np.any((used_gh_c2 + gh2 > CAP_GPU[ri_arr2, None] + 1e-6) |
                              (used_pw_c2 + pw2 > CAP_IT[ri_arr2, None] - NONAI[ri_arr2][:, hours2] + 1e-6), axis=1)
            if not np.any(cap_ok2):
                best = (feas[0], float(a))
            else:
                sel = np.where(cap_ok2)[0][0]
                best = (int(ri_arr2[sel]), float(starts2[sel]))
            ri, s = best
        else:
            pressure = np.sum((used_gh_c + gh_add) / CAP_GPU[ri_arr, None], axis=1)
            score = np.sum(gh_add * (MRG_P_SENS[ri_arr][:, hours] + carbon_weight * MRG_C_SENS[ri_arr][:, hours]), axis=1) \
                    + lat_weight * np.array([lat[(row.SourceRegion, REGIONS[ri_arr[i]])] for i in range(len(ri_arr))]) * g * d \
                    + delay_penalty * (s_arr - a) * g * d * 0.01 \
                    + pressure_weight * pressure
            score[~cap_ok] = np.inf
            sel = int(np.argmin(score))
            ri, s = int(ri_arr[sel]), float(s_arr[sel])
        hours = np.arange(int(np.floor(s)), int(np.ceil(s + d)))
        hours = hours[hours < NH]
        ovf = np.clip(np.minimum(s + d, hours + 1.0) - np.maximum(s, hours), 0.0, 1.0)
        used_gh[ri, hours] += g * ovf
        used_pw[ri, hours] += g * p * ovf
        sched.append(dict(TaskID=int(row.TaskID), TaskType=row.TaskType, SourceRegion=row.SourceRegion, EstimatedDuration_min=row.EstimatedDuration_min, ArrivalHour=int(row.ArrivalHour),
                          Region=REGIONS[ri], StartHour=round(s,2), FinishHour=round(s + d, 3), GPU=g))
    sched = _repair2(sched)
    return pd.DataFrame(sched), used_gh, used_pw

def evaluate(sched_df):
    """精确功率评估: 无储能, 新能源优先消纳, 富余外送(限SellLimit)否则弃电."""
    ai = np.zeros((N_REG, NH))
    for row in sched_df.itertuples():
        ri = RIDX[row.Region]; s = row.StartHour; d = duration_hours(row.EstimatedDuration_min)
        g = row.GPU; p = POWER_MAP[row.TaskType]
        hours = np.arange(int(np.floor(s)), int(np.ceil(s + d)))
        hours = hours[(hours >= 0) & (hours < NH)]
        for t in hours:
            ai[ri, t] += g * p * overlap(s, d, t)
    cost = 0.0; carbon = 0.0; used_sum = 0.0; avail_sum = 0.0; gp_sum = 0.0
    cost_sens = 0.0; carbon_sens = 0.0
    latency = 0.0; mig = 0
    for row in sched_df.itertuples():
        latv = lat[(row.SourceRegion, row.Region)]
        latency += latv * row.GPU * duration_hours(row.EstimatedDuration_min)
        if row.SourceRegion != row.Region:
            mig += 1
    for ri in range(N_REG):
        load = NONAI[ri] + ai[ri]
        used = np.minimum(load, REN[ri])
        rem = REN[ri] - used
        gs = np.minimum(rem, SP_LIMIT[ri])
        gp = np.maximum(load - used, 0)
        cost += float(np.sum(gp * P[ri] - gs * SP[ri]))
        carbon += float(np.sum(gp * CI[ri]))
        used_sum += float(np.sum(used + gs))
        avail_sum += float(np.sum(REN[ri]))
        gp_sum += float(np.sum(gp))
        # 敏感性口径: 按基准可再生消纳剖面, 未覆盖负荷全额购电/计碳
        uncovered = np.maximum(load - UREN_BASE[ri], 0)
        cost_sens += float(np.sum(uncovered * P[ri]))
        carbon_sens += float(np.sum(uncovered * CI[ri]))
    return dict(cost=cost, carbon=carbon, renew_util=used_sum / avail_sum * 100 if avail_sum else 0,
                latency=latency, migration_rate=mig / len(sched_df), grid_purchase=gp_sum,
                cost_sens=cost_sens, carbon_sens=carbon_sens)

def set_scenario(P_new=None, REN_new=None, CI_new=None, SP_new=None, NONAI_new=None, BAI_new=None):
    """更新电力参数全局并重算边际代理(供Q4场景复用)."""
    global P, REN, CI, SP, NONAI, BAI, LOAD_EST, MRG_P, MRG_C
    if P_new is not None: P = P_new
    if REN_new is not None: REN = REN_new
    if CI_new is not None: CI = CI_new
    if SP_new is not None: SP = SP_new
    if NONAI_new is not None: NONAI = NONAI_new
    if BAI_new is not None: BAI = BAI_new
    LOAD_EST = NONAI + BAI
    MRG_P = np.zeros_like(P); MRG_C = np.zeros_like(P)
    MRG_P_SENS = np.zeros_like(P); MRG_C_SENS = np.zeros_like(P)
    for ri in range(N_REG):
        sh = shortfall_share(ri, np.arange(NH))
        MRG_P[ri] = P[ri] * sh
        MRG_C[ri] = CI[ri] * sh
        # 敏感性口径: 按基准可再生消纳剖面, 新增负荷按购电价/碳强度全额计入
        with np.errstate(divide="ignore", invalid="ignore"):
            shs = np.where(LOAD_EST[ri] > 0, np.maximum(0, LOAD_EST[ri] - UREN_BASE[ri]) / LOAD_EST[ri], 0.0)
        MRG_P_SENS[ri] = P[ri] * shs
        MRG_C_SENS[ri] = CI[ri] * shs

def _overlap_contrib(t, ri):
    d = t["FinishHour"] - t["StartHour"]; g = float(t["GPU"]); p = POWER_MAP[t["TaskType"]]
    h0 = int(np.floor(t["StartHour"])); h1 = int(np.ceil(t["StartHour"] + d))
    hours = np.arange(max(0, h0), min(NH, h1))
    ov = np.clip(np.minimum(t["StartHour"] + d, hours + 1.0) - np.maximum(t["StartHour"], hours), 0.0, 1.0)
    return ri, hours, ov, g, p

def _usage(sched):
    gh = np.zeros((N_REG, NH)); pw = np.zeros((N_REG, NH))
    for t in sched:
        ri = RIDX[t["Region"]]
        _, hours, ov, g, p = _overlap_contrib(t, ri)
        gh[ri, hours] += g * ov
        pw[ri, hours] += g * p * ov
    return gh, pw

def _overlap_hours(t):
    d = t["FinishHour"] - t["StartHour"]
    h0 = int(np.floor(t["StartHour"])); h1 = int(np.ceil(t["StartHour"] + d))
    return np.arange(max(0, h0), min(NH, h1))

def _try_evict(target, rj, s0, gh, pw, sched):
    """把占用 (rj, s0) 槽位的更早到达任务提前移走, 为 target 腾位. 返回True."""
    d_t = target["FinishHour"] - target["StartHour"]
    h0 = int(np.floor(s0)); h1 = int(np.ceil(s0 + d_t))
    need = set(np.arange(max(0, h0), min(NH, h1)).tolist())
    occ = [i for i, u in enumerate(sched) if RIDX[u["Region"]] == rj and set(_overlap_hours(u).tolist()) & need]
    occ.sort(key=lambda i: sched[i].get("ArrivalHour", sched[i]["StartHour"]))
    for i in occ:
        u = sched[i]
        if u.get("ArrivalHour", u["StartHour"]) >= target.get("ArrivalHour", target["StartHour"]):
            continue
        ua = int(u.get("ArrivalHour", u["StartHour"]))
        du = u["FinishHour"] - u["StartHour"]
        ur = RIDX[u["Region"]]
        _remove_t(u, ur, gh, pw)
        # 找 u 的最早无违规槽位(同区, 从 arrival 起)
        placed = None
        s_max = int(min(2405, 2406 - du))
        for s1 in range(ua, s_max + 1):
            if _place_no_viol(u, ur, float(s1), gh, pw):
                placed = (ur, float(s1)); break
        if placed is None:
            _add_t(u, ur, u["StartHour"], gh, pw)
            continue
        _add_t(u, ur, placed[1], gh, pw)
        u["StartHour"] = placed[1]; u["FinishHour"] = round(placed[1] + du, 3)
        if _place_no_viol(target, rj, s0, gh, pw):
            return True
    return False

def _place_no_viol(t, ri, s, gh, pw):
    """检查任务t放到(ri,s)是否不产生违规(相对当前gh/pw). 返回bool."""
    d = t["FinishHour"] - t["StartHour"]; g = float(t["GPU"]); p = POWER_MAP[t["TaskType"]]
    h0 = int(np.floor(s)); h1 = int(np.ceil(s + d))
    hours = np.arange(max(0, h0), min(NH, h1))
    if hours.size == 0:
        return False
    ov = np.clip(np.minimum(s + d, hours + 1.0) - np.maximum(s, hours), 0.0, 1.0)
    gha = g * ov; pwa = g * p * ov
    if np.any(gh[ri][hours] + gha > CAP_GPU[ri] + 1e-6):
        return False
    if np.any(pw[ri][hours] + pwa > (CAP_IT[ri] - NONAI[ri][hours]) + 1e-6):
        return False
    return True

def _remove_t(t, ri, gh, pw):
    d = t["FinishHour"] - t["StartHour"]; g = float(t["GPU"]); p = POWER_MAP[t["TaskType"]]
    h0 = int(np.floor(t["StartHour"])); h1 = int(np.ceil(t["StartHour"] + d))
    hours = np.arange(max(0, h0), min(NH, h1))
    ov = np.clip(np.minimum(t["StartHour"] + d, hours + 1.0) - np.maximum(t["StartHour"], hours), 0.0, 1.0)
    gh[ri][hours] -= g * ov; pw[ri][hours] -= g * p * ov

def _add_t(t, ri, s, gh, pw):
    d = t["FinishHour"] - t["StartHour"]; g = float(t["GPU"]); p = POWER_MAP[t["TaskType"]]
    h0 = int(np.floor(s)); h1 = int(np.ceil(s + d))
    hours = np.arange(max(0, h0), min(NH, h1))
    ov = np.clip(np.minimum(s + d, hours + 1.0) - np.maximum(s, hours), 0.0, 1.0)
    gh[ri][hours] += g * ov; pw[ri][hours] += g * p * ov

def _repair2(sched):
    """位移式修复: 把占用D/E/F收尾槽位的早到任务提前, 为晚到任务腾出容量."""
    sched = list(sched)
    for it in range(14):
        gh, pw = _usage(sched)
        viol = set()
        for ri in range(N_REG):
            bad = np.where((gh[ri] > CAP_GPU[ri] + 1e-6) | (pw[ri] > (CAP_IT[ri] - NONAI[ri]) + 1e-6))[0]
            for h in bad:
                viol.add((ri, int(h)))
        if not viol:
            break
        progressed = False
        # 找出造成违规的任务
        for (ri, h) in sorted(viol):
            cand = [i for i, t in enumerate(sched) if RIDX[t["Region"]] == ri and t["StartHour"] <= h + 1 and t["FinishHour"] >= h]
            cand.sort(key=lambda i: -(sched[i]["GPU"] * (sched[i]["FinishHour"] - sched[i]["StartHour"])))
            for i in cand:
                t = sched[i]
                a = int(t.get("ArrivalHour", t["StartHour"]))
                d = t["FinishHour"] - t["StartHour"]
                old_ri = RIDX[t["Region"]]; old_s = t["StartHour"]
                _remove_t(t, old_ri, gh, pw)
                # 扫描所有可行(区域,开工), 选不引入违规且评分最低者
                best = None; bestscore = np.inf
                for r in feasible_regions(t["SourceRegion"], t["TaskType"], lat):
                    rj = RIDX[r]
                    s_max = int(min(2405, 2406 - d))
                    starts = np.arange(a, s_max + 1)
                    if starts.size == 0:
                        starts = np.array([a])
                    for s0 in starts:
                        if not _place_no_viol(t, rj, float(s0), gh, pw):
                            if _try_evict(t, rj, float(s0), gh, pw, sched):
                                best = (rj, float(s0)); bestscore = -1
                                break
                            continue
                        # 评分: 敏感性成本 + 时延 + 延迟
                        h0 = int(np.floor(s0)); h1 = int(np.ceil(s0 + d))
                        hrs = np.arange(max(0, h0), min(NH, h1))
                        ov = np.clip(np.minimum(s0 + d, hrs + 1.0) - np.maximum(s0, hrs), 0.0, 1.0)
                        sc = float(np.sum(ov * t["GPU"] * MRG_P_SENS[rj][hrs])) + 3.0 * lat[(t["SourceRegion"], r)] * t["GPU"] * d + 1.0 * (s0 - a) * t["GPU"] * d * 0.01
                        if sc < bestscore:
                            bestscore = sc; best = (rj, float(s0))
                if best is None:
                    # 无法无违规重放: 若槽位被早到任务占用, 尝试"提前腾挪"占用者
                    # 先在原地恢复, 再尝试把占用D/E/F收尾的早任务提前
                    _add_t(t, old_ri, old_s, gh, pw)
                    continue
                rj, s0 = best
                _add_t(t, rj, s0, gh, pw)
                t["Region"] = REGIONS[rj]; t["StartHour"] = s0; t["FinishHour"] = round(s0 + d, 3)
                progressed = True
                break
            if progressed:
                break
        if not progressed:
            break
    return sched

def _repair(sched):
    sched = list(sched)
    for it in range(4):
        gh, pw = _usage(sched)
        viol = set()
        for ri in range(N_REG):
            bad = np.where((gh[ri] > CAP_GPU[ri] + 1e-6) | (pw[ri] > (CAP_IT[ri] - NONAI[ri]) + 1e-6))[0]
            for h in bad:
                viol.add((ri, int(h)))
        if not viol:
            break
        touched = []
        for idx, t in enumerate(sched):
            ri = RIDX[t["Region"]]
            _, hours, _, _, _ = _overlap_contrib(t, ri)
            if any((ri, int(h)) in viol for h in hours):
                touched.append(idx)
        moved = False
        for idx in sorted(touched, key=lambda i: -sched[i]["GPU"] * (sched[i]["FinishHour"] - sched[i]["StartHour"])):
            t = sched[idx]
            a = int(t.get("ArrivalHour", t["StartHour"]))  # 允许在[到达, 2406-d]内重排(可提前)
            d = t["FinishHour"] - t["StartHour"]
            # 先移除
            ri0, hours0, ov0, g0, p0 = _overlap_contrib(t, RIDX[t["Region"]])
            gh[ri0, hours0] -= g0 * ov0; pw[ri0, hours0] -= g0 * p0 * ov0
            best = None; bestscore = np.inf
            for r in feasible_regions(t["SourceRegion"], t["TaskType"], lat):
                ri = RIDX[r]
                s_max = int(min(2405, 2406 - d))
                starts = np.arange(a, s_max + 1, 2)
                if starts.size == 0:
                    starts = np.array([a], dtype=float)
                s_arr = starts.astype(float)
                h0 = int(np.floor(s_arr.min())); h1 = int(np.ceil((s_arr + d).max()))
                hours = np.arange(max(0, h0), min(NH, h1))
                ov = np.clip(np.minimum(s_arr[:, None] + d, hours[None, :] + 1.0) - np.maximum(s_arr[:, None], hours[None, :]), 0.0, 1.0)
                gha = g0 * ov; pwa = p0 * ov
                ghc = gh[ri][hours][None, :] + gha
                pwc = pw[ri][hours][None, :] + pwa
                ok = ~np.any((ghc > CAP_GPU[ri] + 1e-6) | (pwc > (CAP_IT[ri] - NONAI[ri][hours]) + 1e-6), axis=1)
                if not np.any(ok):
                    continue
                score = np.sum(gha * MRG_P_SENS[ri][hours][None, :], axis=1) + 3.0 * lat[(t["SourceRegion"], r)] * g0 * d + 1.0 * (s_arr - a) * g0 * d * 0.01
                score[~ok] = np.inf
                j = int(np.argmin(score))
                sc = score[j]
                if sc < bestscore:
                    bestscore = sc; best = (ri, float(s_arr[j]), hours, ov[j], gha[j], pwa[j])
            if best is None:
                # 恢复原位
                gh[ri0, hours0] += g0 * ov0; pw[ri0, hours0] += g0 * p0 * ov0
                continue
            ri, s, hours, ovj, ghaj, pwaj = best
            t["Region"] = REGIONS[ri]; t["StartHour"] = s; t["FinishHour"] = round(s + d, 3)
            gh[ri, hours] += ghaj; pw[ri, hours] += pwaj
            moved = True
        if not moved:
            break
    return sched

# 外送上限
sto = pd.read_excel(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), os.path.pardir, os.path.join("附件数据", "storage_information.xlsx")), sheet_name="storage_information")
SP_LIMIT = np.array([sto[sto["Region"] == r]["SellLimit_MW"].iloc[0] for r in REGIONS])

if __name__ == "__main__":
    # 基线(附件)对比: 从region_time_data聚合
    rt2 = rt.copy(); rt2["cost"] = rt2["ElectricityPrice_CNY_per_MWh"]*rt2["GridPurchase_MW"] - rt2["SellPrice_CNY_per_MWh"]*rt2["GridSell_MW"]
    main = rt2[rt2["Hour"] <= 2405]
    base_metrics = dict(cost=main["cost"].sum(), carbon=main["CarbonEmission_tCO2"].sum(),
                        renew_util=(main["UsedRenewable_MW"]+main["RenewableCharge_MW"]+main["GridSell_MW"]).sum()/main["AvailableRenewable_MW"].sum()*100,
                        latency=float("nan"), migration_rate=0.0, grid_purchase=main["GridPurchase_MW"].sum())

    t0 = time.time()
    # 主运行: 基准权重
    sched_main, gh, pw = run_schedule(lat_weight=3.0, carbon_weight=0.0)
    sched_main.to_csv(os.path.join(RESULTS, "q2_schedule.csv"), index=False, encoding="utf-8-sig")
    ev = evaluate(sched_main); ev["scenario"] = "optimized"
    base_metrics["scenario"] = "baseline"
    compare = pd.DataFrame([base_metrics, ev]).set_index("scenario")
    compare.to_csv(os.path.join(RESULTS, "q2_compare.csv"), encoding="utf-8-sig")
    print("Q2 主运行:", ev)

    # ---- 可行性校验 ----
    def verify(sched_df):
        gh = np.zeros((N_REG, NH)); pw = np.zeros((N_REG, NH))
        for row in sched_df.itertuples():
            ri = RIDX[row.Region]; d = duration_hours(row.EstimatedDuration_min); g = row.GPU; p = POWER_MAP[row.TaskType]
            s0 = row.StartHour
            hours = np.arange(int(np.floor(s0)), int(np.ceil(s0 + d)))
            hours = hours[(hours >= 0) & (hours < NH)]
            ov = np.clip(np.minimum(s0 + d, hours + 1.0) - np.maximum(s0, hours), 0.0, 1.0)
            gh[ri, hours] += g * ov; pw[ri, hours] += g * p * ov
        v_gh = int(np.sum(gh > CAP_GPU[:, None] + 1e-6))
        v_pw = int(np.sum(pw > (CAP_IT[:, None] - NONAI) + 1e-6))
        return v_gh, v_pw

    v_gh, v_pw = verify(sched_main)
    print("Q2 可行性校验: GPU越限", v_gh, "IT功率越限", v_pw)

    # 时延权重扫描 (真实的成本-时延权衡)
    pts = []
    for lw in [0.0, 3.0]:
        sched, _, _ = run_schedule(lat_weight=lw, carbon_weight=0.0)
        m = evaluate(sched)
        tot_gh = float(np.sum(sched["GPU"] * sched["EstimatedDuration_min"] / 60.0))
        pts.append(dict(lat_weight=lw, cost=m["cost"], carbon=m["carbon"], latency=m["latency"],
                        avg_latency_ms=m["latency"] / tot_gh, renew_util=m["renew_util"], migration_rate=m["migration_rate"]))
        print("lat_weight=", lw, "cost=", round(m["cost"]/1e6,1), "avg_lat=", round(m["latency"]/tot_gh,1), "mig=", round(m["migration_rate"],4))
    pareto = pd.DataFrame(pts)
    pareto.to_csv(os.path.join(RESULTS, "q2_pareto.csv"), index=False, encoding="utf-8-sig")

    # 也输出碳权重扫描(报告碳排不敏感的实证)
    carbon_pts = []
    for cw in [0.0, 20.0]:
        sched, _, _ = run_schedule(lat_weight=0.3, carbon_weight=cw)
        m = evaluate(sched)
        carbon_pts.append(dict(carbon_weight=cw, cost=m["cost"], carbon=m["carbon"], renew_util=m["renew_util"], migration_rate=m["migration_rate"]))
    pd.DataFrame(carbon_pts).to_csv(os.path.join(RESULTS, "q2_carbon_sweep.csv"), index=False, encoding="utf-8-sig")

    # ---------- F7: 迁移结构热力图 (来源 x 执行) ----------
    ct = pd.crosstab(sched_main["SourceRegion"], sched_main["Region"])[REGIONS]
    fig, ax = plt.subplots(figsize=(6.5, 5))
    im = ax.imshow(ct.values, cmap="Blues", aspect="auto")
    ax.set_xticks(range(6)); ax.set_xticklabels([REGION_LABEL[r] for r in REGIONS])
    ax.set_yticks(range(6)); ax.set_yticklabels([REGION_LABEL[r] for r in REGIONS])
    for i in range(6):
        for j in range(6):
            ax.text(j, i, f"{ct.values[i,j]}", ha="center", va="center", fontsize=8)
    ax.set_xlabel("执行区域"); ax.set_ylabel("来源区域")
    ax.set_title("任务迁移结构 (来源→执行, 任务数)")
    fig.colorbar(im, ax=ax)
    save(fig, os.path.join(FIGURES, "F7.pdf"))

    # ---------- F8: 成本-平均时延散点 (时延权重扫描) ----------
    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    sc = ax.scatter(pareto["avg_latency_ms"], pareto["cost"]/1e6, c=pareto["migration_rate"], cmap="viridis", s=60)
    for _, r in pareto.iterrows():
        ax.annotate(f"λ={r['lat_weight']:.1f}", (r["avg_latency_ms"], r["cost"]/1e6), fontsize=8, xytext=(4,4), textcoords="offset points")
    ax.set_xlabel("平均时延 (GPU-hour加权, ms)"); ax.set_ylabel("运行成本 (百万元)")
    ax.set_title("成本—时延权衡 (时延权重扫描)")
    fig.colorbar(sc, ax=ax, label="迁移率")
    save(fig, os.path.join(FIGURES, "F8.pdf"))

    # ---------- F9: 代表性区域 逐时IT负荷与购电 (优化 vs 基准) ----------
    def load_and_purchase(sched_df):
        ai = np.zeros((N_REG, NH))
        for row in sched_df.itertuples():
            ri = RIDX[row.Region]; d = duration_hours(row.EstimatedDuration_min); g = row.GPU; p = POWER_MAP[row.TaskType]
            s0 = row.StartHour
            hours = np.arange(int(np.floor(s0)), int(np.ceil(s0 + d)))
            hours = hours[(hours >= 0) & (hours < NH)]
            for t in hours:
                ai[ri, t] += g * p * overlap(s0, d, t)
        load = NONAI + ai
        gp = np.maximum(load - REN, 0)
        return load, gp
    load_opt, gp_opt = load_and_purchase(sched_main)
    # 基准
    load_base = (rt.set_index(["Region","Hour"])["NonAI_IT_Load_MW"] + rt.set_index(["Region","Hour"])["Baseline_AI_IT_Load_MW"]).sort_index()
    load_base = np.array([load_base[(REGIONS[ri], h)] for ri in range(N_REG) for h in range(2406)]).reshape(N_REG, 2406) * np.array([gpu.loc[r,"PUE"] for r in REGIONS])[:, None]
    rtidx = rt.set_index(["Region","Hour"])
    gp_base = np.array([rtidx.loc[(REGIONS[ri], h), "GridPurchase_MW"] for ri in range(N_REG) for h in range(2406)]).reshape(N_REG, 2406)
    fig, axes = plt.subplots(2, 1, figsize=(10, 6))
    ri = RIDX["RegionD"]
    axes[0].plot(np.arange(2406), load_opt[ri], color="#0072B2", lw=0.7, label="优化 IT 负荷")
    axes[0].plot(np.arange(2406), load_base[ri], color="#999999", lw=0.7, ls="--", label="基准 IT 负荷")
    axes[0].set_ylabel("MW"); axes[0].set_title("RegionD 逐时 IT 负荷 (优化 vs 基准)"); axes[0].legend(fontsize=8)
    axes[1].plot(np.arange(2406), gp_opt[ri], color="#D55E00", lw=0.7, label="优化购电")
    axes[1].plot(np.arange(2406), gp_base[ri], color="#999999", lw=0.7, ls="--", label="基准购电")
    axes[1].set_xlabel("小时"); axes[1].set_ylabel("MW"); axes[1].set_title("RegionD 逐时购电 (优化 vs 基准)"); axes[1].legend(fontsize=8)
    save(fig, os.path.join(FIGURES, "F9.pdf"))
    print("Q2 完成, 总耗时", round(time.time()-t0,1), "s")