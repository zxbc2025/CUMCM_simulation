# -*- coding: utf-8 -*-
"""全局绘图样式 (视觉规范 v1)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": ["Microsoft YaHei", "SimHei", "sans-serif"],
    "font.sans-serif": ["Microsoft YaHei", "SimHei", "DejaVu Sans"],
    "axes.unicode_minus": False,
    "font.size": 9,
    "axes.titlesize": 10,
    "axes.labelsize": 9,
    "legend.fontsize": 8,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "figure.dpi": 120,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "axes.grid": True,
    "grid.alpha": 0.3,
})

TYPE_COLOR = {"RealTimeInference": "#0072B2", "BatchInference": "#009E73", "AITraining": "#D55E00"}
TYPE_LABEL = {"RealTimeInference": "实时推理", "BatchInference": "批量推理", "AITraining": "AI训练"}
REGION_LABEL = {r: r.replace("Region", "R") for r in ["RegionA","RegionB","RegionC","RegionD","RegionE","RegionF"]}

def save(fig, path):
    fig.savefig(path)
    png = path.rsplit(".", 1)[0] + ".png"
    fig.savefig(png, dpi=150)
    plt.close(fig)
    print("saved", path)
