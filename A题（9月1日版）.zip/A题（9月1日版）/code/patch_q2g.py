# -*- coding: utf-8 -*-
p = r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\code\q2_schedule.py"
s = open(p, encoding="utf-8").read()
# 在 _place_no_viol 前插入 _try_evict
anchor = "def _place_no_viol(t, ri, s, gh, pw):"
evict = '''def _overlap_hours(t):
    d = t["FinishHour"] - t["StartHour"]
    h0 = int(np.floor(t["StartHour"])); h1 = int(np.ceil(t["StartHour"] + d))
    return np.arange(max(0, h0), min(NH, h1))

def _try_evict(target, rj, s0, gh, pw, sched):
    """把占用 (rj, s0) 槽位的更早到达任务提前移走, 为 target 腾位. 返回True."""
    d_t = target["FinishHour"] - target["StartHour"]
    h0 = int(np.floor(s0)); h1 = int(np.ceil(s0 + d_t))
    need = set(np.arange(max(0, h0), min(NH, h1)).tolist())
    occ = [i for i, u in enumerate(sched) if RIDX[u["Region"]] == rj and set(_overlap_hours(u).tolist()) & need]
    occ.sort(key=lambda i: sched[i].get("ArrivalHour", sched[i]["StartHour"]))
    for i in occ:
        u = sched[i]
        if u.get("ArrivalHour", u["StartHour"]) >= target.get("ArrivalHour", target["StartHour"]):
            continue
        ua = int(u.get("ArrivalHour", u["StartHour"]))
        du = u["FinishHour"] - u["StartHour"]
        ur = RIDX[u["Region"]]
        _remove_t(u, ur, gh, pw)
        # 找 u 的最早无违规槽位(同区, 从 arrival 起)
        placed = None
        s_max = int(min(2405, 2406 - du))
        for s1 in range(ua, s_max + 1):
            if _place_no_viol(u, ur, float(s1), gh, pw):
                placed = (ur, float(s1)); break
        if placed is None:
            _add_t(u, ur, u["StartHour"], gh, pw)
            continue
        _add_t(u, ur, placed[1], gh, pw)
        u["StartHour"] = placed[1]; u["FinishHour"] = round(placed[1] + du, 3)
        if _place_no_viol(target, rj, s0, gh, pw):
            return True
    return False

def _place_no_viol(t, ri, s, gh, pw):'''
assert anchor in s
s = s.replace(anchor, evict, 1)

# 在 _repair2 扫描中: 候选不满足时尝试腾挪
old = '''                    for s0 in starts:
                        if not _place_no_viol(t, rj, float(s0), gh, pw):
                            continue'''
new = '''                    for s0 in starts:
                        if not _place_no_viol(t, rj, float(s0), gh, pw):
                            if _try_evict(t, rj, float(s0), gh, pw, sched):
                                best = (rj, float(s0)); bestscore = -1
                                break
                            continue'''
assert old in s
s = s.replace(old, new)
open(p, "w", encoding="utf-8").write(s)
print("eviction logic added")
