# -*- coding: utf-8 -*-
import os, json, hashlib, glob
work = r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work"
def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return "sha256:" + h.hexdigest()
files = []
def add(src, dest, role, desc):
    p = os.path.join(work, src)
    if os.path.exists(p):
        files.append({"source": src.replace("\\", "/"), "destination": dest, "sha256": sha(p), "role": role, "description": desc, "license_status": "original"})
    else:
        print("MISSING:", src)
add("supporting-materials/README.md", "README.md", "readme", "运行说明与文件清单")
for f in sorted(glob.glob(os.path.join(work, "code", "*.py"))):
    name = os.path.basename(f)
    add(os.path.join("code", name), os.path.join("code", name), "code", "模型实现脚本")
for f in sorted(glob.glob(os.path.join(work, "results", "*.csv"))) + [os.path.join(work, "results", "summary.json")]:
    name = os.path.basename(f)
    add(os.path.join("results", name), os.path.join("results", name), "results", "结果数据")
for f in sorted(glob.glob(os.path.join(work, "figures", "*.pdf"))):
    name = os.path.basename(f)
    add(os.path.join("figures", name), os.path.join("figures", name), "results", "论文图")
for f in sorted(glob.glob(os.path.join(work, "validation", "ai-disclosure", "*"))):
    name = os.path.basename(f)
    add(os.path.join("validation", "ai-disclosure", name), os.path.join("ai-disclosure", name), "ai-disclosure", "AI 使用披露")
for name in ["workload_trace.xlsx", "GPU_information.xlsx", "network_latency.xlsx", "power_mapping.xlsx", "region_time_data.xlsx", "storage_information.xlsx"]:
    src = os.path.join(os.path.dirname(work), "附件数据", name)
    if os.path.exists(src):
        files.append({"source": src.replace("\\", "/"), "destination": os.path.join("data", name), "sha256": sha(src), "role": "data", "description": "附件原始数据", "license_status": "original"})
manifest = {
    "schema_version": 1,
    "max_archive_bytes": 52428800,
    "required_roles": ["readme", "code", "data", "results", "ai-disclosure"],
    "anonymity_report": "validation/anonymity-report.json",
    "files": files,
}
json.dump(manifest, open(os.path.join(work, "supporting-materials-manifest.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
total = sum(os.path.getsize(os.path.join(work, f["source"])) for f in files if os.path.exists(os.path.join(work, f["source"])))
print("manifest written, files:", len(files), "total bytes:", total)
