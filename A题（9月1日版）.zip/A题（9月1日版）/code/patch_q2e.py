# -*- coding: utf-8 -*-
p = r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\code\q2_schedule.py"
s = open(p, encoding="utf-8").read()

# 在 set_scenario 之后插入修复函数
anchor = "# 外送上限"
repair_fn = '''def _overlap_contrib(t, ri):
    d = t["FinishHour"] - t["StartHour"]; g = float(t["GPU"]); p = POWER_MAP[t["TaskType"]]
    h0 = int(np.floor(t["StartHour"])); h1 = int(np.ceil(t["StartHour"] + d))
    hours = np.arange(max(0, h0), min(NH, h1))
    ov = np.clip(np.minimum(t["StartHour"] + d, hours + 1.0) - np.maximum(t["StartHour"], hours), 0.0, 1.0)
    return ri, hours, ov, g, p

def _usage(sched):
    gh = np.zeros((N_REG, NH)); pw = np.zeros((N_REG, NH))
    for t in sched:
        ri = RIDX[t["Region"]]
        _, hours, ov, g, p = _overlap_contrib(t, ri)
        gh[ri, hours] += g * ov
        pw[ri, hours] += g * p * ov
    return gh, pw

def _repair(sched):
    sched = list(sched)
    for it in range(5):
        gh, pw = _usage(sched)
        viol = set()
        for ri in range(N_REG):
            bad = np.where((gh[ri] > CAP_GPU[ri] + 1e-6) | (pw[ri] > (CAP_IT[ri] - NONAI[ri]) + 1e-6))[0]
            for h in bad:
                viol.add((ri, int(h)))
        if not viol:
            break
        touched = []
        for idx, t in enumerate(sched):
            ri = RIDX[t["Region"]]
            _, hours, _, _, _ = _overlap_contrib(t, ri)
            if any((ri, int(h)) in viol for h in hours):
                touched.append(idx)
        moved = False
        for idx in sorted(touched, key=lambda i: -sched[i]["GPU"] * (sched[i]["FinishHour"] - sched[i]["StartHour"])):
            t = sched[idx]
            a = int(t["StartHour"])  # 保持原开工不早移; 允许延后
            d = t["FinishHour"] - t["StartHour"]
            # 先移除
            ri0, hours0, ov0, g0, p0 = _overlap_contrib(t, RIDX[t["Region"]])
            gh[ri0, hours0] -= g0 * ov0; pw[ri0, hours0] -= g0 * p0 * ov0
            best = None; bestscore = np.inf
            for r in feasible_regions(t["SourceRegion"], t["TaskType"], lat):
                ri = RIDX[r]
                s_max = int(min(2405, 2406 - d))
                starts = np.arange(a, s_max + 1)
                if starts.size == 0:
                    starts = np.array([a], dtype=float)
                s_arr = starts.astype(float)
                h0 = int(np.floor(s_arr.min())); h1 = int(np.ceil((s_arr + d).max()))
                hours = np.arange(max(0, h0), min(NH, h1))
                ov = np.clip(np.minimum(s_arr[:, None] + d, hours[None, :] + 1.0) - np.maximum(s_arr[:, None], hours[None, :]), 0.0, 1.0)
                gha = g0 * ov; pwa = p0 * ov
                ghc = gh[ri][hours][None, :] + gha
                pwc = pw[ri][hours][None, :] + pwa
                ok = ~np.any((ghc > CAP_GPU[ri] + 1e-6) | (pwc > (CAP_IT[ri] - NONAI[ri][hours]) + 1e-6), axis=1)
                if not np.any(ok):
                    continue
                score = np.sum(gha * MRG_P_SENS[ri][hours][None, :], axis=1) + 3.0 * lat[(t["SourceRegion"], r)] * g0 * d + 1.0 * (s_arr - a) * g0 * d * 0.01
                score[~ok] = np.inf
                j = int(np.argmin(score))
                sc = score[j]
                if sc < bestscore:
                    bestscore = sc; best = (ri, float(s_arr[j]), hours, ov[j], gha[j], pwa[j])
            if best is None:
                # 恢复原位
                gh[ri0, hours0] += g0 * ov0; pw[ri0, hours0] += g0 * p0 * ov0
                continue
            ri, s, hours, ovj, ghaj, pwaj = best
            t["Region"] = REGIONS[ri]; t["StartHour"] = s; t["FinishHour"] = round(s + d, 3)
            gh[ri, hours] += ghaj; pw[ri, hours] += pwaj
            moved = True
        if not moved:
            break
    return sched

# 外送上限'''
assert anchor in s
s = s.replace(anchor, repair_fn, 1)

# 在 run_schedule 返回前调用 _repair
old_ret = "    return pd.DataFrame(sched), used_gh, used_pw"
new_ret = "    sched = _repair(sched)\n    return pd.DataFrame(sched), used_gh, used_pw"
assert old_ret in s
s = s.replace(old_ret, new_ret)
open(p, "w", encoding="utf-8").write(s)
print("q2 repair pass added")
