# -*- coding: utf-8 -*-
"""Q4 多区域算-储-电协同: 分解(任务调度+储能LP) + 场景矩阵 (F12-F14, q4_scenarios.csv).
路线B(分解+滚动)的落地实现: 任务层复用Q2调度(碳感知加权), 储能层复用Q3 LP(参数化, 快速版无波动约束目标).
"""
import os, sys, time
import numpy as np
import pandas as pd
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import q2_schedule as q2
from common import load_region_time, load_storage, load_gpu_info, REGIONS, POWER_MAP, RESULTS, FIGURES, duration_hours, overlap
from style import save, REGION_LABEL, TYPE_COLOR

t0 = time.time()
rt = load_region_time().sort_values(["Region","Hour"]).reset_index(drop=True)
sto = load_storage(); gpu = load_gpu_info()
NH2 = 2407  # 0..2406
RIDX = {r: i for i, r in enumerate(REGIONS)}
HOURS = np.arange(NH2)

# 全时段参数 (0..2406)
P_full = np.zeros((6, NH2)); SP_full = np.zeros((6, NH2)); CI_full = np.zeros((6, NH2))
REN_full = np.zeros((6, NH2)); NONAI_full = np.zeros((6, NH2))
for r in REGIONS:
    sub = rt[rt["Region"] == r].set_index("Hour")
    h = HOURS
    P_full[RIDX[r]] = sub.loc[h, "ElectricityPrice_CNY_per_MWh"].values
    SP_full[RIDX[r]] = sub.loc[h, "SellPrice_CNY_per_MWh"].values
    CI_full[RIDX[r]] = sub.loc[h, "CarbonIntensity_tCO2_per_MWh"].values
    REN_full[RIDX[r]] = sub.loc[h, "AvailableRenewable_MW"].values
    NONAI_full[RIDX[r]] = sub.loc[h, "NonAI_IT_Load_MW"].values

PUE = np.array([gpu.loc[r, "PUE"] for r in REGIONS])
base_sched = pd.read_csv(os.path.join(RESULTS, "q2_schedule.csv"))

def ai_load_from_sched(sched_df):
    ai = np.zeros((6, NH2))
    for row in sched_df.itertuples():
        ri = RIDX[row.Region]; d = duration_hours(row.EstimatedDuration_min); g = row.GPU; p = POWER_MAP[row.TaskType]
        s0 = float(row.StartHour)
        hours = np.arange(int(np.floor(s0)), int(np.ceil(s0 + d)))
        hours = hours[(hours >= 0) & (hours < NH2)]
        for t in hours:
            ai[ri, t] += g * p * overlap(s0, d, t)
    return ai

def storage_lp(region_idx, load, ren, price, sellp, carb, weights=(0.5,0.2,0.3), denom=(1e6,1e4,100.0), no_storage=False):
    """单区域储能LP(0..2406), 目标=归一化加权(成本,碳排,峰值)."""
    s = sto.loc[REGIONS[region_idx]]
    cap, minsoc, init = float(s["StorageCapacity_MWh"]), float(s["MinSOC_MWh"]), float(s["InitialSOC_MWh"])
    mc, md, etac, etad = float(s["MaxChargePower_MW"]), float(s["MaxDischargePower_MW"]), float(s["ChargeEfficiency"]), float(s["DischargeEfficiency"])
    gi, ge = float(s["MaxGridImport_MW"]), float(s["MaxGridExport_MW"])
    N = NH2; V = 8
    idx = lambda t, j: t * V + j
    Pk = N * V
    n = N * V + 1
    eq_r, eq_c, eq_v, eq_b = [], [], [], []
    ub_r, ub_c, ub_v, ub_b = [], [], [], []
    def add_eq(coefs, b):
        eq_r.extend([len(eq_b)]*len(coefs))
        for c, v in coefs: eq_c.append(c); eq_v.append(v)
        eq_b.append(b)
    def add_ub(coefs, b):
        ub_r.extend([len(ub_b)]*len(coefs))
        for c, v in coefs: ub_c.append(c); ub_v.append(v)
        ub_b.append(b)
    for t in range(N):
        add_eq([(idx(t,0),1.0),(idx(t,2),1.0),(idx(t,6),1.0),(idx(t,3),-1.0),(idx(t,4),-1.0),(idx(t,1),-1.0),(idx(t,5),-1.0)], load[t])
        add_eq([(idx(t,2),1.0),(idx(t,3),1.0),(idx(t,1),1.0),(idx(t,5),1.0)], ren[t])
        coefs = [(idx(t,7),1.0),(idx(t,3),-etac),(idx(t,4),-etac),(idx(t,6),1.0/etad)]
        if t > 0: coefs.append((idx(t-1,7),-1.0))
        add_eq(coefs, init if t == 0 else 0.0)
        add_ub([(idx(t,3),1.0),(idx(t,4),1.0)], mc if not no_storage else 0.0)
        add_ub([(Pk,-1.0),(idx(t,0),1.0),(idx(t,1),-1.0)], 0.0)
    add_ub([(idx(N-1,7),-1.0)], -init)
    A_eq = coo_matrix((eq_v,(eq_r,eq_c)), shape=(len(eq_b), n)).tocsr()
    A_ub = coo_matrix((ub_v,(ub_r,ub_c)), shape=(len(ub_b), n)).tocsr()
    lo = np.zeros(n); hi = np.full(n, np.inf)
    for t in range(N):
        lo[idx(t,7)] = minsoc; hi[idx(t,7)] = cap
        hi[idx(t,0)] = gi; hi[idx(t,1)] = ge
        hi[idx(t,6)] = md if not no_storage else 0.0
        if no_storage:
            hi[idx(t,3)] = 0.0; hi[idx(t,4)] = 0.0
    w1, w2, w3 = weights; d1, d2, d3 = denom
    c = np.zeros(n); c[Pk] = w3/d3
    for t in range(N):
        c[idx(t,0)] += w1*price[t]/d1 + w2*carb[t]/d2
        c[idx(t,1)] += -w1*sellp[t]/d1
    res = linprog(c, A_ub=A_ub, b_ub=np.array(ub_b), A_eq=A_eq, b_eq=np.array(eq_b),
                  bounds=list(zip(lo, hi)), method="highs")
    x = res.x
    net = np.array([x[idx(t,0)]-x[idx(t,1)] for t in range(N)])
    return dict(cost=float(sum(x[idx(t,0)]*price[t]-x[idx(t,1)]*sellp[t] for t in range(N))),
                carbon=float(sum(x[idx(t,0)]*carb[t] for t in range(N))),
                peak=float(x[Pk]), fluctuation=float(np.sum(np.abs(net-net.mean()))),
                charge=float(sum(x[idx(t,3)]+x[idx(t,4)] for t in range(N))),
                discharge=float(sum(x[idx(t,6)] for t in range(N))),
                soc_end=float(x[idx(N-1,7)]), status=res.status)

def run_scenario(name, price=None, sellp=None, ren=None, sched=None, carbon_weight=0.0, resched=False):
    price = P_full.copy() if price is None else price
    sellp = SP_full.copy() if sellp is None else sellp
    ren = REN_full.copy() if ren is None else ren
    if resched:
        q2.set_scenario(P_new=price[:, :2406], REN_new=ren[:, :2406], CI_new=CI_full[:, :2406], SP_new=sellp[:, :2406])
        sched, _, _ = q2.run_schedule(lat_weight=3.0, carbon_weight=carbon_weight)
        sched.to_csv(os.path.join(RESULTS, f"q4_sched_{name}.csv"), index=False, encoding="utf-8-sig")
    ai = ai_load_from_sched(sched)
    load = (NONAI_full + ai) * PUE[:, None]
    m = dict(scenario=name)
    for ri in range(6):
        r = storage_lp(ri, load[ri], ren[ri], price[ri], sellp[ri], CI_full[ri])
        for k in ["cost","carbon","peak","fluctuation","charge","discharge","soc_end"]:
            m[k] = m.get(k, 0.0) + r[k]
    tot_gh = float(np.sum(sched["GPU"] * sched["EstimatedDuration_min"] / 60.0))
    lat = 0.0; mig = 0
    for row in sched.itertuples():
        lat += q2.lat[(row.SourceRegion, row.Region)] * row.GPU * duration_hours(row.EstimatedDuration_min)
        if row.SourceRegion != row.Region: mig += 1
    m["avg_latency_ms"] = lat / tot_gh
    m["migration_rate"] = mig / len(sched)
    sell_lim = np.array([sto.loc[r, "SellLimit_MW"] for r in REGIONS])[:, None]
    m["renew_util"] = float(np.sum(np.minimum(load, ren) + np.minimum(np.maximum(ren-load,0), sell_lim)) / np.sum(ren) * 100)
    print(name, {k: round(m[k], 3) if isinstance(m[k], float) else m[k] for k in ["cost","carbon","peak","avg_latency_ms","migration_rate"]})
    return m

# 场景定义
base_carbon = float(np.sum(CI_full * np.maximum((NONAI_full*PUE[:,None]) - REN_full, 0)))
print("baseline(无AI, 纯负荷) 碳排参考:", round(base_carbon,0))
rows = []
rows.append(run_scenario("base", sched=base_sched))
# 电价: 全天平均
pf = np.array([np.full(NH2, P_full[i].mean()) for i in range(6)])
sf = np.array([np.full(NH2, SP_full[i].mean()) for i in range(6)])
rows.append(run_scenario("price_flat", price=pf, sellp=sf, sched=base_sched))
# 电价: 高波动
pv = np.array([P_full[i].mean() + 1.5*(P_full[i]-P_full[i].mean()) for i in range(6)])
sv = np.array([SP_full[i].mean() + 1.5*(SP_full[i]-SP_full[i].mean()) for i in range(6)])
rows.append(run_scenario("price_volatile", price=pv, sellp=sv, sched=base_sched))
# 新能源 +30%
rows.append(run_scenario("ren_plus30", ren=REN_full*1.3, sched=base_sched))
# 新能源 -30% (重调度)
rows.append(run_scenario("ren_minus30", ren=REN_full*0.7, sched=base_sched, resched=True, carbon_weight=0.0))
# 新能源平滑
rm = pd.DataFrame(REN_full.T).rolling(24, center=True, min_periods=1).mean().values.T
rows.append(run_scenario("ren_smooth", ren=rm, sched=base_sched))
# 新能源-30% + 碳约束60% (重调度, 高碳权重)
rows.append(run_scenario("renm30_carboncap", ren=REN_full*0.7, sched=base_sched, resched=True, carbon_weight=40.0))
df = pd.DataFrame(rows)
df.to_csv(os.path.join(RESULTS, "q4_scenarios.csv"), index=False, encoding="utf-8-sig")
print(df.round(1).to_string())
print("Q4 完成, 耗时", round(time.time()-t0,1), "s")
