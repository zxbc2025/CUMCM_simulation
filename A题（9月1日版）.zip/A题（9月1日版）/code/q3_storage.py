# -*- coding: utf-8 -*-
"""Q3 储能协同优化: 每区域独立LP (HiGHS), 三场景对比 (F10, F11, q3_storage.csv, q3_compare.csv)."""
import os, sys
import numpy as np
import pandas as pd
from scipy.optimize import linprog
from scipy.sparse import coo_matrix, vstack
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load_region_time, load_storage, load_gpu_info, REGIONS, RESULTS, FIGURES
from style import save, REGION_LABEL

rt = load_region_time().sort_values(["Region", "Hour"]).reset_index(drop=True)
sto = load_storage()
gpu = load_gpu_info()

H = list(range(0, 2407))
N = len(H)
VAR = 9  # GP,GS,UR,CR,CG,Curt,Dis,SOC,delta

def build_region(region):
    sub = rt[rt["Region"] == region].set_index("Hour")
    load = (sub["Baseline_AI_IT_Load_MW"] + sub["NonAI_IT_Load_MW"]) * gpu.loc[region, "PUE"]
    ren = sub["AvailableRenewable_MW"]
    price = sub["ElectricityPrice_CNY_per_MWh"]
    sellp = sub["SellPrice_CNY_per_MWh"]
    carb = sub["CarbonIntensity_tCO2_per_MWh"]
    s = sto.loc[region]
    cap, minsoc, init = float(s["StorageCapacity_MWh"]), float(s["MinSOC_MWh"]), float(s["InitialSOC_MWh"])
    mc, md, etac, etad = float(s["MaxChargePower_MW"]), float(s["MaxDischargePower_MW"]), float(s["ChargeEfficiency"]), float(s["DischargeEfficiency"])
    gi, ge = float(s["MaxGridImport_MW"]), float(s["MaxGridExport_MW"])
    return load.values, ren.values, price.values, sellp.values, carb.values, (cap, minsoc, init, mc, md, etac, etad, gi, ge)

def solve_region(region, no_storage=False, weights=(1.0,0.0,0.0,0.0), denom=(1.0,1.0,1.0,1.0)):
    L, R, P, SP, C, par = build_region(region)
    cap, minsoc, init, mc, md, etac, etad, gi, ge = par
    n = N * VAR + 1
    idx = lambda t, j: t * VAR + j
    Pk = n - 1
    eq_rows, eq_cols, eq_vals, eq_rhs = [], [], [], []
    ub_rows, ub_cols, ub_vals, ub_rhs = [], [], [], []
    def add_eq(coefs, rhs):
        eq_rows.extend([len(eq_rhs)] * len(coefs))
        for (c, v) in coefs:
            eq_cols.append(c); eq_vals.append(v)
        eq_rhs.append(rhs)
    def add_ub(coefs, ub):
        ub_rows.extend([len(ub_rhs)] * len(coefs))
        for (c, v) in coefs:
            ub_cols.append(c); ub_vals.append(v)
        ub_rhs.append(ub)
    # 等式: 功率平衡
    for t in range(N):
        add_eq([(idx(t,0),1.0),(idx(t,2),1.0),(idx(t,6),1.0),(idx(t,3),-1.0),(idx(t,4),-1.0),(idx(t,1),-1.0),(idx(t,5),-1.0)], L[t])
    # 等式: 新能源平衡
    for t in range(N):
        add_eq([(idx(t,2),1.0),(idx(t,3),1.0),(idx(t,1),1.0),(idx(t,5),1.0)], R[t])
    # 等式: SOC 递推
    for t in range(N):
        coefs = [(idx(t,7),1.0),(idx(t,3),-etac),(idx(t,4),-etac),(idx(t,6),1.0/etad)]
        if t > 0:
            coefs.append((idx(t-1,7),-1.0))
        add_eq(coefs, init if t == 0 else 0.0)
    # 不等式: SOC 期末约束 SOC(2406) >= InitialSOC  ->  -SOC(2406) <= -init
    add_ub([(idx(N-1,7),-1.0)], -init)
    # 不等式: 总充电上限
    for t in range(N):
        add_ub([(idx(t,3),1.0),(idx(t,4),1.0)], mc if not no_storage else 0.0)
    # 不等式: 峰值净购电 -(Pk-GP+GS)<=0
    for t in range(N):
        add_ub([(Pk,-1.0),(idx(t,0),1.0),(idx(t,1),-1.0)], 0.0)
    # 不等式: 波动 -(delta - GP + GS + m)<=0, -(delta + GP - GS - m)<=0
    coef_m = [(idx(u,0),1.0/N) for u in range(N)] + [(idx(u,1),-1.0/N) for u in range(N)]
    for t in range(N):
        add_ub([(idx(t,8),-1.0),(idx(t,0),1.0),(idx(t,1),-1.0)] + [(c,-v) for c,v in coef_m], 0.0)
        add_ub([(idx(t,8),-1.0),(idx(t,0),-1.0),(idx(t,1),1.0)] + [(c,v) for c,v in coef_m], 0.0)
    A_eq = coo_matrix((eq_vals,(eq_rows,eq_cols)), shape=(len(eq_rhs), n)).tocsr()
    A_ub = coo_matrix((ub_vals,(ub_rows,ub_cols)), shape=(len(ub_rhs), n)).tocsr()
    lo = np.zeros(n); hi = np.full(n, np.inf)
    for t in range(N):
        lo[idx(t,7)] = minsoc; hi[idx(t,7)] = cap
        hi[idx(t,0)] = gi
        hi[idx(t,1)] = ge
        hi[idx(t,6)] = md if not no_storage else 0.0
        if no_storage:
            hi[idx(t,3)] = 0.0; hi[idx(t,4)] = 0.0
    w1, w2, w3, w4 = weights
    d1, d2, d3, d4 = denom
    c = np.zeros(n)
    for t in range(N):
        c[idx(t,0)] += w1*P[t]/d1 + w2*C[t]/d2   # 成本(购-售) + 碳排(购电)
        c[idx(t,1)] += -w1*SP[t]/d1
        c[idx(t,8)] += w4/d4                      # 波动
    c[Pk] += w3/d3                                # 峰值
    res = linprog(c, A_ub=A_ub, b_ub=np.array(ub_rhs), A_eq=A_eq, b_eq=np.array(eq_rhs),
                  bounds=list(zip(lo, hi)), method="highs")
    return res, n, idx, Pk, L, P, SP, C

def metrics_from_solution(res, n, idx, Pk, region):
    x = res.x
    cost = 0.0; carb = 0.0; peak = 0.0; fluc = 0.0; charge = 0.0; dis = 0.0
    net = []
    for t in range(N):
        gp = x[idx(t,0)]; gs = x[idx(t,1)]
        cost += P[t]*gp - SP[t]*gs
        carb += C[t]*gp
        net.append(gp - gs)
        charge += x[idx(t,3)] + x[idx(t,4)]
        dis += x[idx(t,6)]
    mean = np.mean(net)
    fluc = float(np.sum(np.abs(np.array(net) - mean)))
    peak = float(x[Pk])
    return dict(region=region, cost=cost, carbon=carb, peak=peak, fluctuation=fluc,
                charge=charge, discharge=dis, soc_end=x[idx(N-1,7)], status=res.status)

# 附件基准
rt2 = rt.copy()
rt2["cost"] = rt2["ElectricityPrice_CNY_per_MWh"]*rt2["GridPurchase_MW"] - rt2["SellPrice_CNY_per_MWh"]*rt2["GridSell_MW"]
rows_base = []
for r in REGIONS:
    sub = rt2[rt2["Region"] == r]
    net = sub["NetGridImport_MW"].values
    rows_base.append(dict(region=r, scenario="baseline", cost=sub["cost"].sum(), carbon=sub["CarbonEmission_tCO2"].sum(),
                          peak=net.max(), fluctuation=np.abs(net-net.mean()).sum(), charge=sub["ChargePower_MW"].sum(),
                          discharge=sub["DischargePower_MW"].sum(), soc_end=sub["SOC_MWh"].iloc[-1], status="baseline"))
base_df = pd.DataFrame(rows_base)

# 求解每区域: 无储能 与 优化
ns_rows, opt_rows, opt_curves = [], [], []
ns_by_region = {}
for r in REGIONS:
    res_ns, n, idx, Pk, L, P, SP, C = solve_region(r, no_storage=True)
    m_ns = metrics_from_solution(res_ns, n, idx, Pk, r); m_ns["scenario"] = "no_storage"
    ns_rows.append(m_ns); ns_by_region[r] = m_ns
    print(r, "no_storage status", res_ns.status)
for r in REGIONS:
    m_ns = ns_by_region[r]
    denom = (max(m_ns["cost"],1.0), max(m_ns["carbon"],1.0), max(m_ns["peak"],1.0), max(m_ns["fluctuation"],1.0))
    res_op, n, idx, Pk, L, P, SP, C = solve_region(r, no_storage=False, weights=(1.0,0.0,0.0,0.0), denom=denom)
    m_op = metrics_from_solution(res_op, n, idx, Pk, r); m_op["scenario"] = "optimized"
    opt_rows.append(m_op)
    print(r, "opt status", res_op.status, "soc_end", round(m_op["soc_end"],1))
    x = res_op.x
    curves = []
    for t in range(N):
        curves.append(dict(Hour=t, Region=r, SOC=x[idx(t,7)], Charge=x[idx(t,3)]+x[idx(t,4)],
                           Discharge=x[idx(t,6)], GridPurchase=x[idx(t,0)], GridSell=x[idx(t,1)],
                           UsedRenewable=x[idx(t,2)], Curtailment=x[idx(t,5)], NetImport=x[idx(t,0)]-x[idx(t,1)]))
    cdf = pd.DataFrame(curves)
    m_op["renew_util"] = round((cdf["UsedRenewable"].sum() + cdf["GridSell"].sum()) / rt[rt["Region"] == r]["AvailableRenewable_MW"].sum() * 100, 1)
    opt_curves.append(cdf)
curves_df = pd.concat(opt_curves, ignore_index=True)
curves_df.to_csv(os.path.join(RESULTS, "q3_storage.csv"), index=False, encoding="utf-8-sig")
ns_df = pd.DataFrame(ns_rows); op_df = pd.DataFrame(opt_rows)
compare = pd.concat([base_df, ns_df, op_df], ignore_index=True)
compare.to_csv(os.path.join(RESULTS, "q3_compare.csv"), index=False, encoding="utf-8-sig")
print(compare.round(1).to_string())

# F10: 代表性区域曲线 (RegionD + RegionE)
fig, axes = plt.subplots(3, 2, figsize=(11, 8), sharex=True)
for axc, r in zip(axes.T, ["RegionD", "RegionE"]):
    sub = curves_df[curves_df["Region"] == r]
    hr = sub["Hour"].values
    axc[0].plot(hr, sub["SOC"], color="#0072B2", lw=0.9); axc[0].set_ylabel("SOC (MWh)"); axc[0].set_title(REGION_LABEL[r])
    axc[1].plot(hr, sub["Charge"], color="#009E73", lw=0.9, label="充电")
    axc[1].plot(hr, sub["Discharge"], color="#D55E00", lw=0.9, label="放电"); axc[1].set_ylabel("MW"); axc[1].legend(fontsize=8)
    axc[2].plot(hr, sub["NetImport"], color="#444444", lw=0.7, label="净购电")
    axc[2].plot(hr, sub["GridSell"], color="#CC79A7", lw=0.7, label="外送"); axc[2].set_ylabel("MW"); axc[2].set_xlabel("小时")
    axc[2].legend(fontsize=8)
fig.suptitle("储能协同优化: 代表性区域 SOC / 充放电 / 净购电")
save(fig, os.path.join(FIGURES, "F10.pdf"))

# F11: 三场景对比柱状图 (全网合计, 归一化到基准)
agg = compare.groupby("scenario")[["cost","carbon","peak","fluctuation"]].sum()
for col in ["cost","carbon","peak","fluctuation"]:
    agg[col+"_n"] = agg[col] / agg.loc["baseline", col]
fig, ax = plt.subplots(figsize=(8, 4))
labels = ["成本", "碳排", "峰值净购电", "负荷波动"]
xpos = np.arange(4); width = 0.26
for i, sc in enumerate(["baseline", "no_storage", "optimized"]):
    vals = [agg.loc[sc, c+"_n"] for c in ["cost","carbon","peak","fluctuation"]]
    ax.bar(xpos + (i-1)*width, vals, width, label={"baseline":"附件基准","no_storage":"无储能","optimized":"储能优化"}[sc])
ax.set_xticks(xpos); ax.set_xticklabels(labels)
ax.set_ylabel("相对基准"); ax.set_title("储能对成本/碳排/峰值/波动的影响 (全网合计, 基准=1)")
ax.legend(fontsize=8)
save(fig, os.path.join(FIGURES, "F11.pdf"))
print("Q3 完成")
