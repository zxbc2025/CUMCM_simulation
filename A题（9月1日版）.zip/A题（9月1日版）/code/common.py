# -*- coding: utf-8 -*-
"""公共数据加载与计算模块 (CUMCM A题 2026 培训模拟题)."""
import os
import numpy as np
import pandas as pd

BASE = r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\附件数据"
WORK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS = os.path.join(WORK, "results")
FIGURES = os.path.join(WORK, "figures")
for d in (RESULTS, FIGURES):
    os.makedirs(d, exist_ok=True)

REGIONS = ["RegionA", "RegionB", "RegionC", "RegionD", "RegionE", "RegionF"]
TYPES = ["RealTimeInference", "BatchInference", "AITraining"]
POWER_MAP = {"RealTimeInference": 0.08, "BatchInference": 0.10, "AITraining": 0.16}
LATENCY_LIMIT = {"RealTimeInference": 20, "BatchInference": 80, "AITraining": 150}
HOURS = np.arange(0, 2407)  # 0..2406


def load_workload():
    return pd.read_excel(os.path.join(BASE, "workload_trace.xlsx"), sheet_name="Sheet1")


def load_gpu_info():
    df = pd.read_excel(os.path.join(BASE, "GPU_information.xlsx"), sheet_name="GPU中心基础情况")
    return df.set_index("Region")


def load_latency():
    df = pd.read_excel(os.path.join(BASE, "network_latency.xlsx"), sheet_name="network_latency")
    return df


def load_power_map():
    df = pd.read_excel(os.path.join(BASE, "power_mapping.xlsx"), sheet_name="任务功率映射")
    return df.set_index("TaskType")["GPU_Power_MW_per_EquivalentGPU"].to_dict()


def load_region_time():
    return pd.read_excel(os.path.join(BASE, "region_time_data.xlsx"), sheet_name="region_time_data")


def load_storage():
    return pd.read_excel(os.path.join(BASE, "storage_information.xlsx"), sheet_name="storage_information").set_index("Region")


def latency_matrix():
    df = load_latency()
    mat = {}
    for r in df.itertuples():
        mat[(r.FromRegion, r.ToRegion)] = float(r.NetworkLatency_ms)
    return mat


def feasible_regions(source, task_type, lat_mat):
    """返回任务可行的执行区域集合 (NetworkLatency <= MaxLatency)."""
    lim = LATENCY_LIMIT[task_type]
    return [r for r in REGIONS if lat_mat.get((source, r), 1e9) <= lim]


def duration_hours(dur_min):
    return dur_min / 60.0


def overlap(start, dur_h, t):
    """任务在 [start, start+dur_h) 与小时 [t, t+1) 的重叠时长(小时)."""
    return max(0.0, min(start + dur_h, t + 1.0) - max(start, float(t)))


def workload_hourly_gpu_hour(wt):
    """按到达小时聚合 GPU-hour 需求 (GPU*分钟/60)."""
    df = wt.copy()
    df["gpu_h"] = df["GPU_Demand"] * df["EstimatedDuration_min"] / 60.0
    return df.groupby("ArrivalHour")["gpu_h"].sum()


def hour_series_by_region_type(wt, metric="GPU_Demand"):
    """返回 (region, type) -> 逐时序列 (长度2400) 的字典."""
    out = {}
    for r in REGIONS:
        for k in TYPES:
            sub = wt[(wt["SourceRegion"] == r) & (wt["TaskType"] == k)]
            ser = sub.groupby("ArrivalHour")[metric].sum().reindex(range(2400), fill_value=0.0)
            out[(r, k)] = ser
    return out
