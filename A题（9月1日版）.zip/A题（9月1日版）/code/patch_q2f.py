# -*- coding: utf-8 -*-
p = r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\code\q2_schedule.py"
s = open(p, encoding="utf-8").read()

# 在 _repair 定义后追加位移式修复函数 _repair2
anchor = "def _repair(sched):"
repair2 = '''def _place_no_viol(t, ri, s, gh, pw):
    """检查任务t放到(ri,s)是否不产生违规(相对当前gh/pw). 返回bool."""
    d = t["FinishHour"] - t["StartHour"]; g = float(t["GPU"]); p = POWER_MAP[t["TaskType"]]
    h0 = int(np.floor(s)); h1 = int(np.ceil(s + d))
    hours = np.arange(max(0, h0), min(NH, h1))
    if hours.size == 0:
        return False
    ov = np.clip(np.minimum(s + d, hours + 1.0) - np.maximum(s, hours), 0.0, 1.0)
    gha = g * ov; pwa = g * p * ov
    if np.any(gh[ri][hours] + gha > CAP_GPU[ri] + 1e-6):
        return False
    if np.any(pw[ri][hours] + pwa > (CAP_IT[ri] - NONAI[ri][hours]) + 1e-6):
        return False
    return True

def _remove_t(t, ri, gh, pw):
    d = t["FinishHour"] - t["StartHour"]; g = float(t["GPU"]); p = POWER_MAP[t["TaskType"]]
    h0 = int(np.floor(t["StartHour"])); h1 = int(np.ceil(t["StartHour"] + d))
    hours = np.arange(max(0, h0), min(NH, h1))
    ov = np.clip(np.minimum(t["StartHour"] + d, hours + 1.0) - np.maximum(t["StartHour"], hours), 0.0, 1.0)
    gh[ri][hours] -= g * ov; pw[ri][hours] -= g * p * ov

def _add_t(t, ri, s, gh, pw):
    d = t["FinishHour"] - t["StartHour"]; g = float(t["GPU"]); p = POWER_MAP[t["TaskType"]]
    h0 = int(np.floor(s)); h1 = int(np.ceil(s + d))
    hours = np.arange(max(0, h0), min(NH, h1))
    ov = np.clip(np.minimum(s + d, hours + 1.0) - np.maximum(s, hours), 0.0, 1.0)
    gh[ri][hours] += g * ov; pw[ri][hours] += g * p * ov

def _repair2(sched):
    """位移式修复: 把占用D/E/F收尾槽位的早到任务提前, 为晚到任务腾出容量."""
    sched = list(sched)
    for it in range(8):
        gh, pw = _usage(sched)
        viol = set()
        for ri in range(N_REG):
            bad = np.where((gh[ri] > CAP_GPU[ri] + 1e-6) | (pw[ri] > (CAP_IT[ri] - NONAI[ri]) + 1e-6))[0]
            for h in bad:
                viol.add((ri, int(h)))
        if not viol:
            break
        progressed = False
        # 找出造成违规的任务
        for (ri, h) in sorted(viol):
            cand = [i for i, t in enumerate(sched) if RIDX[t["Region"]] == ri and t["StartHour"] <= h + 1 and t["FinishHour"] >= h]
            cand.sort(key=lambda i: -(sched[i]["GPU"] * (sched[i]["FinishHour"] - sched[i]["StartHour"])))
            for i in cand:
                t = sched[i]
                a = int(t.get("ArrivalHour", t["StartHour"]))
                d = t["FinishHour"] - t["StartHour"]
                old_ri = RIDX[t["Region"]]; old_s = t["StartHour"]
                _remove_t(t, old_ri, gh, pw)
                # 扫描所有可行(区域,开工), 选不引入违规且评分最低者
                best = None; bestscore = np.inf
                for r in feasible_regions(t["SourceRegion"], t["TaskType"], lat):
                    rj = RIDX[r]
                    s_max = int(min(2405, 2406 - d))
                    starts = np.arange(a, s_max + 1)
                    if starts.size == 0:
                        starts = np.array([a])
                    for s0 in starts:
                        if not _place_no_viol(t, rj, float(s0), gh, pw):
                            continue
                        # 评分: 敏感性成本 + 时延 + 延迟
                        h0 = int(np.floor(s0)); h1 = int(np.ceil(s0 + d))
                        hrs = np.arange(max(0, h0), min(NH, h1))
                        ov = np.clip(np.minimum(s0 + d, hrs + 1.0) - np.maximum(s0, hrs), 0.0, 1.0)
                        sc = float(np.sum(ov * t["GPU"] * MRG_P_SENS[rj][hrs])) + 3.0 * lat[(t["SourceRegion"], r)] * t["GPU"] * d + 1.0 * (s0 - a) * t["GPU"] * d * 0.01
                        if sc < bestscore:
                            bestscore = sc; best = (rj, float(s0))
                if best is None:
                    # 无法无违规重放: 若槽位被早到任务占用, 尝试"提前腾挪"占用者
                    # 先在原地恢复, 再尝试把占用D/E/F收尾的早任务提前
                    _add_t(t, old_ri, old_s, gh, pw)
                    continue
                rj, s0 = best
                _add_t(t, rj, s0, gh, pw)
                t["Region"] = REGIONS[rj]; t["StartHour"] = s0; t["FinishHour"] = round(s0 + d, 3)
                progressed = True
                break
            if progressed:
                break
        if not progressed:
            break
    return sched

def _repair(sched):'''
assert anchor in s
s = s.replace(anchor, repair2, 1)
# run_schedule 调用 _repair2
s = s.replace("    sched = _repair(sched)\n    return pd.DataFrame(sched), used_gh, used_pw", "    sched = _repair2(sched)\n    return pd.DataFrame(sched), used_gh, used_pw")
open(p, "w", encoding="utf-8").write(s)
print("displacement repair added")
