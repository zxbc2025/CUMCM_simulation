# -*- coding: utf-8 -*-
p = r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\code\q1_schedule.py"
s = open(p, encoding="utf-8").read()

# 1) 删除 Fmax 逐任务 epigraph 构建段
old_fmax = '''# Fmax: 每个任务 i: sum_s (s+d) x(i,.,s) - Fmax <= 0 (逐任务epigraph)
for ti, key in enumerate(task_keys):
    row_f = np.zeros(n)
    for i, tk in enumerate(tasks):
        if tk["id"] == key:
            row_f[i] = tk["s"] + tk["d"]
    rows_ub.append(row_f); b_ub.append(0.0)

# 目标: Fmax + 负载均衡微项
c = np.zeros(n + 1); c[-1] = 1.0
for i, tk in enumerate(tasks):
    c[i] = 0.0005 * tk["gpu"] * tk["d"] / float(gpu.loc[tk["r"], "Available_GPU"])

A_ub_full = np.zeros((len(rows_ub), n + 1))
A_ub_full[:, :n] = np.array(rows_ub)
# 每个Fmax行(最后 n_tasks 行)在Fmax列系数 -1
for j in range(n_tasks):
    A_ub_full[len(rows_ub) - n_tasks + j, -1] = -1.0
A_eq_full = np.zeros((n_tasks, n + 1)); A_eq_full[:, :n] = A_eq

lb = np.zeros(n + 1); ub = np.ones(n + 1); ub[-1] = 2410.0
integrality = np.ones(n + 1); integrality[-1] = 0'''
new_fmax = '''# 目标: 最小化峰值利用率 Umax (负载均衡) + 微小提前完成偏好
# Umax >= usage(r,t)/Available_GPU(r)  ->  usage(r,t) - Available_GPU(r)*Umax <= 0
for r in REGIONS:
    cap = float(gpu.loc[r, "Available_GPU"])
    for t in hours:
        row_u = np.zeros(n)
        for i, tk in enumerate(tasks):
            if tk["r"] == r:
                ov = overlap(tk["s"], tk["d"], t)
                if ov > 0:
                    row_u[i] = tk["gpu"] * ov
        rows_ub.append(row_u); b_ub.append(0.0)

c = np.zeros(n + 1); c[-1] = 1.0  # Umax 主目标
for i, tk in enumerate(tasks):
    c[i] = 1e-7 * (tk["s"] + tk["d"])  # 提前完成微偏好(不改变均衡主目标)

A_ub_full = np.zeros((len(rows_ub), n + 1))
A_ub_full[:, :n] = np.array(rows_ub)
# 每个Umax行(最后 6*30 行)在Umax列系数 -Available_GPU
r_idx = 0
for r in REGIONS:
    cap = float(gpu.loc[r, "Available_GPU"])
    for t in hours:
        A_ub_full[len(rows_ub) - len(REGIONS)*len(hours) + r_idx, -1] = -cap
        r_idx += 1
A_eq_full = np.zeros((n_tasks, n + 1)); A_eq_full[:, :n] = A_eq

lb = np.zeros(n + 1); ub = np.ones(n + 1); ub[-1] = 2.0  # Umax 上界放宽
integrality = np.ones(n + 1); integrality[-1] = 0'''
assert old_fmax in s, "fmax block not found"
s = s.replace(old_fmax, new_fmax)
open(p, "w", encoding="utf-8").write(s)
print("q1_schedule.py objective rewritten")
