# -*- coding: utf-8 -*-
import os, sys, time
sys.path.insert(0, r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\code")
import q2_schedule as q2
import numpy as np, pandas as pd
sched, gh, pw = q2.run_schedule(lat_weight=3.0, carbon_weight=0.0)
sched.to_csv(r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\results\q2_schedule_diag.csv", index=False)
gh2, pw2 = q2._usage(sched.to_dict("records"))
for ri, r in enumerate(q2.REGIONS):
    rem = q2.CAP_IT[ri] - q2.NONAI[ri]
    vp = np.where(pw2[ri] > rem + 1e-6)[0]
    if len(vp):
        print(r, "IT越限:", len(vp), "小时:", vp[:15].tolist(), "最大超限:", round(float((pw2[ri]-rem).max()),1))
vg = int(np.sum(gh2 > q2.CAP_GPU[:, None] + 1e-6)); vp = int(np.sum(pw2 > (q2.CAP_IT[:, None] - q2.NONAI) + 1e-6))
print("TOTAL GPU越限:", vg, "IT越限:", vp)
