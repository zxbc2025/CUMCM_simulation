# -*- coding: utf-8 -*-
import os
base = r"C:\Users\1\.codex\skills\cumcm-modeling\scripts"
for fn in ["check_pdf_rules.py", "check_cross_format.py"]:
    p = os.path.join(base, fn)
    s = open(p, encoding="utf-8").read()
    old = "capture_output=True, text=True, timeout=90"
    new = "capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=90"
    assert old in s, fn
    s = s.replace(old, new)
    open(p, "w", encoding="utf-8").write(s)
    print(fn, "patched")
