# -*- coding: utf-8 -*-
p = r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\code\q2_schedule.py"
s = open(p, encoding="utf-8").read()

# 1) 签名加 pressure_weight
old = "def run_schedule(lat_weight=0.3, carbon_weight=0.0, max_delay_batch=16, max_delay_train=32, delay_penalty=1.0, step=4):"
new = "def run_schedule(lat_weight=0.3, carbon_weight=0.0, max_delay_batch=16, max_delay_train=32, delay_penalty=1.0, step=4, pressure_weight=0.0):"
assert old in s
s = s.replace(old, new)

# 2) score 中加入压力项
old2 = '''            score = np.sum(gh_add * (MRG_P[ri_arr][:, hours] + carbon_weight * MRG_C[ri_arr][:, hours]), axis=1) \\
                    + lat_weight * np.array([lat[(row.SourceRegion, REGIONS[ri_arr[i]])] for i in range(len(ri_arr))]) * g * d \\
                    + delay_penalty * (s_arr - a) * g * d * 0.01'''
new2 = '''            pressure = np.sum((used_gh_c + gh_add) / CAP_GPU[ri_arr, None], axis=1)
            score = np.sum(gh_add * (MRG_P[ri_arr][:, hours] + carbon_weight * MRG_C[ri_arr][:, hours]), axis=1) \\
                    + lat_weight * np.array([lat[(row.SourceRegion, REGIONS[ri_arr[i]])] for i in range(len(ri_arr))]) * g * d \\
                    + delay_penalty * (s_arr - a) * g * d * 0.01 \\
                    + pressure_weight * pressure'''
assert old2 in s
s = s.replace(old2, new2)
open(p, "w", encoding="utf-8").write(s)
print("q2_schedule.py pressure term added")
