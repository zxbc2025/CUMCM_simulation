# -*- coding: utf-8 -*-
"""Q4 图表: F12 场景热力图, F13 雷达图(优化vs基准), F14 迁移率/储能电量."""
import os, sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load_region_time, REGIONS, RESULTS, FIGURES
from style import save

rt = load_region_time()
df = pd.read_csv(os.path.join(RESULTS, "q4_scenarios.csv"))
scn_order = ["base","price_flat","price_volatile","ren_plus30","ren_minus30","ren_smooth","renm30_carboncap"]
df["scenario"] = pd.Categorical(df["scenario"], categories=scn_order, ordered=True)
df = df.sort_values("scenario")

# 附件基准指标 (0..2406)
rt2 = rt.copy(); rt2["cost"] = rt2["ElectricityPrice_CNY_per_MWh"]*rt2["GridPurchase_MW"] - rt2["SellPrice_CNY_per_MWh"]*rt2["GridSell_MW"]
net = rt2["NetGridImport_MW"].values
base_metrics = dict(cost=rt2["cost"].sum(), carbon=rt2["CarbonEmission_tCO2"].sum(), peak=net.max(),
                    fluctuation=np.abs(net-net.mean()).sum(),
                    renew_util=(rt2["UsedRenewable_MW"]+rt2["RenewableCharge_MW"]+rt2["GridSell_MW"]).sum()/rt2["AvailableRenewable_MW"].sum()*100)

# ---------- F12: 场景 x 指标 热力图 (按base归一化) ----------
metrics = ["cost","carbon","peak","fluctuation","avg_latency_ms","migration_rate"]
base_row = df[df["scenario"]=="base"].iloc[0]
mat = np.zeros((len(df), len(metrics)))
for j, met in enumerate(metrics):
    mat[:, j] = df[met].values / max(base_row[met], 1e-9)
labels = ["成本","碳排","峰值购电","负荷波动","平均时延","迁移率"]
fig, ax = plt.subplots(figsize=(8.5, 4.2))
im = ax.imshow(mat, cmap="YlOrRd", aspect="auto")
ax.set_xticks(range(len(metrics))); ax.set_xticklabels(labels)
ax.set_yticks(range(len(df))); ax.set_yticklabels(df["scenario"].tolist())
for i in range(len(df)):
    for j in range(len(metrics)):
        ax.text(j, i, f"{mat[i,j]:.2f}", ha="center", va="center", fontsize=7)
ax.set_title("场景矩阵: 指标相对基准场景倍数 (基准=1)")
fig.colorbar(im, ax=ax)
save(fig, os.path.join(FIGURES, "F12.pdf"))

# ---------- F13: 雷达图 (联合优化 vs 附件基准, 归一化, 越外越好) ----------
base_opt = df[df["scenario"]=="base"].iloc[0]
r_names = ["成本","碳排","峰值净购电","负荷波动","新能源利用率"]
# 越低越好 -> baseline/value; 越高越好 -> value/baseline
def norm_opt(metric, higher_better=False):
    b = base_metrics[metric]; v = float(base_opt[metric])
    return v/b if higher_better else b/max(v,1e-9)
opt_vals = [norm_opt("cost"), norm_opt("carbon"), norm_opt("peak"), norm_opt("fluctuation"), norm_opt("renew_util", higher_better=True)]
base_vals = [1.0]*5
ang = np.linspace(0, 2*np.pi, len(r_names), endpoint=False).tolist()
ang += ang[:1]
fig = plt.figure(figsize=(5.5, 5.2))
ax = fig.add_subplot(111, polar=True)
ax.plot(ang, base_vals + base_vals[:1], color="#999999", lw=1.5, label="附件基准")
ax.fill(ang, base_vals + base_vals[:1], color="#999999", alpha=0.2)
ax.plot(ang, opt_vals + opt_vals[:1], color="#D55E00", lw=1.5, label="算储电联合优化")
ax.fill(ang, opt_vals + opt_vals[:1], color="#D55E00", alpha=0.25)
ax.set_xticks(ang[:-1]); ax.set_xticklabels(r_names)
ax.set_ylim(0, max(max(opt_vals), 1.5))
ax.set_title("联合优化 vs 附件基准 (归一化, 越外越好)", pad=20)
ax.legend(loc="upper right", bbox_to_anchor=(1.25, 1.1), fontsize=8)
save(fig, os.path.join(FIGURES, "F13.pdf"))

# ---------- F14: 迁移率 与 储能充放电电量 ----------
fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
axes[0].bar(np.arange(len(df)), df["migration_rate"]*100, color="#0072B2")
axes[0].set_xticks(np.arange(len(df))); axes[0].set_xticklabels(df["scenario"], rotation=30, ha="right", fontsize=7)
axes[0].set_ylabel("迁移率 (%)"); axes[0].set_title("各场景任务迁移率")
axes[1].bar(np.arange(len(df)), df["charge"]/1e3, color="#009E73", label="充电(GWh)")
axes[1].bar(np.arange(len(df)), -df["discharge"]/1e3, color="#D55E00", label="放电(GWh)")
axes[1].axhline(0, color="k", lw=0.8)
axes[1].set_xticks(np.arange(len(df))); axes[1].set_xticklabels(df["scenario"], rotation=30, ha="right", fontsize=7)
axes[1].set_ylabel("GWh"); axes[1].set_title("各场景储能充放电电量(全网)"); axes[1].legend(fontsize=8)
save(fig, os.path.join(FIGURES, "F14.pdf"))
print("Q4 图表完成")
