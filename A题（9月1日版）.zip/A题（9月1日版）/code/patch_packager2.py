# -*- coding: utf-8 -*-
p = r"C:\Users\1\.codex\skills\cumcm-modeling\scripts\package_supporting_materials.py"
s = open(p, encoding="utf-8").read()
old = "        shutil.copy2(temporary, output)\ntemporary.unlink(missing_ok=True)"
new = "        shutil.copy2(temporary, output)\n        temporary.unlink(missing_ok=True)"
assert old in s, "pattern not found"
s = s.replace(old, new)
open(p, "w", encoding="utf-8").write(s)
print("indent fixed")
