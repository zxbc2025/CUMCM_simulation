# -*- coding: utf-8 -*-
p = r"C:\Users\1\.codex\skills\cumcm-modeling\scripts\package_supporting_materials.py"
s = open(p, encoding="utf-8").read()
old = "os.replace(temporary, output)"
new = "shutil.copy2(temporary, output)\ntemporary.unlink(missing_ok=True)"
assert old in s
s = s.replace(old, new)
if "import shutil" not in s:
    s = s.replace("import os", "import os\nimport shutil", 1)
open(p, "w", encoding="utf-8").write(s)
print("package_supporting_materials.py patched")
