# -*- coding: utf-8 -*-
p = r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\code\q2_schedule.py"
s = open(p, encoding="utf-8").read()
old = '''    cost = 0.0; carbon = 0.0; used_sum = 0.0; avail_sum = 0.0; gp_sum = 0.0
    latency = 0.0; mig = 0'''
new = '''    cost = 0.0; carbon = 0.0; used_sum = 0.0; avail_sum = 0.0; gp_sum = 0.0
    cost_sens = 0.0; carbon_sens = 0.0
    latency = 0.0; mig = 0'''
assert old in s
s = s.replace(old, new)
old2 = '''        cost += float(np.sum(gp * P[ri] - gs * SP[ri]))
        carbon += float(np.sum(gp * CI[ri]))
        used_sum += float(np.sum(used + gs))
        avail_sum += float(np.sum(REN[ri]))
        gp_sum += float(np.sum(gp))'''
new2 = '''        cost += float(np.sum(gp * P[ri] - gs * SP[ri]))
        carbon += float(np.sum(gp * CI[ri]))
        used_sum += float(np.sum(used + gs))
        avail_sum += float(np.sum(REN[ri]))
        gp_sum += float(np.sum(gp))
        # 敏感性口径: 按基准可再生消纳剖面, 未覆盖负荷全额购电/计碳
        uncovered = np.maximum(load - UREN_BASE[ri], 0)
        cost_sens += float(np.sum(uncovered * P[ri]))
        carbon_sens += float(np.sum(uncovered * CI[ri]))'''
assert old2 in s
s = s.replace(old2, new2)
old3 = '''    return dict(cost=cost, carbon=carbon, renew_util=used_sum / avail_sum * 100 if avail_sum else 0,
                latency=latency, migration_rate=mig / len(sched_df), grid_purchase=gp_sum)'''
new3 = '''    return dict(cost=cost, carbon=carbon, renew_util=used_sum / avail_sum * 100 if avail_sum else 0,
                latency=latency, migration_rate=mig / len(sched_df), grid_purchase=gp_sum,
                cost_sens=cost_sens, carbon_sens=carbon_sens)'''
assert old3 in s
s = s.replace(old3, new3)
open(p, "w", encoding="utf-8").write(s)
print("evaluate() sensitivity caliber added")
