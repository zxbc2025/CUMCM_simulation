# -*- coding: utf-8 -*-
import os, pandas as pd
work = r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work"
results = os.path.join(work, "results")
tables = os.path.join(work, "paper", "tables")

t1 = """| 类别 | 符号 | 含义 |
|---|---|---|
| 集合 | $\\mathcal{R}$ | 六区域集合 RegionA-F |
| 集合 | $\\mathcal{T}$ | 小时集合 0-2406（主时域 0-2399，收尾 2400-2405） |
| 集合 | $\\mathcal{I}$ | 任务集合（50000 个） |
| 参数 | $a_i,d_i,g_i,k_i,o_i$ | 任务到达时点/时长/GPU 需求/类型/来源区域 |
| 参数 | $M_i, L_{o,r}$ | 任务最大时延 / 来源到执行区域单向时延 |
| 参数 | $A_r, U_r, \\rho_r$ | 可调度 GPU 容量 / 最大 IT 功率 / PUE |
| 参数 | $p_r(t), s_r(t), c_r(t)$ | 购电价 / 售电价 / 碳强度 |
| 参数 | $\\mathrm{Ren}_r(t)$ | 可用新能源出力 |
| 参数 | $C_r, \\underline{S}_r, S_r^0$ | 储能容量 / SOC 下限 / 初始 SOC |
| 变量 | $x_{i,r}, z_{i,s}$ | 任务区域指派 / 开工时点决策 |
| 变量 | $\\mathrm{GP},\\mathrm{GS},\\mathrm{UR},\\mathrm{Curt}$ | 购电 / 外送 / 直接消纳 / 弃电功率 |
| 变量 | $\\mathrm{Ch},\\mathrm{Dis},\\mathrm{SOC}$ | 充 / 放电功率与 SOC |
| 指标 | $\\eta_{\\mathrm{ren}}$ | 新能源利用率 |
"""
open(os.path.join(tables, "T1-notation.md"), "w", encoding="utf-8").write(t1)

t2 = """| 项目 | 数值 |
|---|---|
| 任务总数 | 50000（实时 16724 / 批量 16717 / 训练 16559） |
| GPU 需求均值/中位数/最大 | 29.5 / 13 / 127 |
| 逐时到达数 | 8-36 个/时（均值 20.8，方差/均值比 0.97） |
| 逐时到达 GPU-hour | 均值 2092，最大 5503 |
| 末窗口(2376-2399)到达任务 | 538（训练 194 / 批量 184 / 实时 160） |
| 时延阈值 | 实时 20ms / 批量 80ms / 训练 150ms |
| 电价区间(元/MWh) | 东部 414-1096，西部/新能源区 235-655 |
| 碳强度均值(tCO2/MWh) | A 0.62 / B 0.58 / C 0.55 / D 0.42 / E 0.22 / F 0.26 |
| 可用新能源 | 均值 799.8 MW，最大 1100 MW（六区域相同） |
| 全网基准电费 | 18.02 亿元 |
| 全网基准碳排 | 204.54 万吨 |
| 全网基准新能源利用率 | 32.9% |
"""
open(os.path.join(tables, "T2-stats.md"), "w", encoding="utf-8").write(t2)

m = pd.read_csv(os.path.join(results, "q1_metrics.csv"), index_col=["region", "type"])
rows = ["| 区域 | 类型 | 模型MAPE(%) | 持久性MAPE(%) | 历史均值MAPE(%) | RMSE | PICP |", "|---|---|---|---|---|---|---|"]
for (r, k), row in m.iterrows():
    rows.append("| {} | {} | {:.1f} | {:.1f} | {:.1f} | {:.1f} | {:.2f} |".format(r, k, row["MAPE_model"], row["MAPE_persist"], row["MAPE_histmean"], row["RMSE_model"], row["PICP"]))
open(os.path.join(tables, "T3-forecast.md"), "w", encoding="utf-8").write("\n".join(rows) + "\n")

c = pd.read_csv(os.path.join(results, "q2_compare.csv"))
rows = ["| 场景 | 成本(元) | 碳排(tCO2) | 新能源利用率(%) | 迁移率 |", "|---|---|---|---|---|"]
for _, r in c.iterrows():
    rows.append("| {} | {:,.0f} | {:,.0f} | {:.1f} | {:.4f} |".format(r["scenario"], r["cost"], r["carbon"], r["renew_util"], r["migration_rate"]))
open(os.path.join(tables, "T4-q2.md"), "w", encoding="utf-8").write("\n".join(rows) + "\n")

c = pd.read_csv(os.path.join(results, "q3_compare.csv"))
rows = ["| 场景 | 成本(元) | 碳排(tCO2) | 峰值净购电(MW) | 波动 | 充电(MWh) | 放电(MWh) |", "|---|---|---|---|---|---|---|"]
for _, r in c.iterrows():
    rows.append("| {} | {:,.0f} | {:,.0f} | {:,.1f} | {:,.0f} | {:,.0f} | {:,.0f} |".format(r["scenario"], r["cost"], r["carbon"], r["peak"], r["fluctuation"], r["charge"], r["discharge"]))
open(os.path.join(tables, "T5-q3.md"), "w", encoding="utf-8").write("\n".join(rows) + "\n")

c = pd.read_csv(os.path.join(results, "q4_scenarios.csv"))
rows = ["| 场景 | 成本(元) | 碳排(tCO2) | 峰值(MW) | 波动 | 平均时延(ms) | 迁移率 | 利用率(%) | 充电(MWh) |", "|---|---|---|---|---|---|---|---|---|"]
for _, r in c.iterrows():
    rows.append("| {} | {:,.0f} | {:,.0f} | {:,.1f} | {:,.0f} | {:.1f} | {:.4f} | {:.1f} | {:,.0f} |".format(r["scenario"], r["cost"], r["carbon"], r["peak"], r["fluctuation"], r["avg_latency_ms"], r["migration_rate"], r["renew_util"], r["charge"]))
open(os.path.join(tables, "T6-q4.md"), "w", encoding="utf-8").write("\n".join(rows) + "\n")
print("tables T1-T6 written")
for f in sorted(os.listdir(tables)):
    print(f, os.path.getsize(os.path.join(tables, f)))
