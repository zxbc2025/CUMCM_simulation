# -*- coding: utf-8 -*-
p = r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\paper\manuscript.md"
s = open(p, encoding="utf-8").read()
# 确保一级标题存在
if not s.startswith("# 模型建立与求解\n"):
    idx = s.index("## 统一口径与基础公式")
    s = s[:idx] + "# 模型建立与求解\n\n" + s[idx:]
# 引用 R-Q1-01
old2 = "决策变量 $x_{i,r,s}\\in\\{0,1\\}$ 表示任务 $i$ 在区域 $r$ 于整小时 $s$ 开工"
new2 = "对第 2376–2399 时实际到达的 {{result:R-Q1-01}} 个任务建立时间索引 0-1 整数规划。决策变量 $x_{i,r,s}\\in\\{0,1\\}$ 表示任务 $i$ 在区域 $r$ 于整小时 $s$ 开工"
if old2 in s:
    s = s.replace(old2, new2)
    print("R-Q1-01 reference added")
else:
    print("old2 NOT FOUND - checking current text")
    i = s.find("决策变量")
    print(repr(s[i:i+80]))
open(p, "w", encoding="utf-8").write(s)
