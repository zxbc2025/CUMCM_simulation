# -*- coding: utf-8 -*-
"""Q1 基础算力调度: 末窗口538任务 时间索引MILP (HiGHS), 输出甘特图F3与利用率F4."""
import os, sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import milp, LinearConstraint, Bounds
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (load_workload, load_gpu_info, REGIONS, TYPES, POWER_MAP, RESULTS, FIGURES, feasible_regions, latency_matrix, overlap, duration_hours, BASE)
from style import save, TYPE_COLOR, TYPE_LABEL, REGION_LABEL

wt = load_workload()
gpu = load_gpu_info()
lat = latency_matrix()
fw = wt[(wt["ArrivalHour"] >= 2376) & (wt["ArrivalHour"] <= 2399)].copy().reset_index(drop=True)
src_map = dict(zip(fw["TaskID"], fw["SourceRegion"]))
print("末窗口任务数:", len(fw), fw["TaskType"].value_counts().to_dict())

tasks = []
for row in fw.itertuples():
    d = duration_hours(row.EstimatedDuration_min)
    for r in feasible_regions(row.SourceRegion, row.TaskType, lat):
        if row.TaskType == "RealTimeInference":
            starts = [int(row.ArrivalHour)]
        else:
            starts = list(range(int(row.ArrivalHour), int(min(2405, 2406 - d)) + 1))
        for s in starts:
            tasks.append(dict(id=int(row.TaskID), type=row.TaskType, gpu=float(row.GPU_Demand),
                              p=POWER_MAP[row.TaskType], d=d, r=r, s=s))
n = len(tasks)
print("候选(任务,区域,开工)对:", n)

# 唯一性: 每任务恰选一个
task_keys = []
for t in tasks:
    if not task_keys or task_keys[-1] != t["id"]:
        task_keys.append(t["id"])
n_tasks = len(task_keys)
A_eq = np.zeros((n_tasks, n))
row = 0
for ti, key in enumerate(task_keys):
    cols = [i for i, t in enumerate(tasks) if t["id"] == key]
    A_eq[ti, cols] = 1.0
b_eq = np.ones(n_tasks)

# 非AI负荷
rt = pd.read_excel(os.path.join(BASE, "region_time_data.xlsx"), sheet_name="region_time_data")
nonai = rt.set_index(["Hour", "Region"])["NonAI_IT_Load_MW"]
hours = list(range(2376, 2406))

rows_ub, b_ub = [], []
for r in REGIONS:
    cap = float(gpu.loc[r, "Available_GPU"]); itcap = float(gpu.loc[r, "Max_IT_Power_MW"])
    for t in hours:
        row_g = np.zeros(n); row_p = np.zeros(n)
        for i, tk in enumerate(tasks):
            if tk["r"] != r:
                continue
            ov = overlap(tk["s"], tk["d"], t)
            if ov > 0:
                row_g[i] = tk["gpu"] * ov
                row_p[i] = tk["gpu"] * tk["p"] * ov
        rows_ub.append(row_g); b_ub.append(cap)
        rows_ub.append(row_p); b_ub.append(itcap - float(nonai.loc[(t, r)]))

# 目标: 最小化峰值利用率 Umax (负载均衡) + 微小提前完成偏好
# Umax >= usage(r,t)/Available_GPU(r)  ->  usage(r,t) - Available_GPU(r)*Umax <= 0
for r in REGIONS:
    cap = float(gpu.loc[r, "Available_GPU"])
    for t in hours:
        row_u = np.zeros(n)
        for i, tk in enumerate(tasks):
            if tk["r"] == r:
                ov = overlap(tk["s"], tk["d"], t)
                if ov > 0:
                    row_u[i] = tk["gpu"] * ov
        rows_ub.append(row_u); b_ub.append(0.0)

c = np.zeros(n + 1); c[-1] = 1.0  # Umax 主目标
for i, tk in enumerate(tasks):
    c[i] = 1e-7 * (tk["s"] + tk["d"])  # 提前完成微偏好(不改变均衡主目标)

A_ub_full = np.zeros((len(rows_ub), n + 1))
A_ub_full[:, :n] = np.array(rows_ub)
# 每个Umax行(最后 6*30 行)在Umax列系数 -Available_GPU
r_idx = 0
for r in REGIONS:
    cap = float(gpu.loc[r, "Available_GPU"])
    for t in hours:
        A_ub_full[len(rows_ub) - len(REGIONS)*len(hours) + r_idx, -1] = -cap
        r_idx += 1
A_eq_full = np.zeros((n_tasks, n + 1)); A_eq_full[:, :n] = A_eq

lb = np.zeros(n + 1); ub = np.ones(n + 1); ub[-1] = 2.0  # Umax 上界放宽
integrality = np.ones(n + 1); integrality[-1] = 0
res = milp(c=c, integrality=integrality, bounds=Bounds(lb, ub),
           constraints=[LinearConstraint(A_ub_full, -np.inf, np.array(b_ub)),
                        LinearConstraint(A_eq_full, b_eq, b_eq)],
           options={"time_limit": 600})
print("milp status:", res.status, res.message)
if res.x is None:
    print("FAILED"); sys.exit(1)
x = np.round(res.x[:n]).astype(int)
Fmax = float(res.x[-1])

sched = []
for i, tk in enumerate(tasks):
    if x[i] == 1:
        sched.append(dict(TaskID=tk["id"], TaskType=tk["type"], Region=tk["r"], StartHour=tk["s"],
                          FinishHour=round(tk["s"] + tk["d"], 3), Duration_h=round(tk["d"], 3), GPU=tk["gpu"]))
sched_df = pd.DataFrame(sched).sort_values(["StartHour", "Region"]).reset_index(drop=True)
sched_df.to_csv(os.path.join(RESULTS, "q1_schedule.csv"), index=False, encoding="utf-8-sig")
sched_df["src"] = sched_df["TaskID"].map(src_map)
sched_df["migrated"] = sched_df["src"] != sched_df["Region"]
print("任务数(解):", len(sched_df), "Fmax:", round(Fmax, 2))
print("迁移率:", sched_df["migrated"].mean().round(3))
print("按类型迁移:", sched_df.groupby("TaskType")["migrated"].agg(["sum", "count"]).to_dict("index"))

util_rows = []
for r in REGIONS:
    cap = float(gpu.loc[r, "Available_GPU"])
    for t in hours:
        gh = sum(tk["gpu"] * overlap(tk["s"], tk["d"], t) for tk, xi in zip(tasks, x) if xi and tk["r"] == r)
        util_rows.append(dict(Region=r, Hour=t, GPUhour=round(gh, 2), Utilization=round(gh / cap * 100, 2)))
util_df = pd.DataFrame(util_rows)
util_df.to_csv(os.path.join(RESULTS, "q1_util.csv"), index=False, encoding="utf-8-sig")
viol = util_df[util_df["GPUhour"] > util_df["Region"].map(gpu["Available_GPU"])]
print("容量越限数:", len(viol))

# F3 甘特图
fig, ax = plt.subplots(figsize=(11, 5))
rows_y = {r: i for i, r in enumerate(REGIONS)}
for tk in sched_df.itertuples():
    ax.barh(rows_y[tk.Region], tk.FinishHour - tk.StartHour, left=tk.StartHour, height=0.6,
            color=TYPE_COLOR[tk.TaskType], alpha=0.85)
ax.set_yticks(range(len(REGIONS))); ax.set_yticklabels([REGION_LABEL[r] for r in REGIONS])
ax.set_xlim(2376, 2406); ax.set_xlabel("小时 (2376–2406)")
ax.set_title("第 2376–2399 时到达任务调度甘特图 (区域分层, 颜色=任务类型)")
import matplotlib.patches as mpatches
ax.legend(handles=[mpatches.Patch(color=TYPE_COLOR[k], label=TYPE_LABEL[k]) for k in TYPES], loc="lower right", fontsize=8)
save(fig, os.path.join(FIGURES, "F3.pdf"))

# F4 利用率
fig, ax = plt.subplots(figsize=(10, 4.2))
for r in REGIONS:
    sub = util_df[util_df["Region"] == r]
    ax.plot(sub["Hour"], sub["Utilization"], label=REGION_LABEL[r], lw=1.2)
ax.axhline(100, color="k", ls="--", lw=0.8)
ax.set_xlabel("小时 (2376–2399)"); ax.set_ylabel("GPU 利用率 (%)")
ax.set_title("各区域逐时 GPU 利用率")
ax.legend(ncol=3, fontsize=8)
save(fig, os.path.join(FIGURES, "F4.pdf"))
print("Q1 调度完成")
