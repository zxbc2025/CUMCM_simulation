# -*- coding: utf-8 -*-
import os
p = r"C:\Users\1\.codex\skills\cumcm-modeling\scripts\visual_qa.py"
s = open(p, encoding="utf-8").read()
s = s.replace("capture_output=True, text=True, timeout=60", "capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=60")
s = s.replace("capture_output=True,\ntext=True,", "capture_output=True,\ntext=True,\nencoding='utf-8',\nerrors='replace',")
open(p, "w", encoding="utf-8").write(s)
print("visual_qa.py patched")
