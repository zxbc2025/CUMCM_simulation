# -*- coding: utf-8 -*-
p = r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\code\q2_schedule.py"
s = open(p, encoding="utf-8").read()
# 默认时延权重改为 3.0
s = s.replace("def run_schedule(lat_weight=0.3, carbon_weight=0.0,", "def run_schedule(lat_weight=3.0, carbon_weight=0.0,")
# 主运行
s = s.replace("sched_main, gh, pw = run_schedule(lat_weight=0.3, carbon_weight=0.0)", "sched_main, gh, pw = run_schedule(lat_weight=3.0, carbon_weight=0.0)")
# 时延扫描(快组合)
s = s.replace("for lw in [0.0, 0.3, 3.0]:", "for lw in [0.0, 0.3, 1.0, 3.0]:")
# 碳扫描
s = s.replace("for cw in [0.0, 20.0]:", "for cw in [0.0, 20.0]:")
open(p, "w", encoding="utf-8").write(s)
print("q2 defaults updated")
