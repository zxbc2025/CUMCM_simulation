# -*- coding: utf-8 -*-
import os, sys, time
sys.path.insert(0, r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\code")
import q2_schedule as q2
import numpy as np, pandas as pd
t0 = time.time()
sched, gh, pw = q2.run_schedule(lat_weight=3.0, carbon_weight=0.0)
print('run time: %.1fs' % (time.time()-t0))
sched.to_csv(r"H:\数模\2026年暑期培训第二次模拟题\A题 面向算电协同的多目标调度优化研究\cumcm_work\results\q2_schedule_diag.csv", index=False)
gh2, pw2 = q2._usage(sched.to_dict('records'))
vg = int(np.sum(gh2 > q2.CAP_GPU[:, None] + 1e-6)); vp = int(np.sum(pw2 > (q2.CAP_IT[:, None] - q2.NONAI) + 1e-6))
print('GPU越限:', vg, 'IT越限:', vp)
print('迁移率:', round(float((sched['SourceRegion']!=sched['Region']).mean()),4))
tot_gh = float(np.sum(sched['GPU']*(sched['FinishHour']-sched['StartHour'])))
lat = sum(q2.lat[(r.SourceRegion,r.Region)]*r.GPU*(r.FinishHour-r.StartHour) for r in sched.itertuples())
print('平均时延(ms):', round(lat/tot_gh,1))
