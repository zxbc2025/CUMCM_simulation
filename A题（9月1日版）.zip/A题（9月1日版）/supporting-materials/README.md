# 支撑材料说明

本目录为 A 题《面向算电协同的多目标调度优化研究》的支撑材料。

## 内容
- code/         模型实现脚本（统计、预测、调度、储能、协同与图表）
- results/      结果数据（CSV/JSON）
- figures/      论文图（PDF/SVG/PNG）
- validation/   校验报告（数据审计、结果溯源、预检等）
- ai-disclosure AI 使用披露

## 复现步骤
1. 运行 code/q1_stats.py、q1_forecast.py、q1_schedule.py 生成问题一结果与图
2. 运行 code/q2_schedule.py、q3_storage.py、q4_joint.py、q4_figures.py 生成问题二~四结果与图
3. 运行 code/make_ledger.py 生成结果台账与溯源校验
4. 运行 code/make_tables.py 生成论文表格源

## 环境
Python 3.13 + numpy/pandas/scipy/pulp/matplotlib/openpyxl/lightgbm；论文构建需 pandoc + xelatex。
